using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;


namespace LightningSample
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        LightningBolt[] lightnings;

        int currentItem = 0;
        int itemCount = 4;
        bool showBackground = true;

        Texture2D background;

        KeyboardState lastKeyState;
        GamePadState lastPadState;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //create a topology for the lightning
            lightnings = new LightningBolt[itemCount];

            LightningDescriptor ld = new LightningDescriptor();
            ld.Topology.Clear();
            ld.Topology.Add(LightningSubdivisionOp.JitterAndFork);
            ld.Topology.Add(LightningSubdivisionOp.JitterAndFork);
            ld.Topology.Add(LightningSubdivisionOp.Jitter);
            ld.Topology.Add(LightningSubdivisionOp.Jitter);
            ld.Topology.Add(LightningSubdivisionOp.JitterAndFork);
            ld.Topology.Add(LightningSubdivisionOp.Jitter);
            ld.Topology.Add(LightningSubdivisionOp.JitterAndFork);
            lightnings[0] = new LightningBolt(this, Vector3.Zero, Vector3.One,ld);

            LightningDescriptor ldElecticity = LightningDescriptor.ElectricityBolt;
            ldElecticity.ExteriorColor = Color.Crimson;
            lightnings[1] = new LightningBolt(this, new Vector3(-12, -10, 0), new Vector3(12, -10, 0), ldElecticity);

            lightnings[2] = new LightningBolt(this, new Vector3(-12, -10, 0), new Vector3(12, -10, 0), LightningDescriptor.ExamplePreset);



            LightningDescriptor ld2 = new LightningDescriptor();
            ld2.Topology.Clear();
  

            ld2.Topology.Add(LightningSubdivisionOp.Jitter);
            ld2.Topology.Add(LightningSubdivisionOp.Jitter);
            ld2.Topology.Add(LightningSubdivisionOp.Jitter);
            ld2.Topology.Add(LightningSubdivisionOp.Jitter);
            ld2.Topology.Add(LightningSubdivisionOp.JitterAndFork);

            ld2.ForkForwardDeviation = new Range(-1, 1);
            ld2.ForkLengthPercentage = 0.6f;
            ld2.ExteriorColor = Color.Orange;
            ld2.BaseWidth = 1.0f;
            ld2.JitterDeviationRadius = 0.5f;
            ld2.JitterDecayRate = 1.0f;
            ld2.IsGlowEnabled = true;
            ld2.GlowIntensity = 3.0f;
            lightnings[3] = new LightningBolt(this, new Vector3(0,12,0), new Vector3(0,-10,0), ld2);



            background = Content.Load<Texture2D>("sunset");
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {

            KeyboardState currentKeyState = Keyboard.GetState();
            GamePadState currentPadState = GamePad.GetState(PlayerIndex.One);

            if ((currentPadState.Buttons.Back == ButtonState.Pressed) ||
                currentKeyState.IsKeyDown(Keys.Escape))
                this.Exit();

            if (((currentPadState.Buttons.A == ButtonState.Pressed) &&
                  (lastPadState.Buttons.A == ButtonState.Released))
                ||
                (currentKeyState.IsKeyDown(Keys.Space) &&
                 lastKeyState.IsKeyUp(Keys.Space)
                ))
                currentItem = (currentItem + 1) % itemCount;

            if (((currentPadState.Buttons.B == ButtonState.Pressed) &&
                  (lastPadState.Buttons.B == ButtonState.Released))
                ||
                (currentKeyState.IsKeyDown(Keys.B) &&
                 lastKeyState.IsKeyUp(Keys.B)
                ))
                showBackground = !showBackground;

            lastKeyState = currentKeyState;
            lastPadState = currentPadState;

            
            bool freeze = ((currentPadState.Buttons.Y == ButtonState.Pressed) || currentKeyState.IsKeyDown(Keys.F));
            if (!freeze)
            {
                //randomize source and destination points
                lightnings[0].Destination = new Vector3(30.0f * (float)rand.NextDouble() - 15.0f, -10, 0);
                lightnings[0].Source = new Vector3(-5.0f + 10.0f * (float)rand.NextDouble(), 14, 0);
                
                double angle = gameTime.TotalGameTime.TotalSeconds;
                lightnings[3].Destination = 12.0f * new Vector3((float)Math.Sin(angle), (float)Math.Cos(angle),0);
                lightnings[3].Source = 12.0f * new Vector3((float)Math.Sin(angle + Math.PI), (float)Math.Cos(angle + Math.PI),0);
                lightnings[currentItem].Update(gameTime);
            }
            base.Update(gameTime);
        }

        Random rand = new Random();
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {

            //draw it in 2D
            Matrix viewMatrix = Matrix.CreateLookAt(new Vector3(0, 0, 10), new Vector3(0, 0, 0), new Vector3(0, 1, 0));
            Matrix projectionMatrix = Matrix.CreateOrthographic(GraphicsDevice.Viewport.Width / 20, GraphicsDevice.Viewport.Height / 20, 0.01f, 50);
            Matrix worldMatrix = Matrix.Identity;
       
            //generate the lightning rendering
            lightnings[currentItem].GenerateTexture(gameTime, worldMatrix, viewMatrix, projectionMatrix);

            Rectangle rect = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            
            GraphicsDevice.Clear(Color.Black);
            spriteBatch.Begin(SpriteBlendMode.Additive);
            if (showBackground)
                spriteBatch.Draw(background,rect,Color.White);
            //draw lightning texture over the scene
            spriteBatch.Draw(lightnings[currentItem].LightningTexture, rect, Color.White);
            spriteBatch.End();
                       
            

            base.Draw(gameTime);
        }
    }
}
