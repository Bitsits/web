// This file is included by SWTri.cpp and should not be built directly by the project.

#define TRI0 0
#define TRI1 0
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#define TRI1 1
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#undef TRI0
#define TRI0 1
#define TRI1 0
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#define TRI1 1
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#undef TRI0
#define TRI0 2
#define TRI1 0
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#define TRI1 1
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#undef TRI0
#define TRI0 3
#define TRI1 0
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#define TRI1 1
#define TRI2 0
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#define TRI2 1
#define TRI3 0
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#define TRI3 1
#define TRI4 0
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#define TRI4 1
#define TRI5 0
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#define TRI5 1
#include "SWTri_DrawTriangle.cpp"

#undef TRI5
#undef TRI4
#undef TRI3
#undef TRI2
#undef TRI1
#undef TRI0
