#include "DSoundManager.cpp" // build first because this defines DIRECTSOUND_VERSION to 0x0600

#include "DSoundInstance.cpp"
#include "BassLoader.cpp"
#include "BassMusicInterface.cpp"
#include "FModLoader.cpp"
#include "FModMusicInterface.cpp"
#include "FModSoundInstance.cpp"
#include "MusicInterface.cpp"
