#ifndef __DSOUNDVERSION_H__
#define __DSOUNDVERSION_H__

#define DIRECTSOUND_VERSION 0x0600
#include <dsound.h>

#endif