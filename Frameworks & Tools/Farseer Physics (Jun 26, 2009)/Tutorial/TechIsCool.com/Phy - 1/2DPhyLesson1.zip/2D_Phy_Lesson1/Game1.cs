using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using FarseerGames.FarseerPhysics;
using FarseerGames.FarseerPhysics.Collisions;
using FarseerGames.FarseerPhysics.Controllers;
using FarseerGames.FarseerPhysics.Dynamics;
using FarseerGames.FarseerPhysics.Factories;
using FarseerGames.FarseerPhysics.Interfaces;
using FarseerGames.FarseerPhysics.Mathematics;


namespace _2D_Phy_Lesson1
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        PhysicsSimulator phySim;
        Body ballBody;
        Geom ballGeom;

        Body platformOne;
        Geom platformOneGeo;

        Texture2D ballTex;
        Texture2D platformTex;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            ballTex = Content.Load<Texture2D>("Phy_ball");
            platformTex = Content.Load<Texture2D>("Phy_Platform");

            //Create the physics simulator
            phySim = new PhysicsSimulator(new Vector2(0, 200));

            //Create the ball body and geometry
            ballBody = BodyFactory.Instance.CreateCircleBody(22f, 2);
            ballBody.Position = new Vector2(250, 100);
            ballGeom = GeomFactory.Instance.CreateCircleGeom(phySim, ballBody, 22f, 16);

            //Create the platform body and geometry
            platformOne = BodyFactory.Instance.CreateRectangleBody(235, 64, 1);
            platformOne.IsStatic = true;
            platformOne.Position = new Vector2(250, 300);
            platformOne.Rotation = MathHelper.ToRadians(15f);
            platformOneGeo = GeomFactory.Instance.CreateRectangleGeom(phySim, platformOne, 235, 64f);

            //Add the objects to the simulator
            phySim.Add(ballBody);
            phySim.Add(ballGeom);

            phySim.Add(platformOne);
            phySim.Add(platformOneGeo);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();
            if (ballBody.Position.Y > GraphicsDevice.PresentationParameters.BackBufferHeight)
            {
                ballBody.Position = new Vector2(250, 100);
            }
            //Keyboard movement

            //THE APPLYIMPULSE WILL BE DESCUSED IN THE NEXT LESSON!
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                ballBody.ApplyImpulse(new Vector2(20, 0));
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                ballBody.ApplyImpulse(new Vector2(-20, 0));
            }

            //Update The Physics Sim
            phySim.Update(gameTime.ElapsedGameTime.Milliseconds * .001f);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            spriteBatch.Draw(ballTex, ballBody.Position, null, Color.White, ballBody.Rotation, new Vector2(32, 32), 1f, SpriteEffects.None, 1f);
            spriteBatch.Draw(platformTex, platformOne.Position, null, Color.White, platformOne.Rotation, new Vector2(117, 32), 1f, SpriteEffects.None, 1f);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
