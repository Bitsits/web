using System;
using System.Collections.Generic;
using Lidgren.Library.Network;
using Lidgren.Library.Network.Xna;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace XNARandyWalking
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        SpriteFont font;
        List<DrawInfo> info = new List<DrawInfo>();

        #region Randy
        private Texture2D imageRandy;
        private Vector2 tilePosition;
        private Vector2 oldTilePosition;
        private Vector2 tilePositionNetwork;
        private float maxSpeed = 220;
        private int columns = 8;
        private int rows = 4;
        private int framesPerSecond = 12;
        private int frameWidth;
        private int frameHeight;
        private float frameLength;
        private Rectangle[,] rectangles;
        private int oldRow = 2;
        private int currRow = 2;
        private int currRowNetwork = 2;
        private int currCol = 0;
        private float totalElapsedTime = 0;
        #endregion

        #region Networking
        private NetClient _client;
        private NetServer _server;
        private NetLog _log;
        private NetAppConfiguration _nac;
        #endregion


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            font = Content.Load<SpriteFont>("Courier New");
            imageRandy = Content.Load<Texture2D>("Randy");

            frameWidth = imageRandy.Width / columns;
            frameHeight = imageRandy.Height / rows;
            frameLength = 1.0f / framesPerSecond;

            graphics.PreferredBackBufferWidth = 300;
            graphics.PreferredBackBufferHeight = 300;
            graphics.ApplyChanges();


            tilePosition =
                new Vector2(graphics.GraphicsDevice.Viewport.Width / 2 - frameWidth / 2,
                            graphics.GraphicsDevice.Viewport.Height / 2 - frameHeight / 2);

            tilePositionNetwork = new Vector2(0, 0);


            rectangles = new Rectangle[rows, columns];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < columns; j++)
                {
                    rectangles[i, j] = new Rectangle(j * frameWidth, i * frameHeight, frameWidth, frameHeight);
                }
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            KeyboardState keyboard = Keyboard.GetState();

            if (_client != null || _server != null)
            {
                UpdateNetwork();
            }
            else
            {
                //We get the state of the keyboard at this moment which will hold keys pressed ect.
                //if the H key is pressed we call the HostClicked Routine.
                if (keyboard.IsKeyDown(Keys.H) || keyboard.IsKeyDown(Keys.S))
                {
                    HostClicked();
                }
                //If the C key is pressed we call the ClientClicked Routine
                if (keyboard.IsKeyDown(Keys.C))
                {
                    ClientClicked();
                }
            }

            float elapsedTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
            totalElapsedTime += elapsedTime;

            if (totalElapsedTime >= frameLength)
            {
                currCol++;
                currCol %= columns;
                totalElapsedTime %= frameLength;
            }

            if (keyboard.IsKeyDown(Keys.Up))
            {
                currRow = 3;
            }
            else if (keyboard.IsKeyDown(Keys.Down))
            {
                currRow = 2;
            }
            else if (keyboard.IsKeyDown(Keys.Left))
            {
                currRow = 1;
            }
            else if (keyboard.IsKeyDown(Keys.Right))
            {
                currRow = 0;
            }

            switch (currRow)
            {
                case 0:
                    tilePosition = new Vector2(
                        Math.Min(tilePosition.X + maxSpeed * elapsedTime,
                                 graphics.GraphicsDevice.Viewport.Width - frameWidth), tilePosition.Y);
                    break;
                case 1:
                    tilePosition = new Vector2(
                        Math.Max(tilePosition.X - maxSpeed * elapsedTime,
                                 0), tilePosition.Y);
                    break;
                case 2:
                    tilePosition = new Vector2(tilePosition.X,
                                               Math.Min(tilePosition.Y + maxSpeed * elapsedTime,
                                                        graphics.GraphicsDevice.Viewport.Height - frameHeight));
                    break;
                case 3:
                    tilePosition = new Vector2(tilePosition.X,
                                               Math.Max(tilePosition.Y - maxSpeed * elapsedTime,
                                                        0));
                    break;
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            foreach (DrawInfo drawInfo in info)
            {
                spriteBatch.DrawString(font, drawInfo.text,
                           drawInfo.pos, drawInfo.color);
            }

            spriteBatch.Draw(imageRandy, tilePosition, rectangles[currRow, currCol], Color.White);
            spriteBatch.Draw(imageRandy, tilePositionNetwork, rectangles[currRowNetwork, currCol], Color.LightPink);

            spriteBatch.End();

            base.Draw(gameTime);
        }

        public void HostClicked()
        {
            TextOut("Acting as Host", 20, 40, Color.Silver);

            //This sets up the configuration, when your setting the config up for server we pick the application name and the port that the server 
            //will bound to when we create it
            _nac = new NetAppConfiguration("XNARandyWalking", 12345);
            //set the maximum connects, im not sure the biggest number aloud at this moment in time
            _nac.MaximumConnections = 32;
            //This is used for somthing later on in the tutorials, where the client can discover hosts.
            _nac.ServerName = "XNARandyWalking!";
            //Initiate the log
            _log = new NetLog();
            //Create the server using the Log and the Configuration, this will bound the port on the computer.
            _server = new NetServer(_nac, _log);
            // Add an Event Handler for when a client connects or disconnects.
            _server.StatusChanged += new EventHandler<NetStatusEventArgs>(server_StatusChanged);
        }
        public void ClientClicked()
        {
            //this code if fairly the same as Server so i wont go into detail
            TextOut("Acting as Client", 20, 40, Color.Silver);

            _nac = new NetAppConfiguration("XNARandyWalking");
            _log = new NetLog();
            //Set it up so that the Log Igores Nothing
            _log.IgnoreTypes = NetLogEntryTypes.None;
            //We want to Output to file, this shows how to do so.
            _log.IsOutputToFileEnabled = true;
            //If we output to a file we need to big a name, this was simple
            _log.OutputFileName = "Client.html";
            _client = new NetClient(_nac, _log);
            _client.StatusChanged += new EventHandler<NetStatusEventArgs>(client_StatusChanged);
            //Once ready we set the Client to Connect to the LocalHost, Port 12345, 
            //if we wanted an IP we would do 
            //client.Connect("192.168.1.1",12345); ect.
            _client.Configuration.ApplicationIdentifier = "XNARandyWalking";
            _client.ServerDiscovered += new EventHandler<NetServerDiscoveredEventArgs>(_client_ServerDiscovered);
            _client.DiscoverKnownServer("localhost", 12345);
        }

        void _client_ServerDiscovered(object sender, NetServerDiscoveredEventArgs e)
        {
            if (e.ServerInformation.ServerName == "XNARandyWalking!")
                _client.Connect(e.ServerInformation.RemoteEndpoint.Address, e.ServerInformation.RemoteEndpoint.Port);
        }

        void client_StatusChanged(object sender, NetStatusEventArgs e)
        {
            //If the client has connected to the server
            if (e.Connection.Status == NetConnectionStatus.Connected)
            {
                TextOut("Client Connected", 20, 60, Color.Silver);
            }
            //If the Client was disconnected
            if (e.Connection.Status == NetConnectionStatus.Disconnected)
            {
                TextOut("Client Disconnected", 20, 80, Color.Silver);

            }
        }
        void server_StatusChanged(object sender, NetStatusEventArgs e)
        {
            if (e.Connection.Status == NetConnectionStatus.Connecting)
            {
                TextOut("Server Connected", 20, 60, Color.Silver);
            }
            if (e.Connection.Status == NetConnectionStatus.Disconnected)
            {
                TextOut("Server Disconnected", 20, 80, Color.Silver);
            }
        }
        //Called everytime the main games UpdateRoutine is called
        public void UpdateNetwork()
        {
            //If the client is chosen this will be called
            if (_client != null)
            {
                //Pump the client session with any new information sent or received
                _client.Heartbeat();
                //Initialize a new message
                NetMessage msg;
                //Message will continue you iterate though any messages received from the Server.
                while ((msg = _client.ReadMessage()) != null)
                {
                    //We Send the message of to be read and interpreted
                    HandleNetworkingMessage(msg);
                }

                if (currRow != oldRow || oldTilePosition != tilePosition)
                {
                    msg = new NetMessage();
                    msg.Write(currRow);
                    XnaSerialization.Write(msg, tilePosition);
                    _client.SendMessage(msg, NetChannel.ReliableUnordered);

                    oldRow = currRow;
                    oldTilePosition = tilePosition;
                }
            }
            //If the Server is chosen this will be called
            if (_server != null)
            {
                //The same as the client....
                _server.Heartbeat();
                NetMessage msg;

                while ((msg = _server.ReadMessage()) != null)
                {
                    HandleNetworkingMessage(msg);
                }

                msg = new NetMessage();
                msg.Write(currRow);
                XnaSerialization.Write(msg, tilePosition);

                foreach (NetConnection conn in _server.Connections)
                {
                    if (conn != null && conn.Status == NetConnectionStatus.Connected)
                        _server.SendMessage(msg, conn, NetChannel.ReliableUnordered);
                }

            }
        }
        public void HandleNetworkingMessage(NetMessage msg)
        {
            //We read the Messages
            try
            {
                currRowNetwork = msg.ReadInt();
                tilePositionNetwork = XnaSerialization.ReadVector2(msg);
            }
            catch (Exception)
            {
                throw;
            }

        }

        private void TextOut(string infoText, int x, int y, Color col)
        {
            DrawInfo drawText = new DrawInfo();
            drawText.pos = new Vector2(x, y);
            drawText.text = infoText;
            drawText.color = col;
            info.Add(drawText);
        }

    }
}
