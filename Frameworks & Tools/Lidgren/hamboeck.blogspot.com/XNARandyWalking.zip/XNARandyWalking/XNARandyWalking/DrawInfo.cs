using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XNARandyWalking
{
    class DrawInfo
    {
        public string text;
        public Vector2 pos;
        public Color color;
    }
}
