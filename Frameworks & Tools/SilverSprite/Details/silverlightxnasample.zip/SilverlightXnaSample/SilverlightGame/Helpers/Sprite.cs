﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using GameSample.Helpers;
using GameSample.Common;

namespace GameSample.Helpers
{
    public partial class Sprite : ISprite
    {
        string image;
        public SpriteView View;
        float X;
        float Y;

        public Sprite()
        {
            View = new SpriteView();
        }

        public Vector2 Position
        {
            get
            {
                return new Vector2(X, Y);
            }
            set
            {
                if (value.X != X)
                {
                    View.SetValue(Canvas.LeftProperty, (double)value.X);
                    X = value.X;
                }
                if (value.Y != Y)
                {
                    View.SetValue(Canvas.TopProperty, (double)value.Y);
                    Y = value.Y;
                }
            }
        }

        public Vector2 Velocity
        {
            get;
            set;
        }

        public string Image
        {
            get
            {
                return image;
            }
            set
            {
                image = value;
                View.Image = image;
            }
        }

        public object Tag
        {
            get;
            set;
        }

        public float Opacity
        {
            get
            {
                return (float)View.Opacity;
            }
            set
            {
                View.Opacity = (double)value;
            }
        }

        public float Rotation
        {
            get;
            set;
        }

        public float Scale
        {
            get;
            set;
        }
    }
}
