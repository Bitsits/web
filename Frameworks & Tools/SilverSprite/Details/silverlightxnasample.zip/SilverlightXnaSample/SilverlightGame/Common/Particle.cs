﻿using GameSample.Helpers;
using Microsoft.Xna.Framework;

namespace GameSample.Common
{
    public class Particle
    {
        public Sprite Sprite;
        double durationSeconds;
        double totalElapsed;

        float startOpacity;
        float endOpacity;

        public Particle(string imagename, Vector2 position, Vector2 velocity, double lifeSpanSeconds, float sOpacity, float eOpacity)
        {
            Sprite = new Sprite();
            Sprite.Position = position;
            Sprite.Velocity = velocity;
            durationSeconds = lifeSpanSeconds;
            startOpacity = sOpacity;
            endOpacity = eOpacity;
            Sprite.Image = imagename;
            Sprite.Tag = this;
            totalElapsed = 0;
        }

        public void Update(double elapsedSeconds)
        {
            totalElapsed += elapsedSeconds;
            if (totalElapsed < durationSeconds)
            {
                Sprite.Position += Sprite.Velocity * (float)elapsedSeconds;
                double pct = totalElapsed / durationSeconds;
                Sprite.Opacity = (float)(startOpacity + (endOpacity - startOpacity) * pct); 
            }
        }

        public bool Expired
        {
            get
            {
                return totalElapsed >= durationSeconds;
            }
        }
    }
}
