﻿using System.Windows.Controls;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System.Collections.Generic;
using GameSample.Helpers;
using System;

namespace GameSample.Common
{
    public class SpriteCollection
    {
        List<ISprite> sprites = new List<ISprite>();
#if ZUNE
        Matrix zuneTransform = Matrix.CreateScale(.5f) * Matrix.CreateRotationZ(MathHelper.PiOver2) * Matrix.CreateTranslation(new Vector3(240, 0, 0))  ;
#endif
#if SILVERLIGHT
        internal Canvas GameSurface;

        public SpriteCollection(Canvas gameSurface)
        {
            GameSurface = gameSurface;
        }
#else
        internal SpriteBatch SpriteBatch;

        public SpriteCollection(SpriteBatch spriteBatch)
        {
            SpriteBatch = spriteBatch;
        }
#endif

        public virtual void Add(ISprite sprite)
        {
            sprites.Add(sprite);
#if SILVERLIGHT
            Sprite s = sprite as Sprite;
            GameSurface.Children.Add(s.View);
#endif

        }

        public virtual void Remove(ISprite sprite)
        {
#if SILVERLIGHT
            Sprite s = sprite as Sprite;
            GameSurface.Children.Remove(s.View);
#endif
            sprites.Remove(sprite);
        }



        public void Draw(TimeSpan elapsed)
        {
#if !SILVERLIGHT
#if ZUNE
            SpriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.BackToFront, SaveStateMode.None, zuneTransform);
#else
            SpriteBatch.Begin();
#endif
            foreach (Sprite s in sprites)
            {
                SpriteBatch.Draw(s.ImageTexture, s.Position, s.DrawColor);
            }
            SpriteBatch.End();
#endif
        }
    }
}
