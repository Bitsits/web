﻿using GameSample.Helpers;
using Microsoft.Xna.Framework;

namespace GameSample.Common
{
    public interface ISprite
    {
        Vector2 Position
        {
            get;
            set;
        }

        Vector2 Velocity
        {
            get;
            set;
        }

        string Image
        {
            get;
            set;
        }

        object Tag
        {
            get;
            set;
        }

        float Opacity
        {
            get;
            set;
        }

        float Rotation
        {
            get;
            set;
        }

        float Scale
        {
            get;
            set;
        }


    }
}
