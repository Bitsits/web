﻿using System;
using GameSample.Helpers;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace GameSample.Common
{
    public class ParticleEngine
    {
        List<Particle> particles = new List<Particle>();
        SpriteCollection sprites;
        double timeSinceAdd = 0;
        Random rand = new Random();

        public ParticleEngine(SpriteCollection coll)
        {
            sprites = coll;
        }

        public void Add(Particle p)
        {
            particles.Add(p);
            sprites.Add(p.Sprite);
        }

        public void Update(TimeSpan elapsed)
        {
            List<Particle> expiredParticles = new List<Particle>(); 
            foreach (Particle p in particles)
            {
                p.Update(elapsed.TotalSeconds);
                if (p.Expired)
                {
                    expiredParticles.Add(p);
                }
            }
            foreach (Particle p in expiredParticles)
            {
                particles.Remove(p);
                sprites.Remove(p.Sprite);
            }
            timeSinceAdd += elapsed.TotalSeconds;
            while (timeSinceAdd > .05)
            {
                Particle p = new Particle("whitecircle", new Vector2(290, 210), new Vector2(rand.Next(500) - 250, rand.Next(500) - 250), 1, 1, 0);
                Add(p);
                timeSinceAdd -= .05;
            }

        }
    }
}
