﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using GameSample.Helpers;
using GameSample.Common;

namespace SilverlightGame
{
    public partial class Page : UserControl
    {
        DateTime lastUpdate = DateTime.Now;
        ParticleEngine engine;

        public Page()
        {
            InitializeComponent();
            SpriteCollection coll = new SpriteCollection(LayoutRoot);
            engine = new ParticleEngine(coll);
            Storyboard sb = new Storyboard();
            sb.SetValue(FrameworkElement.NameProperty, "gameLoop");
            this.Resources.Add("gameLoop", sb);
            sb.Completed += new EventHandler(sb_Completed);
            sb.Begin();
        }

        void sb_Completed(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            TimeSpan elapsed = now - lastUpdate;
            engine.Update(elapsed);
            lastUpdate = now;
            (sender as Storyboard).Begin();
        }
    }
}
