﻿using System;
using System.Collections.Generic;
using System.Text;
using GameSample.Common;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GameSample.Helpers
{
    public class Sprite : ISprite
    {

        public static ContentManager Content;
        Texture2D imageTexture;
        string image;
        float opacity;

        Color drawColor = Color.White;

        public Color DrawColor
        {
            get
            {
                return drawColor;
            }
        }

        public Texture2D ImageTexture
        {
            get
            {
                return imageTexture;
            }
        }

        #region ISprite Members

        public Vector2 Position
        {
            get;
            set;
        }

        public Vector2 Velocity
        {
            get;
            set;
        }

        public string Image
        {
            get
            {
                return image;
            }
            set
            {
                image = value;
                imageTexture = Content.Load<Texture2D>(image);
            }
        }

        public object Tag
        {
            get;
            set;
        }

        public float Opacity
        {
            get
            {
                return opacity;
            }
            set
            {
                opacity = value;
                byte o = (byte)(opacity * 255);
                drawColor = new Color(255, 255, 255, o);
            }
        }

        public float Rotation
        {
            get;
            set;
        }

        public float Scale
        {
            get;
            set;
        }

        #endregion
    }
}
