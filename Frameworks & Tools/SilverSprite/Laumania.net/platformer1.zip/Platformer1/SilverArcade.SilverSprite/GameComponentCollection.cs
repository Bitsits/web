﻿using System;
using System.Collections.Generic;

namespace SilverArcade.SilverSprite
{
    public sealed class GameComponentCollection : IList<GameComponent>
    {
        //Since our DrawOrder & UpdateOrder are independent, if we want to 
        //perform updates and draws in the correct order, we have two options
        // 1) Sort every cycle (slower, but simpler)
        // 2) Maintain Two Lists (a bit more complex and bug-prone, but more efficient) 

        List<GameComponent> _components = new List<GameComponent>();
        List<DrawableGameComponent> _drawableComponents = new List<DrawableGameComponent>();
        List<GameComponent> _tempUpdateableComponents = new List<GameComponent>();
        List<GameComponent> _tempDrawableComponents = new List<GameComponent>();
        //Used to decouple the sorting from the actual
        //update of the sort order.  Necessary since
        //the sort order can be updated while iterating 
        //throw a list.  We don't want to change the 
        //list at that time.
        bool _updateSortOrder = false;

        internal void Refresh()
        {
            if (_updateSortOrder)
            {
                _drawableComponents.Sort(SortDrawOrder);
                _components.Sort(SortUpdateOrder);
                _updateSortOrder = false;
            }
        }

        static int SortDrawOrder(DrawableGameComponent c1, DrawableGameComponent c2)
        {
            if (c1.DrawOrder == c2.DrawOrder)
                return 0;

            return (c1.DrawOrder < c2.DrawOrder) ? -1 : 1;
        }

        static int SortUpdateOrder(GameComponent gc1, GameComponent gc2)
        {
            if (gc1.UpdateOrder == gc2.UpdateOrder)
                return 0;

            return (gc1.UpdateOrder < gc2.UpdateOrder) ? -1 : 1;
        }


        public int IndexOf(GameComponent item)
        {
            return _components.IndexOf(item);
        }

        public void Insert(int index, GameComponent item)
        {
            _components.Insert(index, item);
            item.UpdateOrderChanged += item_Updated;
            item.Initialize();
            DrawableGameComponent dgc = item as DrawableGameComponent;
            if (dgc != null)
            {
                _drawableComponents.Add(dgc);
                dgc.DrawOrderChanged += item_Updated;
            }

            _updateSortOrder = true;
        }

        //Need to decouple the changing of the sort order from 
        //the actual changes to the properties.
        void item_Updated(object sender, EventArgs e)
        {
            _updateSortOrder = true;
        }

        public void RemoveAt(int index)
        {
            if(index > _components.Count - 1)
                throw new IndexOutOfRangeException();

            DrawableGameComponent removedComponent = _components[index] as DrawableGameComponent;

            if(removedComponent != null)
                _drawableComponents.Remove(removedComponent);

            _components.RemoveAt(index);
        }

        public bool Remove(GameComponent item)
        {
            if (item is DrawableGameComponent)
                _drawableComponents.Remove(item as DrawableGameComponent);

            return _components.Remove(item);
        }

        public GameComponent this[int index]
        {
            get
            {
                return _components[index];
            }
            set
            {
                _components[index] = value;
            }
        }

        public void Add(GameComponent item)
        {
            _components.Add(item);
            item.UpdateOrderChanged += item_Updated;
            item.Initialize();
            DrawableGameComponent dgc = item as DrawableGameComponent;

            if (dgc != null)
            {
                dgc.DrawOrderChanged += item_Updated;
                _drawableComponents.Add(dgc);
            }

            _updateSortOrder = true;
            Refresh();
        }

        public void Clear()
        {
            _components.Clear();
            _drawableComponents.Clear();
        }

        public bool Contains(GameComponent item)
        {
            return _components.Contains(item);
        }

        public void CopyTo(GameComponent[] array, int arrayIndex)
        {
            _components.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return _components.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public void Update(GameTime gameTime)
        {
            _tempUpdateableComponents.Clear();
            for (int i = 0; i < _components.Count; i++)
            {
                if (_components[i].Enabled)
                {
                    _tempUpdateableComponents.Add(_components[i]);
                }
            }
            foreach (GameComponent gc in _tempUpdateableComponents)
            {
                gc.Update(gameTime);
            }
            
            Refresh();
        }

        public void Draw(GameTime gameTime)
        {
            _tempDrawableComponents.Clear();
            for (int i = 0; i < _drawableComponents.Count; i++)
            {
                if (_drawableComponents[i].Enabled && _drawableComponents[i].Visible)
                {
                    _tempDrawableComponents.Add(_drawableComponents[i]);
                }
            }
            foreach (DrawableGameComponent dc in _tempDrawableComponents)
            {
                dc.Draw(gameTime);
            }

            Refresh();
        }

        public void Initialize()
        {
            foreach (GameComponent gc in _components)
            {
                gc.Initialize();
            }

            Refresh();
        }

        public IEnumerator<GameComponent> GetEnumerator()
        {
            return _components.GetEnumerator();
        }


        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return _components.GetEnumerator();
        }
    }
}
