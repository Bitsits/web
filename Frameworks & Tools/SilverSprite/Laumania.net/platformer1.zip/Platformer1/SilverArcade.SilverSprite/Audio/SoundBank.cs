﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverArcade.SilverSprite.Audio
{
    public class SoundBank : IDisposable
    {
        public SoundBank(AudioEngine parent, string path)
        {
        }

        public Cue GetCue(string cueName)
        {
            return new Cue();
        }

        #region IDisposable Members

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
