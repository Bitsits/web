using System;
using System.Collections.Generic;
using System.Text;

namespace SilverArcade.SilverSprite.Audio
{
    public enum AudioStopOptions
    {
        AsAuthored = 0,
        Immediate = 2,
    }
}
