﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Collections.Generic;
using System.Windows.Resources;
using System.IO;
using SilverArcade.SilverSprite.Content;
using SilverArcade.SilverSprite.Graphics;

namespace SilverArcade.SilverSprite.Audio
{
    public class SoundEffect
    {
        string _assetName;
        private float volume = 0.5f;
        List<SoundEffectInstance> sounds = new List<SoundEffectInstance>();
        StreamResourceInfo info;
        GraphicsDevice _graphics;
        static Dictionary<string, byte[]> soundBuffers = new Dictionary<string, byte[]>();

        public SoundEffect(ContentManager content, string assetName)
        {
            _assetName = assetName;
            if (soundBuffers.ContainsKey(assetName) == false)
            {
                info = Application.GetResourceStream(new Uri(_assetName + ".mp3", UriKind.Relative));
                if (info == null)
                {
                    info = Application.GetResourceStream(new Uri(_assetName + ".wma", UriKind.Relative));
                }

                if (info == null)
                    throw new ContentLoadException("Could not load audio asset: " + assetName + "\r\nSilverSprite only support MP3 and WMA audio assets.");
                byte[] b = new byte[info.Stream.Length];
                info.Stream.Read(b, 0, b.Length);
                info.Stream.Close();
                soundBuffers.Add(assetName, b);
            }

            _graphics = ((IGraphicsDeviceService)content.ServiceProvider.GetService(typeof(IGraphicsDeviceService))).GraphicsDevice;
        }


        public SoundEffectInstance Play(float volume, float pitch, float pan, bool loop)
        {            
            var effect = Play(volume);

            return effect;
        }

        public SoundEffectInstance Play()
        {
            // Play with default volume
            return Play(volume);
        }

        public SoundEffectInstance Play(float volume)
        {
            this.volume = volume;

            if (info == null) 
                return null;
            
            //TODO: Obviously sounds may have more than one media element...
            SoundEffectInstance s = null;
            foreach (SoundEffectInstance ele in sounds)
            {
                if (ele.MediaElement.CurrentState == MediaElementState.Stopped || ele.MediaElement.CurrentState == MediaElementState.Paused)
                {
                    s = ele;
                    break;
                }
            }

            if (s == null)
            {
                s = new SoundEffectInstance(new MediaElement());
                sounds.Add(s);
                _graphics.Root.Children.Add(s.MediaElement);
            }
            s.MediaElement.SetSource(new MemoryStream(soundBuffers[_assetName]));
            s.MediaElement.Volume = volume;
            s.MediaElement.Play();
            return s;
        }

        public SoundEffectInstance Play3D(AudioListener listener, AudioEmitter emitter)
        {
            throw new NotImplementedException();
        }

        public SoundEffectInstance Play3D(AudioListener listener, AudioEmitter emitter, Single volume, Single pitch, bool loop)
        {
            throw new NotImplementedException();
        }

        public SoundEffectInstance Play3D(AudioListener[] listeners, AudioEmitter emitter, Single volume, Single pitch, bool loop)
        {
            throw new NotImplementedException();
        }

        public string Name
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public TimeSpan Duration
        {
            get { throw new NotImplementedException(); }
        }
        public static Single MasterVolume
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public static Single SpeedOfSound
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }
        
        public static Single DopplerScale
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public static Single DistanceScale
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }
    }
}
