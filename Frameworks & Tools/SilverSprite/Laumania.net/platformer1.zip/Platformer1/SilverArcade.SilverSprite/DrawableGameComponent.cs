﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverArcade.SilverSprite
{
    public class DrawableGameComponent : GameComponent, IDrawable
    {
        private bool _isVisible;
        private int _drawOrder;

        public event EventHandler DrawOrderChanged;        
        public event EventHandler VisibleChanged;

        public DrawableGameComponent(Game game)
            : base(game)
        {
            Visible = true;
        }

        #region IDrawable Members

        public int DrawOrder
        {
            get{return _drawOrder;}
            set
            {
                _drawOrder = value;
                if(DrawOrderChanged != null)
                    DrawOrderChanged(this, null);

                OnDrawOrderChanged(this, null);
            }
        }

        public bool Visible
        {
            get{return _isVisible;}
            set
            {
                _isVisible = value;
                
                if(VisibleChanged != null)
                    VisibleChanged(this, null);

                OnVisibleChanged(this, null);
            }
             
        }

        public virtual void Draw(GameTime gameTime)
        {
        }

        protected virtual void OnVisibleChanged(object sender, EventArgs args)
        {
        }

        protected virtual void OnDrawOrderChanged(object sender, EventArgs args)
        {
        }
        #endregion
    }
}
