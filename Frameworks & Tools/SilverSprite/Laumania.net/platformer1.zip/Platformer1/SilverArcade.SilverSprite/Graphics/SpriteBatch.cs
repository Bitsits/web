﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Text;
using System.Linq;

#if USE_FARSEER
using FarseerGames.FarseerPhysics.Mathematics;
#endif

namespace SilverArcade.SilverSprite.Graphics
{
    public class SpriteBatch : IDisposable
    {
        internal static List<SpriteBatch> SpriteBatches = new List<SpriteBatch>();
        GraphicsDevice _graphicsDevice;
        List<SpriteBatchCanvas> canvases = new List<SpriteBatchCanvas>();
        internal int canvasIndex = 0;
        internal static int canvasZIndex = 0;
        SpriteBatchCanvas currentCanvas = null;
        DrawCommandQueue _commands = new DrawCommandQueue();
        SpriteSortMode currentSortMode;
        static double _globalRenderAtScale = 1;
        static bool _globalBitmapCacheEnabled = false;
        double _renderAtScale = 1;
        bool _bitmapCacheEnabled = false;

        public void HideUnused()
        {
            foreach (SpriteBatchCanvas c in canvases)
            {
                c.Visible = c.InUse;
            }
        }

        public void Begin(SpriteBlendMode blendMode)
        {
            currentCanvas = GetCanvas();
            currentCanvas.Begin();
            currentCanvas.InUse = true;
            currentSortMode = SpriteSortMode.Deferred;
            _commands.Reset();
        }

        public void Begin(SpriteBlendMode blendMode, SpriteSortMode sortMode, SaveStateMode stateMode)
        {
            Begin();
            currentSortMode = sortMode;
        }

        public void Begin(SpriteBlendMode blendMode, SpriteSortMode sortMode, SaveStateMode stateMode, Matrix transformMatrix)
        {
            //TODO: Full XNA Library throws an exception if Begin is called before calling End of the previous session.

            currentCanvas = GetCanvas();
            currentCanvas.Begin();
            currentCanvas.TransformMatrix = transformMatrix;
            currentCanvas.InUse = true;
            currentSortMode = sortMode;
            _commands.Reset();
        }

        SpriteBatchCanvas GetCanvas()
        {
            SpriteBatchCanvas c;
            if (canvasIndex >= canvases.Count)
            {
                c = new SpriteBatchCanvas();
                c.BitmapCacheEnabled = _bitmapCacheEnabled;
                c.RenderAtScale = _renderAtScale;
                canvases.Add(c);
                canvasIndex++;
                _graphicsDevice.Root.Children.Add(c.Canvas);
            }
            else
            {
                c = canvases[canvasIndex];
                canvasIndex++;
            }
            c.Canvas.SetValue(Canvas.ZIndexProperty, canvasZIndex);
            canvasZIndex++;
            return c;
        }

        public static void Reset()
        {
            canvasZIndex = 0;
            foreach (SpriteBatch sb in SpriteBatch.SpriteBatches)
            {
                sb.InUse = false;
                sb.canvasIndex = 0;
            } 
        }

        public bool InUse
        {
            get
            {
                foreach (SpriteBatchCanvas canvas in canvases)
                {
                    if (canvas.InUse) return true;
                }
                return false;
            }
            set
            {
                foreach (SpriteBatchCanvas canvas in canvases)
                {
                    canvas.InUse = value;
                }
            }
        }

        public void Begin()
        {
            Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.None, Matrix.Identity);
        }

        public void End()
        {
            // if SpriteSortMode isn't immediate, do some Linq here to get the reight sorting.
            if (currentSortMode == SpriteSortMode.Immediate || currentSortMode == SpriteSortMode.Deferred || currentSortMode == SpriteSortMode.Texture)
            {
                for (int i = 0; i < _commands.CommandCount; i++)
                {
                    currentCanvas.Draw(_commands[i]);
                }
            }
            else if (currentSortMode == SpriteSortMode.FrontToBack)
            {
                var query = from command in _commands.AsQueryable<DrawCommand>().Take<DrawCommand>(_commands.CommandCount)
                            orderby command.LayerDepth select command;

                foreach (DrawCommand cmd in query)
                {
                    currentCanvas.Draw(cmd);
                }
            }
            else if (currentSortMode == SpriteSortMode.BackToFront)
            {
                var query = from command in _commands.AsQueryable<DrawCommand>().Take<DrawCommand>(_commands.CommandCount)
                            orderby command.LayerDepth descending
                            select command;

                foreach (DrawCommand cmd in query)
                {
                    currentCanvas.Draw(cmd);
                }
            }
            currentCanvas.End();
        }

        public GraphicsDevice GraphicsDevice
        {
            get
            {
                return _graphicsDevice;
            }
        }

        public SpriteBatch(GraphicsDevice graphicsDevice)
        {
            _graphicsDevice = graphicsDevice;
            RenderAtScale = _globalRenderAtScale;
            BitmapCacheEnabled = _globalBitmapCacheEnabled;
            SpriteBatches.Add(this);
        }

        public void DrawString(SpriteFont spriteFont, string text, Vector2 position, Color color, float rotation, Vector2 origin, float scale, SpriteEffects effects, float layerDepth)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.String;
            cmd.Font = spriteFont;
            cmd.Text = text;
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = rotation;
            cmd.Origin = origin;
            cmd.Scale = new Vector2(scale, scale);
            cmd.Effects = effects;
            cmd.LayerDepth = layerDepth;
        }

        public void DrawString(SpriteFont spriteFont, string text, Vector2 position, Color color)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.String;
            cmd.Font = spriteFont;
            cmd.Text = text;
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = 0;
            cmd.Origin = Vector2.Zero;
            cmd.Scale = Vector2.One;
            cmd.Effects = SpriteEffects.None;
            cmd.LayerDepth = 0;
        }

        public void DrawString(SpriteFont spriteFont, StringBuilder text, Vector2 position, Color color)
        {
            DrawString(spriteFont, text.ToString(), position, color);
        }

        public void DrawString(SpriteFont spriteFont, string text, Vector2 position, Color color, float rotation, Vector2 origin, Vector2 scale, SpriteEffects effects, float layerDepth)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.String;
            cmd.Font = spriteFont;
            cmd.Text = text;
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = rotation;
            cmd.Origin = origin;
            cmd.Scale = scale;
            cmd.Effects = effects;
            cmd.LayerDepth = layerDepth;
        }

        public void DrawString(SpriteFont spriteFont, StringBuilder text, Vector2 position, Color color, float rotation, Vector2 origin, Vector2 scale, SpriteEffects effects, float layerDepth)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.String;
            cmd.Font = spriteFont;
            cmd.Text = text.ToString();
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = rotation;
            cmd.Origin = origin;
            cmd.Scale = scale;
            cmd.Effects = effects;
            cmd.LayerDepth = layerDepth;
        }

        public void DrawString(SpriteFont spriteFont, StringBuilder text, Vector2 position, Color color, float rotation, Vector2 origin, float scale, SpriteEffects effects, float layerDepth)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.String;
            cmd.Font = spriteFont;
            cmd.Text = text.ToString();
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = rotation;
            cmd.Origin = origin;
            cmd.Scale = new Vector2(scale, scale);
            cmd.Effects = effects;
            cmd.LayerDepth = layerDepth;
        }

        public void Draw(Texture2D texture, Vector2 position, Rectangle? sourceRectangle, Color color, float rotation, Vector2 origin, float scale, SpriteEffects effects, float layerDepth)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.Texture;
            cmd.Texture = texture;
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = rotation;
            cmd.Origin = origin;
            if (sourceRectangle != null)
            {
                cmd.SourceRectangle = sourceRectangle.Value;
            }
            else
            {
                cmd.SourceRectangle = texture.SourceRect;
            } 
            cmd.Scale = new Vector2(scale, scale);
            cmd.Effects = effects;
            cmd.LayerDepth = layerDepth;
        }

        public void Draw(Texture2D texture, Vector2 position, Rectangle? sourceRectangle, Color color)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.Texture;
            cmd.Texture = texture;
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = 0;
            cmd.Origin = Vector2.Zero;
            cmd.Scale = Vector2.One;
            cmd.Effects = SpriteEffects.None;
            cmd.LayerDepth = 0;
            if (sourceRectangle != null)
            {
                cmd.SourceRectangle = sourceRectangle.Value;
            }
            else
            {
                cmd.SourceRectangle = texture.SourceRect;
            }
        }

        public void Draw(Texture2D texture, Rectangle destinationRectangle, Rectangle? sourceRectangle, Color color)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.Texture;
            cmd.Texture = texture;
            cmd.Position = new Vector2(destinationRectangle.X, destinationRectangle.Y);
            cmd.Color = color;
            cmd.Rotation = 0;
            cmd.Origin = Vector2.Zero;
            if (sourceRectangle != null)
            {
                cmd.SourceRectangle = sourceRectangle.Value;
            }
            else
            {
                cmd.SourceRectangle = texture.SourceRect;
            }
            float scaleX = destinationRectangle.Width / (float)cmd.SourceRectangle.Width;
            float scaleY = destinationRectangle.Height / (float)cmd.SourceRectangle.Height;
            cmd.Scale = new Vector2(scaleX, scaleY);
            cmd.Effects = SpriteEffects.None;
            cmd.LayerDepth = 0;
        }

        public void Draw(Texture2D texture, Rectangle destinationRectangle, Color color)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.Texture;
            cmd.Texture = texture;
            cmd.Position = new Vector2(destinationRectangle.X, destinationRectangle.Y);
            cmd.Color = color;
            cmd.Rotation = 0;
            cmd.Origin = Vector2.Zero;
            cmd.SourceRectangle = texture.SourceRect;
            float scaleX = destinationRectangle.Width / (float)cmd.SourceRectangle.Width;
            float scaleY = destinationRectangle.Height / (float)cmd.SourceRectangle.Height;
            cmd.Scale = new Vector2(scaleX, scaleY);
            cmd.Effects = SpriteEffects.None;
            cmd.LayerDepth = 0;
        }

        public void Draw(Texture2D texture, Vector2 position, Color color)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.Texture;
            cmd.Texture = texture;
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = 0;
            cmd.Origin = Vector2.Zero;
            cmd.SourceRectangle = texture.SourceRect;
            cmd.Scale = Vector2.One;
            cmd.Effects = SpriteEffects.None;
            cmd.LayerDepth = 0;
        }

        public void Draw(Texture2D texture, Vector2 position, Rectangle? sourceRectangle, Color color, float rotation, Vector2 origin, Vector2 scale, SpriteEffects effects, float layerDepth)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.Texture;
            cmd.Texture = texture;
            cmd.Position = position;
            cmd.Color = color;
            cmd.Rotation = rotation;
            cmd.Origin = origin;
            if (sourceRectangle != null)
            {
                cmd.SourceRectangle = sourceRectangle.Value;
            }
            else
            {
                cmd.SourceRectangle = texture.SourceRect;
            }
            cmd.Scale = scale;
            cmd.Effects = effects;
            cmd.LayerDepth = layerDepth;
        }

        public void Draw(Texture2D texture, Rectangle destinationRectangle, Rectangle? sourceRectangle, Color color, float rotation, Vector2 origin, SpriteEffects effects, float layerDepth)
        {
            DrawCommand cmd = _commands.GetNextAvailable();
            cmd.CommandType = DrawCommand.DrawCommandType.Texture;
            cmd.Texture = texture;
            cmd.Position = new Vector2(destinationRectangle.X, destinationRectangle.Y);
            cmd.Color = color;
            cmd.Rotation = rotation;
            cmd.Origin = origin;
            if (sourceRectangle != null)
            {
                cmd.SourceRectangle = sourceRectangle.Value;
            }
            else
            {
                cmd.SourceRectangle = texture.SourceRect;
            }
            float scaleX = destinationRectangle.Width / (float)cmd.SourceRectangle.Width;
            float scaleY = destinationRectangle.Height / (float)cmd.SourceRectangle.Height;
            cmd.Scale = new Vector2(scaleX, scaleY);
            cmd.Effects = effects;
            cmd.LayerDepth = layerDepth;
        }

        static public void SetGlobalBitmapCache(bool cacheEnabled, double renderAtScale)
        {
            _globalBitmapCacheEnabled = cacheEnabled;
            _globalRenderAtScale = renderAtScale;
            foreach (SpriteBatch s in SpriteBatches)
            {
                s.RenderAtScale = renderAtScale;
                s.BitmapCacheEnabled = cacheEnabled;
            }
        }

        public double RenderAtScale
        {
            get
            {
                return _renderAtScale;
            }
            set
            {
                _renderAtScale = value;
                foreach (SpriteBatchCanvas c in canvases)
                {
                    c.RenderAtScale = value;
                }
            }
        }

        public bool BitmapCacheEnabled
        {
            get
            {
                return _bitmapCacheEnabled;
            }
            set
            {
                _bitmapCacheEnabled = value;
                foreach (SpriteBatchCanvas c in canvases)
                {
                    c.BitmapCacheEnabled = value;
                }
            }
        }

        #region IDisposable Members

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
