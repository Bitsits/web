﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
#if USE_FARSEER
using FarseerGames.FarseerPhysics.Mathematics;
#endif


namespace SilverArcade.SilverSprite.Graphics
{
    public class Viewport
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        public Single MinDepth
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public Single MaxDepth
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public Vector3 Project(Vector3 source, Matrix projection, Matrix view, Matrix world)
        {
            throw new NotImplementedException();
        }

        public Vector3 Unproject(Vector3 source, Matrix projection, Matrix view, Matrix world)
        {
            throw new NotImplementedException();
        }

        public Single AspectRation
        {
            get { throw new NotImplementedException(); }
        }

        public Rectangle TitleSafeArea
        {
            //Implemented by Laumania.net - No clue if it will work properly :)
            get { return new Rectangle(this.X,this.Y,this.Width,this.Height); }
        }
    }
}
