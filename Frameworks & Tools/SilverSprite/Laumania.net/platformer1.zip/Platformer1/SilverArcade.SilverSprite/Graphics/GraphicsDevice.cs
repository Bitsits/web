﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using Media = System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media;
using SilverArcade.SilverSprite.Input;

namespace SilverArcade.SilverSprite.Graphics
{
    public class GraphicsDevice
    {
        System.Windows.Media.SolidColorBrush backgroundBrush;
        Color background;
        Canvas root;
        Viewport _viewport;

        public event EventHandler Disposing;
        public event EventHandler DeviceResetting;
        public event EventHandler DeviceReset;
        public event EventHandler DeviceLost;
        public event EventHandler ResourceCreated;
        public event EventHandler ResourceDestroyed;
       
        internal GraphicsDeviceManager GraphicsDeviceManager
        {
            set;
            get;
        }

        public GraphicsDevice()
        {
            _viewport = new Viewport();
            RenderState = new RenderState();
        }

        internal void Initialize()
        {
        }

        public Viewport Viewport
        {
            get
            {
                return _viewport;
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public Canvas Root
        {
            get
            {
                return root;
            }
            set
            {
                root = value;
                background = Color.CornflowerBlue;
                backgroundBrush = new System.Windows.Media.SolidColorBrush(background.ToSilverlightColor());
                root.Background = backgroundBrush;
                Application.Current.RootVisual.MouseLeftButtonDown += new MouseButtonEventHandler(root_MouseLeftButtonDown);
                Application.Current.RootVisual.MouseLeftButtonUp += new MouseButtonEventHandler(root_MouseLeftButtonUp);
                Application.Current.RootVisual.MouseMove += new MouseEventHandler(root_MouseMove);
            }
        }

        void root_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                System.Windows.Point p = e.GetPosition(root);
                Mouse.X = (int)p.X;
                Mouse.Y = (int)p.Y;
            }
            catch
            {
            }
        }

        void root_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Mouse.LeftButtonDown = false;
        }

        void root_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Mouse.LeftButtonDown = true;
        }

        public void Clear(Color color)
        {
            if (color != background)
            {
                root.Background = new SolidColorBrush(color.ToSilverlightColor());
                background = color;
            }
        }

        public bool SynchronizeWithVerticalRetrace
        {
            get;
            set;
        }

        public RenderState RenderState
        {
            get;
            set;
        }

        public PresentationParameters PresentationParameters
        {
            get;
            set;
        }
        public GraphicsDeviceCreationParameters CreationParameters
        {
            get;
            set;
        }

        public void Clear(ClearOptions options, Vector4 color, Single depth, int stencil)
        {
            throw new NotImplementedException();
        }

        public void Clear(ClearOptions options, Vector4 color, Single depth, int stencil, Rectangle[] regions)
        {
            throw new NotImplementedException();
        }

        public void Clear(ClearOptions options, Color color, Single depth, int stencil)
        {
            throw new NotImplementedException();
        }

        public void Clear(ClearOptions options, Color color, Single depth, int stencil, Rectangle[] regions)
        {
            throw new NotImplementedException();
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }

        public void Reset(PresentationParameters presentationParameters)
        {
            throw new NotImplementedException();
        }

        public void Reset(GraphicsAdapter graphicsAdapter)
        {
            throw new NotImplementedException();
        }

        public void Reset(PresentationParameters presentationParameters, GraphicsAdapter graphicsAdapter)
        {
            throw new NotImplementedException();
        }

        public DisplayMode DisplayMode
        {
            get { throw new NotImplementedException(); }
        }

        public GraphicsDeviceCapabilities GraphicsDeviceCapabilities
        {
            get { throw new NotImplementedException(); }
        }

        		public void  Present(IntPtr overrideWindowHandle)
		{
			throw new NotImplementedException();
		}

                public void Present(Rectangle? sourceRectangle, Rectangle? destinationRectangle, IntPtr overrideWindowHandle)
		{
			throw new NotImplementedException();
		}

		public void  Present()
		{
			throw new NotImplementedException();
		}



    }
}
