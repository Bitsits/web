﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverArcade.SilverSprite.Shaders;

namespace SilverArcade.SilverSprite.Graphics
{
    public class ClippedSpriteImage : Sprite
    {
        TranslateTransform translate;
        System.Windows.Shapes.Rectangle rectangle;
        Texture2D texture;
        Color color;
        protected ImageBrush brush;
        Rectangle sourceRectangle;
        TintEffect tintEffect;

        public virtual Texture2D Texture2D
        {
            get
            {
                return texture;
            }
            set
            {
                texture = value;
                if (value.VectorGraphic != null)
                {                    
                    Element = value.CloneVectorGraphic();
                    brush = null;
                }
                else
                    brush.ImageSource = value.ImageSource;
            }
        }

        public Color Color
        {
            get
            {
                return color;
            }
            set
            {
                if (color != value)
                {
                    if (value == Color.White)
                    {
                        rectangle.Effect = null;
                        tintEffect = null;
                    }
                    else
                    {
                        if (tintEffect == null)
                        {
                            tintEffect = new TintEffect();
                            rectangle.Effect = tintEffect;
                        }
                        tintEffect.Color = System.Windows.Media.Color.FromArgb(value.A, value.R, value.G, value.B);
                    }
                    color = value;
                }
            }
        }

        public ClippedSpriteImage() : base()
        {
            rectangle = new System.Windows.Shapes.Rectangle();
            brush = new ImageBrush();
            brush.Stretch = Stretch.None;
            translate = new TranslateTransform();
            brush.AlignmentX = AlignmentX.Left;
            brush.AlignmentY = AlignmentY.Top;
            brush.Transform = translate;
            rectangle.Fill = brush;
            Element = rectangle;
        }

        public Rectangle SourceRectangle
        {
            get
            {
                return sourceRectangle;
            }
            set
            {
                if (sourceRectangle.X != value.X ||
                    sourceRectangle.Y != value.Y)
                {
                    translate.X = -value.X;
                    translate.Y = -value.Y;
                }
                if (sourceRectangle.Width != value.Width ||
                    sourceRectangle.Height != value.Height)
                {
                    rectangle.Width = value.Width;
                    rectangle.Height = value.Height;
                }
                sourceRectangle = value;
            }
        }
    }
}
