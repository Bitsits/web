﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverArcade.SilverSprite.Input
{
    public class MouseState
    {
        int x;
        int y;
        ButtonState left;
        ButtonState right;

        public int X
        {
            get
            {
                return x;
            }
            internal set
            {
                x = value;
            }
        }

        public int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        public ButtonState LeftButton
        {
            get
            {
                return left;
            }
            internal set
            {
                left = value;
            }
        }

        public ButtonState RightButton
        {
            get
            {
                return right;
            }
            internal set
            {
                right = value;
            }
        }
    
    }
}
