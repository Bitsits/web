﻿#region License
/*
MIT License
Copyright � 2006 The Mono.Xna Team

All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#endregion License

using System.Collections.Generic;
using SWI = System.Windows.Input;
using System;

namespace SilverArcade.SilverSprite.Input
{
    public struct KeyboardState
    {
        #region Private Fields

        Keys[] pressed;

        static Dictionary<Keys, SWI.Key> keyXref;
        #endregion Private Fields


        public void Update()
        {
            keyXref = null;
            PopulateXref();
            pressed = GetPressedKeys();
        }


        #region Public Methods


        public Keys[] GetPressedKeys()
        {
            if (keyXref == null)
            {
                PopulateXref();
            }
            List<Keys> keysDown = new List<Keys>();
            foreach (KeyValuePair<Keys, SWI.Key> kp in keyXref)
            {
                if (Game.KeyHandler.IsKeyPressed(kp.Value))
                {
                    keysDown.Add(kp.Key);
                }
            }

            return keysDown.ToArray();
        }

        static void PopulateXref()
        {
            keyXref = new Dictionary<Keys, System.Windows.Input.Key>();
            keyXref.Add(Keys.A, SWI.Key.A);
            keyXref.Add(Keys.B, SWI.Key.B);
            keyXref.Add(Keys.C, SWI.Key.C);
            keyXref.Add(Keys.D, SWI.Key.D);
            keyXref.Add(Keys.E, SWI.Key.E);
            keyXref.Add(Keys.F, SWI.Key.F);
            keyXref.Add(Keys.G, SWI.Key.G);
            keyXref.Add(Keys.H, SWI.Key.H);
            keyXref.Add(Keys.I, SWI.Key.I);
            keyXref.Add(Keys.J, SWI.Key.J);
            keyXref.Add(Keys.K, SWI.Key.K);
            keyXref.Add(Keys.L, SWI.Key.L);
            keyXref.Add(Keys.M, SWI.Key.M);
            keyXref.Add(Keys.N, SWI.Key.N);
            keyXref.Add(Keys.O, SWI.Key.O);
            keyXref.Add(Keys.P, SWI.Key.P);
            keyXref.Add(Keys.Q, SWI.Key.Q);
            keyXref.Add(Keys.R, SWI.Key.R);
            keyXref.Add(Keys.S, SWI.Key.S);
            keyXref.Add(Keys.T, SWI.Key.T);
            keyXref.Add(Keys.U, SWI.Key.U);
            keyXref.Add(Keys.V, SWI.Key.V);
            keyXref.Add(Keys.W, SWI.Key.W);
            keyXref.Add(Keys.X, SWI.Key.X);
            keyXref.Add(Keys.Y, SWI.Key.Y);
            keyXref.Add(Keys.Z, SWI.Key.Z);
            keyXref.Add(Keys.Up, SWI.Key.Up);
            keyXref.Add(Keys.Down, SWI.Key.Down);
            keyXref.Add(Keys.Left, SWI.Key.Left);
            keyXref.Add(Keys.Right, SWI.Key.Right);
            keyXref.Add(Keys.Enter, SWI.Key.Enter);
            keyXref.Add(Keys.Space, SWI.Key.Space);
            keyXref.Add(Keys.Back, SWI.Key.Back);
            keyXref.Add(Keys.Delete, SWI.Key.Delete);
            keyXref.Add(Keys.Escape, SWI.Key.Escape);

            keyXref.Add(Keys.D0, SWI.Key.D0);
            keyXref.Add(Keys.D1, SWI.Key.D1);
            keyXref.Add(Keys.D2, SWI.Key.D2);
            keyXref.Add(Keys.D3, SWI.Key.D3);
            keyXref.Add(Keys.D4, SWI.Key.D4);
            keyXref.Add(Keys.D5, SWI.Key.D5);
            keyXref.Add(Keys.D6, SWI.Key.D6);
            keyXref.Add(Keys.D7, SWI.Key.D7);
            keyXref.Add(Keys.D8, SWI.Key.D8);
            keyXref.Add(Keys.D9, SWI.Key.D9);
        }

        internal static bool IsKeyWatched(Keys key)
        {
            if (keyXref == null)
            {
                PopulateXref();
            }

            return keyXref.ContainsKey(key);
        }

        public bool IsKeyDown(Keys key)
        {
            if (pressed != null)
            {
                foreach (Keys k in pressed)
                {
                    if (k == key) return true;
                }
            }
            return false;
        }




        public bool IsKeyUp(Keys key)
        {
            return !IsKeyDown(key);
        }

        #endregion

        public KeyboardState Clone()
        {
            KeyboardState state = new KeyboardState();
            if(this.pressed != null)
                state.pressed = (Keys[])this.pressed.Clone();
           
            return state;
        }
    }
}