﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverArcade.SilverSprite.Content;
using SilverArcade.SilverSprite.Graphics;
using SilverArcade.SilverSprite.Input;
using System.Collections.Generic;

namespace SilverArcade.SilverSprite
{
    public class Game : Canvas
    {
        public event System.EventHandler Exiting;
        GraphicsDevice graphicsDevice;
        GameTime updateGameTime;
        GameTime drawGameTime;
        DateTime lastUpdate;
        bool _initialized = false;
        public static KeyHandler KeyHandler = null;
        GameComponentCollection _gameComponentCollection = new GameComponentCollection();
        Storyboard sb = new Storyboard();
        public GameServiceContainer _services = new GameServiceContainer();
        ContentManager _content;
        GameWindow _window;
        TimeSpan _targetElapsedTime;
        TimeSpan _timeSinceLast = TimeSpan.Zero;
        States _currentState = States.Idle;
        private enum States
        {
            Idle,
            Startup,
            Running,
            Done
        }

        public void MapKeyboardToGamePadButton(Buttons b, Keys k)
        {
            GamePadState.MapKey(b, k);
        }

        public void AddFont(string fontName, string fontFamily)
        {
            FontFamily f = new FontFamily(fontFamily);
            TextBlock t = new TextBlock();
            this.Children.Add(t);
            t.FontFamily = f;
            SpriteFont.AddFont(fontName, f);
        }

        public bool IsActive
        {
            get
            {
                return true;
            }
        }

        public bool IsMouseVisible
        {
            get;
            set;
        }

        public TimeSpan TargetElapsedTime
        {
            get
            {
                return _targetElapsedTime;
            }
            set
            {
                _targetElapsedTime = value;
            }
        }

        public bool IsFixedTimeStep
        {
            get;
            set;
        }

        public GameWindow Window
        {
            get
            {
                return _window;
            }
        }

        public GameServiceContainer Services
        {
            get
            {
                return _services;
            }
        }

        public Game()
        {
            
            GamePadState.Initialize();
            _window = new SilverlightGameWindow(this) as GameWindow;
  //          CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
            updateGameTime = new GameTime();
            drawGameTime = new GameTime();
            lastUpdate = DateTime.Now;
            _targetElapsedTime = TimeSpan.FromTicks(0x28b0bL);
            sb.Completed += new EventHandler(sb_Completed);
            this.Loaded += new RoutedEventHandler(Game_Loaded);
            _currentState = States.Startup;
        }

        void Game_Loaded(object sender, RoutedEventArgs e)
        {
            GraphicsDevice.Root = this;
            sb.Begin();
        }


        protected virtual void OnExiting(object sender, EventArgs e)
        {
        }
        protected virtual void BeginRun() { }

        void sb_Completed(object sender, EventArgs e)
        {
            if (_currentState != States.Done)
            { 
                Tick();
                sb.Begin();
            }
        }

        void Tick()
        {
            if (!_initialized)
            {
                GraphicsDevice.GraphicsDeviceManager.ApplyChanges();
                Initialize();
                RectangleGeometry r = new RectangleGeometry();
                r.Rect = new Rect(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                GraphicsDevice.Root.Clip = r;
                _initialized = true;
                if (KeyHandler == null)
                {
                    KeyHandler = new KeyHandler(Application.Current.RootVisual as FrameworkElement);
                }
                _currentState = States.Running;
                BeginRun();
            }
            SilverArcade.SilverSprite.Input.Keyboard.Update();
            SilverArcade.SilverSprite.Input.Mouse.Update();

            DateTime now = DateTime.Now;
            if (IsFixedTimeStep)
            {
                _timeSinceLast += now - lastUpdate;
                while (_timeSinceLast >= _targetElapsedTime)
                {
                    updateGameTime.Update(_targetElapsedTime);
                    _timeSinceLast -= _targetElapsedTime;
                    Update(updateGameTime);
                }
            }
            else
            {
                updateGameTime.Update(now - lastUpdate);
                Update(updateGameTime);
            }

            SpriteBatch.Reset();
            drawGameTime.Update(now - lastUpdate);
            lastUpdate = now;
            Draw(drawGameTime);
            foreach (SpriteBatch sb in SpriteBatch.SpriteBatches)
            {
                sb.HideUnused();
            }

        }

        void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            Tick();
        }

        public ContentManager Content
        {
            get
            {
                if (_content == null)
                {
                    _content = new ContentManager(_services);                   
                }
                return _content;
            }
        }

        public GraphicsDevice GraphicsDevice
        {
            get
            {
                if (graphicsDevice == null)
                {
                    graphicsDevice = new GraphicsDevice();
                }
                return graphicsDevice;
            }
            protected set
            {
                graphicsDevice = value;
            }
        }

        protected virtual void Initialize()
        {
            LoadContent();

            _gameComponentCollection.Initialize();
        }

        protected virtual void LoadContent()
        {
        }

        protected virtual void UnloadContent()
        {
        }

        protected virtual bool BeginDraw()
        {
            return true;
        }

        protected virtual void EndDraw()
        {

        }

        protected virtual void OnActivated(object o, EventArgs e)
        {

        }

        protected virtual void OnDeactivated(object o, EventArgs e)
        {

        }

        protected virtual void EndRun()
        {

        }

        protected virtual void Update(GameTime gameTime)
        {
            _gameComponentCollection.Update(gameTime);
        }

        protected virtual void Draw(GameTime gameTime)
        {
            _gameComponentCollection.Draw(gameTime);
        }

        public void Exit()
        {
            _currentState = States.Done;
            sb.Stop();
        }

        public GameComponentCollection Components 
        {
            get
            {
                return _gameComponentCollection;
            }
        }
    }
}
