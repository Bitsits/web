﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Effects;
using System.Windows.Resources;
using System.IO;

namespace SilverArcade.SilverSprite.Shaders
{
    public class TintEffect : ShaderEffect
    {
        public static DependencyProperty ColorProperty = DependencyProperty.Register("Color", typeof(System.Windows.Media.Color), typeof(TintEffect), new PropertyMetadata(new System.Windows.Media.Color(), PixelShaderConstantCallback(2)));

        public TintEffect()
        {
#if USE_FARSEER
            Uri u = new Uri(@"/SilverArcade.SilverSpriteForFarseer;component/Shaders/ssdrawcolor.ps", UriKind.Relative);
#else
            Uri u = new Uri(@"/SilverArcade.SilverSprite;component/Shaders/ssdrawcolor.ps", UriKind.Relative);
#endif
            PixelShader = new PixelShader() { UriSource = u };
            this.UpdateShaderValue(ColorProperty);
        }

        public virtual System.Windows.Media.Color Color
        {
            get
            {
                return ((System.Windows.Media.Color)(GetValue(ColorProperty)));
            }
            set
            {
                SetValue(ColorProperty, value);
            }
        }

    }
}
