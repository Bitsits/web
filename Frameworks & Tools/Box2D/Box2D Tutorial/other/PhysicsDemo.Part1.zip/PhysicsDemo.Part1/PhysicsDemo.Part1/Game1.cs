using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using Box2D.XNA;

namespace PhysicsDemo.Part1
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            _circle = Content.Load<Texture2D>("circle");

            var image = Content.Load<Texture2D>("xna_logo");
            var imageData = new Color[image.Width * image.Height];
            image.GetData(imageData);

            var bbwidth = GraphicsDevice.PresentationParameters.BackBufferWidth;
            var bbheight = GraphicsDevice.PresentationParameters.BackBufferHeight;

            _physicsWorld = new World(new Vector2(0, 100), true);

            // add ground
            BodyDef bd = new BodyDef();
            Body ground = _physicsWorld.CreateBody(bd);
            PolygonShape shape = new PolygonShape();
            shape.SetAsEdge(new Vector2(0.0f, bbheight), new Vector2(bbwidth, bbheight));
            ground.CreateFixture(shape, 0.0f);

            Random rand = new Random();
            int bail_count = 0;
            while (bail_count < 100)
            {
                int rx = rand.Next() % image.Width;
                int ry = rand.Next() % image.Height;

                var c = imageData[rx + image.Width * ry];

                if (c.A == 0)
                {
                    bail_count++;
                    continue;
                }

                var position = new Vector2(rx - image.Width / 2.0f + bbwidth / 2.0f, ry - image.Height / 2.0f + bbheight / 2.0f);

                bool tooClose = false;
                for (var b = _physicsWorld.GetBodyList(); b != null; b = b.GetNext())
                {
                    if ((position - b.Position).Length() < 2.0 * _circleRadius)
                    {
                        tooClose = true;
                        break;
                    }
                }

                if (tooClose)
                {
                    bail_count++;
                    continue;
                }

                AddCicle(position, c);
                bail_count = 0;
            }
            
        }

        private void AddCicle(Vector2 position, Color color)
        {
            var circle = new CircleShape();
            circle._radius = _circleRadius;

            var fd = new FixtureDef();
            fd.shape = circle;
            fd.restitution = 0.9f;
            fd.friction = 0.1f;
            fd.density = 1.0f;

            BodyDef bd = new BodyDef();
            bd.type = BodyType.Dynamic;
            bd.position =  position;
            
            var body = _physicsWorld.CreateBody(bd);
            body.CreateFixture(fd);
            body.SetUserData(color);
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            if (Keyboard.GetState().GetPressedKeys().Length > 0)
                _simulate = true;

            if (_simulate)
            {
                _physicsWorld.Step((float)gameTime.ElapsedGameTime.TotalSeconds, 10, 3);
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
            for (var b = _physicsWorld.GetBodyList(); b != null; b = b.GetNext())
            {
                var userData = b.GetUserData();
                if (userData != null)
                    spriteBatch.Draw(_circle, b.Position, null, (Color)userData, 0, new Vector2(_circle.Width, _circle.Height), _circleRadius / (_circle.Width / 2.0f), SpriteEffects.None, 0);
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }

        bool _simulate;
        float _circleRadius = 5.0f;
        World _physicsWorld;
        Texture2D _circle;
    }
}
