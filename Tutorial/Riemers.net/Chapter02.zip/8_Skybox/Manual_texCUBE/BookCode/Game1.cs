using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace BookCode
{
    public struct VertexPosition
    {
        public Vector3 Position;
        public VertexPosition(Vector3 position)
        {
            this.Position = position;
        }
        public static readonly VertexElement[] VertexElements = 
            {
                 new VertexElement( 0, 0, VertexElementFormat.Vector3, VertexElementMethod.Default, VertexElementUsage.Position, 0 )
            };
        
        public static readonly int SizeInBytes = sizeof(float) * 3;
    }

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        BasicEffect basicEffect;
        GraphicsDevice device;
        QuakeCamera fpsCam;
        CoordCross cCross;

        Model myModel;
        Matrix[] modelTransforms;

        VertexBuffer skyboxVertexBuffer;
        TextureCube skyboxTexture;
        Effect skyboxEffect;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }
        
        protected override void Initialize()
        {
            fpsCam = new QuakeCamera(graphics.GraphicsDevice.Viewport);            
            base.Initialize();            
        }

        protected override void LoadContent()
        {
            device = graphics.GraphicsDevice;
            basicEffect = new BasicEffect(device, null);
            cCross = new CoordCross(device);

            myModel = Content.Load<Model>("Ship");
            modelTransforms = new Matrix[myModel.Bones.Count];

            skyboxTexture = Content.Load<TextureCube>("skyboxtexture");
            skyboxEffect = Content.Load<Effect>("skyboxsample");
            CreateSkyboxVertexBuffer();
        }

        private void CreateSkyboxVertexBuffer()
        {
            Vector3 forwardBottomLeft = new Vector3(-1, -1, -1);
            Vector3 forwardBottomRight = new Vector3(1, -1, -1);
            Vector3 forwardUpperLeft = new Vector3(-1, 1, -1);
            Vector3 forwardUpperRight = new Vector3(1, 1, -1);

            Vector3 backBottomLeft = new Vector3(-1, -1, 1);
            Vector3 backBottomRight = new Vector3(1, -1, 1);
            Vector3 backUpperLeft = new Vector3(-1, 1, 1);
            Vector3 backUpperRight = new Vector3(1, 1, 1);

            VertexPosition[] vertices = new VertexPosition[36];
            int i = 0;

            //face in front of the camera
            vertices[i++] = new VertexPosition(forwardBottomLeft);
            vertices[i++] = new VertexPosition(forwardUpperLeft);
            vertices[i++] = new VertexPosition(forwardUpperRight);

            vertices[i++] = new VertexPosition(forwardBottomLeft);
            vertices[i++] = new VertexPosition(forwardUpperRight);
            vertices[i++] = new VertexPosition(forwardBottomRight);

            //face to the right of the camera
            vertices[i++] = new VertexPosition(forwardBottomRight);
            vertices[i++] = new VertexPosition(forwardUpperRight);
            vertices[i++] = new VertexPosition(backUpperRight);

            vertices[i++] = new VertexPosition(forwardBottomRight);
            vertices[i++] = new VertexPosition(backUpperRight);
            vertices[i++] = new VertexPosition(backBottomRight);

            //face behind camera
            vertices[i++] = new VertexPosition(backBottomLeft);
            vertices[i++] = new VertexPosition(backUpperRight);
            vertices[i++] = new VertexPosition(backUpperLeft);

            vertices[i++] = new VertexPosition(backBottomLeft);
            vertices[i++] = new VertexPosition(backBottomRight);
            vertices[i++] = new VertexPosition(backUpperRight);

            //face to the left of the camera
            vertices[i++] = new VertexPosition(backBottomLeft);
            vertices[i++] = new VertexPosition(backUpperLeft);
            vertices[i++] = new VertexPosition(forwardUpperLeft);

            vertices[i++] = new VertexPosition(backBottomLeft);
            vertices[i++] = new VertexPosition(forwardUpperLeft);
            vertices[i++] = new VertexPosition(forwardBottomLeft);

            //face above the camera
            vertices[i++] = new VertexPosition(forwardUpperLeft);
            vertices[i++] = new VertexPosition(backUpperLeft);
            vertices[i++] = new VertexPosition(backUpperRight);

            vertices[i++] = new VertexPosition(forwardUpperLeft);
            vertices[i++] = new VertexPosition(backUpperRight);
            vertices[i++] = new VertexPosition(forwardUpperRight);

            //face under the camera
            vertices[i++] = new VertexPosition(forwardBottomLeft);
            vertices[i++] = new VertexPosition(backBottomRight);
            vertices[i++] = new VertexPosition(backBottomLeft);

            vertices[i++] = new VertexPosition(forwardBottomLeft);
            vertices[i++] = new VertexPosition(forwardBottomRight);
            vertices[i++] = new VertexPosition(backBottomRight);

            skyboxVertexBuffer = new VertexBuffer(device, vertices.Length * VertexPosition.SizeInBytes, BufferUsage.WriteOnly);
            skyboxVertexBuffer.SetData<VertexPosition>(vertices);
        }

        protected override void UnloadContent()
        {
        }
     
        protected override void Update(GameTime gameTime)
        {
            GamePadState gamePadState = GamePad.GetState(PlayerIndex.One);
            if (gamePadState.Buttons.Back == ButtonState.Pressed)
                this.Exit();

            MouseState mouseState = Mouse.GetState();
            KeyboardState keyState = Keyboard.GetState();

            fpsCam.Update(mouseState, keyState, gamePadState);

            base.Update(gameTime);
        }
            
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, Color.Black, 1, 0);

            device.RenderState.DepthBufferWriteEnable = false;
            skyboxEffect.CurrentTechnique = skyboxEffect.Techniques["SkyBox"];
            skyboxEffect.Parameters["xWorld"].SetValue(Matrix.CreateTranslation(fpsCam.Position));
            skyboxEffect.Parameters["xView"].SetValue(fpsCam.ViewMatrix);
            skyboxEffect.Parameters["xProjection"].SetValue(fpsCam.ProjectionMatrix);
            skyboxEffect.Parameters["xCubeTexture"].SetValue(skyboxTexture);
            skyboxEffect.Begin();
            foreach (EffectPass pass in skyboxEffect.CurrentTechnique.Passes)
            {
                pass.Begin();

                device.VertexDeclaration = new VertexDeclaration(device, VertexPosition.VertexElements);
                device.Vertices[0].SetSource(skyboxVertexBuffer, 0, VertexPosition.SizeInBytes);
                device.DrawPrimitives(PrimitiveType.TriangleList, 0, 12);

                pass.End();
            }
            skyboxEffect.End();
            device.RenderState.DepthBufferWriteEnable = true;

            //draw model
            myModel.CopyAbsoluteBoneTransformsTo(modelTransforms);
            foreach (ModelMesh mesh in myModel.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.World = modelTransforms[mesh.ParentBone.Index] * Matrix.CreateScale(0.002f);
                    effect.View = fpsCam.ViewMatrix;
                    effect.Projection = fpsCam.ProjectionMatrix;
                }
                mesh.Draw();
            }            

            //draw coordcross
            cCross.Draw(fpsCam.ViewMatrix, fpsCam.ProjectionMatrix);            

            base.Draw(gameTime);
        }
    }
}