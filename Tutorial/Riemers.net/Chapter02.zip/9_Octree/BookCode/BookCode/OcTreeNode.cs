using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

namespace BookCode
{
    class OcTreeNode
    {
        private const int maxObjectsInNode = 5;
        private const float minSize = 5.0f;

        private Vector3 center;
        private float size;
        List<DrawableModel> modelList;
        private BoundingBox nodeBoundingBox;        

        OcTreeNode nodeUFL;
        OcTreeNode nodeUFR;
        OcTreeNode nodeUBL;
        OcTreeNode nodeUBR;
        OcTreeNode nodeDFL;
        OcTreeNode nodeDFR;
        OcTreeNode nodeDBL;
        OcTreeNode nodeDBR;
        List<OcTreeNode> childList;

        public static int modelsDrawn;
        private static int modelsStoredInQuadTree;

        public int ModelsDrawn { get { return modelsDrawn; } set { modelsDrawn = value; } }

        public OcTreeNode(Vector3 center, float size)
        {
            this.center = center;
            this.size = size;
            modelList = new List<DrawableModel>();
            childList = new List<OcTreeNode>(8);

            Vector3 diagonalVector = new Vector3(size / 2.0f, size / 2.0f, size / 2.0f);
            nodeBoundingBox = new BoundingBox(center - diagonalVector, center + diagonalVector);
        }

        public int Add(Model model, Matrix worldMatrix)
        {
            DrawableModel newDModel = new DrawableModel(model, worldMatrix, modelsStoredInQuadTree++);
            AddDrawableModel(newDModel);
            return newDModel.ModelID;
        }

        public void UpdateModelWorldMatrix(int modelID, Matrix newWorldMatrix)
        {
            DrawableModel deletedModel = RemoveDrawableModel(modelID);
            deletedModel.WorldMatrix = newWorldMatrix;
            AddDrawableModel(deletedModel);
        }

        private DrawableModel RemoveDrawableModel(int modelID)
        {
            DrawableModel dModel = null;

            for (int index = 0; index < modelList.Count; index++)
            {
                if (modelList[index].ModelID == modelID)
                {
                    dModel = modelList[index];
                    modelList.Remove(dModel);
                }
            }

            int child = 0;
            while ((dModel == null) && (child < childList.Count))
            {
                dModel = childList[child++].RemoveDrawableModel(modelID);
            }

            return dModel;
        }

        private void AddDrawableModel(DrawableModel dModel)
        {
            if (childList.Count == 0)
            {
                modelList.Add(dModel);

                bool maxObjectsReached = (modelList.Count > maxObjectsInNode);
                bool minSizeNotReached = (size > minSize);
                if (maxObjectsReached && minSizeNotReached)
                {
                    CreateChildNodes();
                    foreach (DrawableModel currentDModel in modelList)
                    {
                        Distribute(currentDModel);
                    }
                    modelList.Clear();
                }
            }
            else
            {
                Distribute(dModel);
            }
        }

        private void CreateChildNodes()
        {
            float sizeOver2 = size / 2.0f;
            float sizeOver4 = size / 4.0f;

            nodeUFR = new OcTreeNode(center + new Vector3(sizeOver4, sizeOver4, -sizeOver4), sizeOver2);
            nodeUFL = new OcTreeNode(center + new Vector3(-sizeOver4, sizeOver4, -sizeOver4), sizeOver2);
            nodeUBR = new OcTreeNode(center + new Vector3(sizeOver4, sizeOver4, sizeOver4), sizeOver2);
            nodeUBL = new OcTreeNode(center + new Vector3(-sizeOver4, sizeOver4, sizeOver4), sizeOver2);
            nodeDFR = new OcTreeNode(center + new Vector3(sizeOver4, -sizeOver4, -sizeOver4), sizeOver2);
            nodeDFL = new OcTreeNode(center + new Vector3(-sizeOver4, -sizeOver4, -sizeOver4), sizeOver2);
            nodeDBR = new OcTreeNode(center + new Vector3(sizeOver4, -sizeOver4, sizeOver4), sizeOver2);
            nodeDBL = new OcTreeNode(center + new Vector3(-sizeOver4, -sizeOver4, sizeOver4), sizeOver2);

            childList.Add(nodeUFR);
            childList.Add(nodeUFL);
            childList.Add(nodeUBR);
            childList.Add(nodeUBL);
            childList.Add(nodeDFR);
            childList.Add(nodeDFL);
            childList.Add(nodeDBR);
            childList.Add(nodeDBL);
        }

        private void Distribute(DrawableModel dModel)
        {
            Vector3 position = dModel.Position;
            if (position.Y > center.Y)          //Up
                if (position.Z < center.Z)      //Forward
                    if (position.X < center.X)  //Left
                        nodeUFL.AddDrawableModel(dModel);
                    else                        //Right
                        nodeUFR.AddDrawableModel(dModel);
                else                            //Back
                    if (position.X < center.X)  //Left
                        nodeUBL.AddDrawableModel(dModel);
                    else                        //Right
                        nodeUBR.AddDrawableModel(dModel);
            else                                //Down
                if (position.Z < center.Z)      //Forward
                    if (position.X < center.X)  //Left
                        nodeDFL.AddDrawableModel(dModel);
                    else                        //Right
                        nodeDFR.AddDrawableModel(dModel);
                else                            //Back
                    if (position.X < center.X)  //Left
                        nodeDBL.AddDrawableModel(dModel);
                    else                        //Right
                        nodeDBR.AddDrawableModel(dModel);
        }

        public void Draw(Matrix viewMatrix, Matrix projectionMatrix, BoundingFrustum cameraFrustrum)
        {
            ContainmentType cameraNodeContainment = cameraFrustrum.Contains(nodeBoundingBox);
            if (cameraNodeContainment != ContainmentType.Disjoint)
            {
                foreach (DrawableModel dModel in modelList)
                {
                    dModel.Draw(viewMatrix, projectionMatrix);
                    modelsDrawn++;
                }

                foreach (OcTreeNode childNode in childList)
                    childNode.Draw(viewMatrix, projectionMatrix, cameraFrustrum);
            }
        }

        public void DrawBoxLines(Matrix viewMatrix, Matrix projectionMatrix, GraphicsDevice device, BasicEffect basicEffect)
        {
            foreach (OcTreeNode childNode in childList)
                childNode.DrawBoxLines(viewMatrix, projectionMatrix, device, basicEffect);            

            if (childList.Count == 0)
                XNAUtils.DrawBoundingBox(nodeBoundingBox, device, basicEffect, Matrix.Identity, viewMatrix, projectionMatrix);
        }
    }
}
