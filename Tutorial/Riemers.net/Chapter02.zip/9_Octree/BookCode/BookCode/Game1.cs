using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace BookCode
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        GraphicsDevice device;
        QuakeCamera fpsCam;
        CoordCross cCross;

        BasicEffect basicEffect;
        Model myModel;
        OcTreeNode ocTreeRoot;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }
        
        protected override void Initialize()
        {
            fpsCam = new QuakeCamera(graphics.GraphicsDevice.Viewport, new Vector3(-20, 3, 8), -MathHelper.Pi/3.0f, 0);
            ocTreeRoot = new OcTreeNode(new Vector3(0, 0, 0), 21);

            base.Initialize();            
        }

        protected override void LoadContent()
        {   
            device = graphics.GraphicsDevice;
            cCross = new CoordCross(device);
            basicEffect = new BasicEffect(device, null);

            myModel = Content.Load<Model>("Ship");

            int[] modelIDs = new int[8];
            modelIDs[0] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(1, 3, 5));
            modelIDs[1] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(5, 2, -1));
            modelIDs[2] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(10, -4, -1));
            modelIDs[3] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(1, 2, -3));
            modelIDs[4] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(5, 2, -3));
            modelIDs[5] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(10, -4, -3));
            modelIDs[6] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(8, 8, -3));
            modelIDs[7] = ocTreeRoot.Add(myModel, Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(10, 8, -3));
        }
     
        protected override void UnloadContent()
        {
        }
    
        protected override void Update(GameTime gameTime)
        {
            GamePadState gamePadState = GamePad.GetState(PlayerIndex.One);
            if (gamePadState.Buttons.Back == ButtonState.Pressed)
                this.Exit();            

            MouseState mouseState = Mouse.GetState();
            KeyboardState keyState = Keyboard.GetState();

            fpsCam.Update(mouseState, keyState, gamePadState);

            float time = (float)gameTime.TotalGameTime.TotalMilliseconds/ 1000.0f;
            Vector3 startingPos = new Vector3(1, 3, 5);
            Vector3 moveDirection = new Vector3(0, 0, -1);
            Matrix newWMatrix = Matrix.CreateScale(0.001f) * Matrix.CreateTranslation(startingPos + time * moveDirection);
            int modelToChange = 0;
            ocTreeRoot.UpdateModelWorldMatrix(modelToChange, newWMatrix);

            base.Update(gameTime);
        }
            
        protected override void Draw(GameTime gameTime)
        {
            device.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, Color.CornflowerBlue, 1, 0);

            //draw coordcross
            cCross.Draw(fpsCam.ViewMatrix, fpsCam.ProjectionMatrix);

            ocTreeRoot.ModelsDrawn = 0;
            BoundingFrustum cameraFrustrum = new BoundingFrustum(fpsCam.ViewMatrix * fpsCam.ProjectionMatrix);
            ocTreeRoot.Draw(fpsCam.ViewMatrix, fpsCam.ProjectionMatrix, cameraFrustrum);
            ocTreeRoot.DrawBoxLines(fpsCam.ViewMatrix, fpsCam.ProjectionMatrix, device, basicEffect);
            Window.Title = string.Format("Models drawn: {0}", ocTreeRoot.ModelsDrawn);
            
            base.Draw(gameTime);
        }
    }
}