using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;

namespace BookCode
{
    class DrawableModel
    {
        private Matrix worldMatrix;
        private Model model;
        private Matrix[] modelTransforms;
        private Vector3 position;
        private int modelID;

        public Matrix WorldMatrix
        {
            get { return worldMatrix; }
            set
            {
                worldMatrix = value;
                position = new Vector3(value.M41, value.M42, value.M43);
            }
        }

        public Vector3 Position { get { return position; } }
        public Model Model { get { return model; } }
        public int ModelID { get { return modelID; } }

        public DrawableModel(Model inModel, Matrix inWorldMatrix, int inModelID)
        {
            model = inModel;
            modelTransforms = new Matrix[model.Bones.Count];
            worldMatrix = inWorldMatrix;
            modelID = inModelID;
            position = new Vector3(inWorldMatrix.M41, inWorldMatrix.M42, inWorldMatrix.M43);
            position = inWorldMatrix.Translation;
        }

        public void Draw(Matrix viewMatrix, Matrix projectionMatrix)
        {
            model.CopyAbsoluteBoneTransformsTo(modelTransforms);
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.World = modelTransforms[mesh.ParentBone.Index] * worldMatrix;
                    effect.View = viewMatrix;
                    effect.Projection = projectionMatrix;
                }
                mesh.Draw();
            }
        }
    }
}
