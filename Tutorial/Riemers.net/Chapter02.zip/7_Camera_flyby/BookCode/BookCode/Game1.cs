using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace BookCode
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        BasicEffect basicEffect;
        GraphicsDevice device;
        QuakeCamera fpsCam;
        CoordCross cCross;
        Model myModel;
        Matrix[] modelTransforms;

        float bezTime = 1.0f;
        Vector3 bezStartPosition;
        Vector3 bezMidPosition;
        Vector3 bezEndPosition;
        Vector3 bezStartTarget;
        Vector3 bezEndTarget;

        SpriteBatch spriteBatch;
        SpriteFont myFont;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }
        
        protected override void Initialize()
        {
            fpsCam = new QuakeCamera(graphics.GraphicsDevice.Viewport);
            fpsCam.Position = new Vector3(1, 1, 10);
            base.Initialize();            
        }

        protected override void LoadContent()
        {
            device = graphics.GraphicsDevice;
            basicEffect = new BasicEffect(device, null);
            cCross = new CoordCross(device);

            myModel = Content.Load<Model>("Ship");
            modelTransforms = new Matrix[myModel.Bones.Count];

            spriteBatch = new SpriteBatch(device);
            myFont = Content.Load<SpriteFont>("font");
        }        

        protected override void UnloadContent()
        {
        }
     
        protected override void Update(GameTime gameTime)
        {
            GamePadState gamePadState = GamePad.GetState(PlayerIndex.One);
            if (gamePadState.Buttons.Back == ButtonState.Pressed)
                this.Exit();

            MouseState mouseState = Mouse.GetState();
            KeyboardState keyState = Keyboard.GetState();

            fpsCam.Update(mouseState, keyState, gamePadState);

            if (keyState.IsKeyDown(Keys.F) || (gamePadState.Buttons.A == ButtonState.Pressed))
                if (bezTime > 1.0f)
                    InitBezier(fpsCam.Position, fpsCam.Position + fpsCam.Forward * 10.0f, new Vector3(0, 0, -20), new Vector3(0, 0, -10));

            UpdateBezier();

            base.Update(gameTime);
        }

        private void InitBezier(Vector3 startPosition, Vector3 startTarget, Vector3 endPosition, Vector3 endTarget)
        {
            bezStartPosition = startPosition;
            bezEndPosition = endPosition;

            bezMidPosition = (bezStartPosition + bezEndPosition) / 2.0f;
            Vector3 cameraDirection = endPosition - startPosition;
            Vector3 targDirection = endTarget - startTarget;
            Vector3 upVector = Vector3.Cross(new Vector3(targDirection.X, 0, targDirection.Z), new Vector3(cameraDirection.X, 0, cameraDirection.Z));
            Vector3 perpDirection = Vector3.Cross(upVector, cameraDirection);

            if (perpDirection == new Vector3())
                perpDirection = new Vector3(0, 1, 0);
            perpDirection.Normalize();

            Vector3 midShiftDirecton = new Vector3(0, 1, 0) + perpDirection;
            bezMidPosition += cameraDirection.Length() * midShiftDirecton;

            bezStartTarget = startTarget;
            bezEndTarget = endTarget;

            bezTime = 0.0f;
        }
        
        private void UpdateBezier()
        {
            bezTime += 0.01f;
            if (bezTime > 1.0f)
                return;            

            float smoothValue = MathHelper.SmoothStep(0, 1, bezTime);
            Vector3 newCamPos = Bezier(bezStartPosition, bezMidPosition, bezEndPosition, smoothValue);
            Vector3 newCamTarget = Vector3.Lerp(bezStartTarget, bezEndTarget, smoothValue);

            float updownRot;
            float leftrightRot;
            AnglesFromDirection(newCamTarget - newCamPos, out updownRot, out leftrightRot);
                        
            fpsCam.UpDownRot = updownRot;
            fpsCam.LeftRightRot = leftrightRot;
            fpsCam.Position = newCamPos;
        }

        private Vector3 Bezier(Vector3 startPoint, Vector3 midPoint, Vector3 endPoint, float time)
        {
            float invTime = 1.0f - time;
            float timePow = (float)Math.Pow(time, 2);
            float invTimePow = (float)Math.Pow(invTime, 2);

            Vector3 result = startPoint * invTimePow;
            result += 2 * midPoint * time * invTime;
            result += endPoint * timePow;

            return result;
        }

        private void AnglesFromDirection(Vector3 direction, out float updownAngle, out float leftrightAngle)
        {
            Vector3 floorProjection = new Vector3(direction.X, 0, direction.Z);
            float directionLength = floorProjection.Length();
            updownAngle = (float)Math.Atan2(direction.Y, directionLength);
            leftrightAngle = -(float)Math.Atan2(direction.X, -direction.Z);
        }
            
        protected override void Draw(GameTime gameTime)
        {
            device.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, Color.CornflowerBlue, 1, 0);

            //draw coordcross
            cCross.Draw(fpsCam.ViewMatrix, fpsCam.ProjectionMatrix);

            List<Matrix> worldMatrices = new List<Matrix>();
            worldMatrices.Add(Matrix.CreateScale(0.002f) * Matrix.CreateTranslation(5, 5, -5));
            worldMatrices.Add(Matrix.CreateScale(0.002f) * Matrix.CreateTranslation(0, 0, -10));
            worldMatrices.Add(Matrix.CreateScale(0.002f) * Matrix.CreateTranslation(-5, 5, -5));

            //draw models
            myModel.CopyAbsoluteBoneTransformsTo(modelTransforms);
            foreach (Matrix worldMatrix in worldMatrices)
            {
                foreach (ModelMesh mesh in myModel.Meshes)
                {
                    foreach (BasicEffect effect in mesh.Effects)
                    {
                        effect.EnableDefaultLighting();
                        effect.World = modelTransforms[mesh.ParentBone.Index] * worldMatrix;
                        effect.View = fpsCam.ViewMatrix;
                        effect.Projection = fpsCam.ProjectionMatrix;
                    }
                    mesh.Draw();
                }
            }

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.BackToFront, SaveStateMode.SaveState);
            spriteBatch.DrawString(myFont, "Press F to initiate a Fly-By", new Vector2(20, 20), Color.Red);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}