using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using System.IO;
using System.Xml.Serialization;

namespace BookCode
{
    [Serializable]
    public struct GameData
    {
        public int ActivePlayers;
        public float Time;
    }

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;
        List<string> log = new List<string>();

        GameData gameData;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            gameData = new GameData();
            gameData.ActivePlayers = 2;
            gameData.Time = 0;

            log.Add("Hit S to save the current game data");
            log.Add("Hit L to load the current game data");

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            font = Content.Load<SpriteFont>("font");
        }

        protected override void Update(GameTime gameTime)
        {
            GamePadState gamePadState = GamePad.GetState(PlayerIndex.One);
            if (gamePadState.Buttons.Back == ButtonState.Pressed)
                this.Exit();

            KeyboardState keyState = Keyboard.GetState();
            if (keyState.IsKeyDown(Keys.S) || (gamePadState.Buttons.B == ButtonState.Pressed))
                SaveGame();
            if (keyState.IsKeyDown(Keys.L) || (gamePadState.Buttons.A == ButtonState.Pressed))
                LoadGame();

            gameData.Time += (float)gameTime.ElapsedGameTime.TotalSeconds;

            base.Update(gameTime);
        }

        private void SaveGame()
        {
            string fileName = Path.Combine(Content.RootDirectory, "save0001.sav");

            FileStream saveFile = File.Open(fileName, FileMode.Create);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(GameData));

            xmlSerializer.Serialize(saveFile, gameData);
            saveFile.Close();

            log.Add("saved!");
        }

        private void LoadGame()
        {
            string fileName = Path.Combine(Content.RootDirectory, "save0001.sav");

            if (File.Exists(fileName))
            {
                FileStream saveFile = File.Open(fileName, FileMode.Open);
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(GameData));

                gameData = (GameData)xmlSerializer.Deserialize(saveFile);
                saveFile.Close();

                log.Add("loaded!");
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, Color.CornflowerBlue, 1, 0);

            spriteBatch.Begin();
            spriteBatch.DrawString(font, "savedata: " + gameData.Time.ToString(), new Vector2(30, 30), Color.Red);
            for (int i = 0; i < log.Count; i++)
                spriteBatch.DrawString(font, log[i], new Vector2(30, 30 * (i + 2)), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
