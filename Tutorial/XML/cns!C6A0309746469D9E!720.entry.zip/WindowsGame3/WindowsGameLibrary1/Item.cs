﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsGameLibrary1
{
    public enum ItemType
    {
        Weapon,
        Armor,
        Potion,
        Ring,
        Necklace,
        Scroll
    }

    public enum ItemSubType
    {
        TwoHandedWeapon,
        OneHandedWeapon,
        HeadArmor,
        ChestArmor,
        ArmsArmor,
        HandsArmor,
        LegsArmor,
        FeetArmor,
        None
    }

    public class Item
    {
        public string Name;
        public ItemType Type;
        public ItemSubType SubType;
        public string Description;
        public int MinDamage;
        public int MaxDMG;
        public int MaxHP;
        public int Speed;

        public Item()
        {

        }
    }
}
