This is the accompanying code for the article "2D in Direct3D 9 using Textured Quads"

It is a Visual Studio.NET project.
If you have a different compiler, add all of the .h/.cpp files into a Win32 application workspace, then link d3d9.lib and d3dx9.lib
If your compiler does not support "#pragma once", you'll have to add your own multiple inclusion guard in "graphics.h" and "texture.h".
