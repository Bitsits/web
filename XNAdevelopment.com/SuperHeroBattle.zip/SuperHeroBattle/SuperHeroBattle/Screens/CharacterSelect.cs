using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

using SuperHeroBattle.Sprites;

namespace SuperHeroBattle.Screens
{
    class CharacterSelect: Screen
    {
        Sprite characterFrame;
        const string ActionStart = "Start";
        List<CharacterSelector> characterSelectors = new List<CharacterSelector>();

        public CharacterSelect(Game game, SpriteBatch batch, ChangeScreen changeScreen)
            : base(game, batch, changeScreen)
        {

        }

        protected override void SetupInputs()
        {
            input.AddGamePadInput(ActionStart, Buttons.Start, true);
            input.AddKeyboardInput(ActionStart, Keys.Enter, true);

            characterSelectors.Add(new CharacterSelector(content, (PlayerIndex)playerOne, new Vector2(0, 0), input));
            characterSelectors.Add(new CharacterSelector(content, new Vector2(300, 0), input));
            characterSelectors.Add(new CharacterSelector(content, new Vector2(600, 0), input));
            characterSelectors.Add(new CharacterSelector(content, new Vector2(900, 0), input));
        }

        protected override void LoadScreenContent(ContentManager content)
        {
            characterFrame = new Sprite(content, "Images/CharacterSelect");
        }

        public override void Activate()
        {
            foreach (CharacterSelector select in characterSelectors)
            {
                select.Hero().currenState = SuperHero.State.Sketch;
                select.Hero().Position = new Vector2(0, 0);
                select.Reset();
            }
        }

        protected override void UpdateScreen(GameTime gameTime)
        {
            bool isReady = true;
            Battle.ClearSuperHeroes();
            foreach (CharacterSelector selector in characterSelectors)
            {
                selector.Update(gameTime);
                if (selector.currentState == CharacterSelector.State.Selecting)
                {
                    isReady = false;
                }

                if (selector.currentState == CharacterSelector.State.Selected)
                {
                    Battle.AddSuperHero(selector.Hero());
                }
            }

            if (input.IsPressed(ActionStart, null) && isReady)
            {
                changeScreenDelegate(ScreenState.Battle);
            }
        }

        protected override void DrawScreen(SpriteBatch batch)
        {
            foreach (CharacterSelector selector in characterSelectors)
            {
                selector.Draw(batch);
            }
            characterFrame.Draw(batch);
        }
    }
}