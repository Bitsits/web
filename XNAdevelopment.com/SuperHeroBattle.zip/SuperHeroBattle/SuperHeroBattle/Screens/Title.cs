using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;

using SuperHeroBattle.Sprites;
using SuperHeroBattle.Texts;


namespace SuperHeroBattle.Screens
{
    class Title : Screen
    {
        Sprite background;
        const string ActionStart = "Start";
        SoundEffect selectSound;

        public Title(Game game, SpriteBatch batch, ChangeScreen changeScreen)
            : base(game, batch, changeScreen)
        {
        }

        protected override void SetupInputs()
        {
            input.AddGamePadInput(ActionStart, Buttons.Start, true);
            input.AddGamePadInput(ActionStart, Buttons.A, true);
            input.AddKeyboardInput(ActionStart, Keys.Space, true);
            input.AddKeyboardInput(ActionStart, Keys.A, true);
        }

        protected override void LoadScreenContent(ContentManager content)
        {
            background = new Sprite(content, "Images/SuperHeroTitle");
            selectSound = content.Load<SoundEffect>("SoundEffects/Select");
        }

        public override void Activate()
        {
        }

        protected override void UpdateScreen(GameTime gameTime)
        {
            if (input.IsPressed(ActionStart, null, out playerOne))
            {
                selectSound.Play();
                changeScreenDelegate(ScreenState.CharacterSelect);
            }
        }

        protected override void DrawScreen(SpriteBatch batch)
        {
            background.Draw(batch);
        }
    }
}
