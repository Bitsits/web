using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

using SuperHeroBattle.Sprites;

namespace SuperHeroBattle.Screens
{
    class GameOver: Screen
    {
        SpriteFont titleFont;

        public GameOver(Game game, SpriteBatch batch, ChangeScreen changeScreen)
            : base(game, batch, changeScreen)
        {
        }

        protected override void SetupInputs()
        {
            input.AddGamePadInput("Start", Buttons.Start, true);
            input.AddGamePadInput("Exit", Buttons.Back, true);
            
        }

        protected override void LoadScreenContent(ContentManager content)
        {
            titleFont = content.Load<SpriteFont>("Fonts/titleFont");
        }

        SuperHero winner;
        public override void Activate()
        {
            int count = -1;
            SuperHero leader = null;
            foreach (SuperHero hero in Battle.superHeroes)
            {
                if (hero.KillCount > count)
                {
                    leader = hero;
                }
            }
            winner = leader;
        }

        protected override void UpdateScreen(GameTime gameTime)
        {
            if (input.IsPressed("Start"))
            {
                changeScreenDelegate(ScreenState.CharacterSelect);
            }

            if (input.IsPressed("Exit"))
            {
                changeScreenDelegate(ScreenState.Exit);
            }
        }

            
        protected override void DrawScreen(SpriteBatch batch)
        {
            winner.Position = new Vector2(600, 300);
            winner.Draw(batch);

            batch.DrawString(titleFont, "Super Hero Battle Over!", new Vector2(100, 50), Color.White);
            batch.DrawString(titleFont, "Winner!", new Vector2(550, 250), winner.playerColor);
            
            batch.DrawString(font, "Press Start to Play again", new Vector2(500, 600), Color.White);
        }
    }
}