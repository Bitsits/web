using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;

using SuperHeroBattle.Sprites;

namespace SuperHeroBattle.Screens
{
    class Battle: Screen
    {
        public static List<SuperHero> superHeroes = new List<SuperHero>();
        TimeSpan mGameTimeRemaining;
        SpriteFont timerFont;
        SoundEffect gameOver;
        Sprite cityBackground;

        public Battle(Game game, SpriteBatch batch, ChangeScreen changeScreen)
            : base(game, batch, changeScreen)
        {
        }

        public static void AddSuperHero(SuperHero hero)
        {
            superHeroes.Add(hero);
        }

        public static void ClearSuperHeroes()
        {
            superHeroes.Clear();
        }

        protected override void SetupInputs()
        {
        }

        protected override void LoadScreenContent(ContentManager content)
        {
            timerFont = content.Load<SpriteFont>("Fonts/Timer");
            gameOver = content.Load<SoundEffect>("SoundEffects/GameOver");
            cityBackground = new Sprite(content, "Images/City");
            //cityBackground.scale = 5.0f;
        }

        public override void Activate()
        {
            foreach (SuperHero hero in superHeroes)
            {
                hero.MakeAlive();
            }

            mGameTimeRemaining = new TimeSpan(0, 2, 00);
        }

        protected override void UpdateScreen(GameTime gameTime)
        {
            foreach (SuperHero hero in superHeroes)
            {
                hero.Update(gameTime, input);
            }

            foreach (SuperHero hero in superHeroes)
            {
                foreach (SuperHero secondHero in superHeroes)
                {
                    if (hero != secondHero)
                    {
                        hero.CheckCollision(secondHero);
                    }
                }
            }

            mGameTimeRemaining -= gameTime.ElapsedGameTime;
            if (mGameTimeRemaining <= new TimeSpan(0, 0, 0))
            {
                gameOver.Play();
                changeScreenDelegate(ScreenState.GameOver);            
            }
        }

        protected override void DrawScreen(SpriteBatch batch)
        {
            cityBackground.Draw(batch);

            foreach (SuperHero hero in superHeroes)
            {
                hero.Draw(batch);
            }

            batch.DrawString(timerFont, String.Format("{0:00}:{1:00}", mGameTimeRemaining.Minutes, mGameTimeRemaining.Seconds), new Vector2(500, 50), Color.Black);
      }
    }
}