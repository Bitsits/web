using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace SuperHeroBattle.Screens
{
    public enum ScreenState
    {
        Title,
        CharacterSelect, 
        Battle,
        GameOver,
        PreviousScreen,
        Exit
    }

    class ScreenStateSwitchboard
    {
        static Game game;
        static SpriteBatch batch;
        static Screen previousScreen;
        static Screen currentScreen;
        static Dictionary<ScreenState, Screen> screens = new Dictionary<ScreenState, Screen>();

        private delegate Screen CreateScreen();

        public ScreenStateSwitchboard(Game game, SpriteBatch batch)
        {
            ScreenStateSwitchboard.game = game;
            ScreenStateSwitchboard.batch = batch;
            ChangeScreen(ScreenState.Title);
        }

        private void ChangeScreen(ScreenState screenState)
        {
            switch (screenState)
            {
                case ScreenState.Title:
                    {
                        ChangeScreen(screenState, new CreateScreen(CreateTitleScreen));
                        break;
                    }

                case ScreenState.CharacterSelect:
                    {
                        ChangeScreen(screenState, new CreateScreen(CreateCharacterSelectScreen));
                        break;
                    }

                case ScreenState.Battle:
                    {
                        ChangeScreen(screenState, new CreateScreen(CreateBattleScreen));
                        break;
                    }

                case ScreenState.GameOver:
                    {
                        ChangeScreen(screenState, new CreateScreen(CreateGameOverScreen));
                        break;
                    }

                case ScreenState.PreviousScreen:
                    {
                        currentScreen = previousScreen;
                        currentScreen.Activate();
                        break;
                    }

                case ScreenState.Exit:
                    {
                        game.Exit();
                        break;
                    }
            }
        }

        private void ChangeScreen(ScreenState screenState, CreateScreen createScreen)
        {
            previousScreen = currentScreen;

            if (!screens.ContainsKey(screenState))
            {
                screens.Add(screenState, createScreen());
                screens[screenState].LoadContent();
            }
            currentScreen = screens[screenState];
            currentScreen.Activate();
        }

        private Screen CreateTitleScreen()
        {
            return new Title(game, batch, new Screen.ChangeScreen(ChangeScreen));
        }

        private Screen CreateCharacterSelectScreen()
        {
            return new CharacterSelect(game, batch, new Screen.ChangeScreen(ChangeScreen));
        }

        private Screen CreateBattleScreen()
        {
            return new Battle(game, batch, new Screen.ChangeScreen(ChangeScreen));
        }

        private Screen CreateGameOverScreen()
        {
            return new GameOver(game, batch, new Screen.ChangeScreen(ChangeScreen));
        }

        public void Update(GameTime gameTime)
        {
            currentScreen.Update(gameTime);
        }

        public void Draw()
        {
            currentScreen.Draw();
        }
    }
}

