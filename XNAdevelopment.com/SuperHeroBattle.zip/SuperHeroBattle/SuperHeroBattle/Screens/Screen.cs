using System;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using SuperHeroBattle.Inputs;
using SuperHeroBattle.Screens;
using SuperHeroBattle.Sounds;

namespace SuperHeroBattle.Screens
{
    class Screen
    {
        protected static Game game;
        protected static ContentManager content;
        protected static SpriteBatch batch;
        protected static Random random = new Random();

        public ChangeScreen changeScreenDelegate;
        public delegate void ChangeScreen(ScreenState screen);

        protected SpriteFont font;

        protected GameInput input = new GameInput();
        protected static Music music;
        protected static SoundEffects soundEffects;

        static protected PlayerIndex playerOne;
        static protected PlayerIndex playerTwo;
        static protected PlayerIndex playerThree;
        static protected PlayerIndex playerFour;

        static private int numberOfPlayers = 0;

        public Screen(Game game, SpriteBatch batch, ChangeScreen changeScreen)
        {
            Screen.game = game;
            Screen.content = game.Content;
            Screen.batch = batch;

            changeScreenDelegate = changeScreen;
        
            if (music == null)
            {
                music = new Music(content);
            }

            if (soundEffects == null)
            {
                soundEffects = new SoundEffects(content);
            }
        }

        public static void AddPlayer(PlayerIndex player)
        {
            switch (numberOfPlayers)
            {
                case 0:
                    {
                        playerOne = player;
                        break;
                    }

                case 1:
                    {
                        playerTwo = player;
                        break;
                    }

                case 2:
                    {
                        playerThree = player;
                        break;
                    }

                case 3:
                    {
                        playerFour = player;
                        break;
                    }

            }
            numberOfPlayers += 1;
        }

        public virtual void Activate()
        {
        }

        public void LoadContent()
        {
            font = content.Load<SpriteFont>("Fonts/screenFont");
            LoadScreenContent(content);
            SetupInputs();
        }

        protected virtual void LoadScreenContent(ContentManager content)
        {
        }
        
        protected virtual void SetupInputs()
        {
        }

        public void Update(GameTime gameTime)
        {
            input.BeginUpdate();
            UpdateScreen(gameTime);
            input.EndUpdate();
        }
   
        protected virtual void UpdateScreen(GameTime gameTime)
        {
        }

        public void Draw()
        {
            batch.Begin();
            DrawScreen(batch);
            batch.End();
        }

        protected virtual void DrawScreen(SpriteBatch batch)
        {
        }

        public void SaveState()
        {
            SaveScreenState();
        }

        protected virtual void SaveScreenState()
        {
        }

        static public int ScreenWidth
        {
            get { return game.GraphicsDevice.PresentationParameters.BackBufferWidth; }
        }

        static public int ScreenHeight
        {
            get { return game.GraphicsDevice.PresentationParameters.BackBufferHeight; }
        }

        static public Rectangle ScreenRectangle
        {
            get { return new Rectangle(0, 0, ScreenWidth, ScreenHeight); }
        }

        static public Rectangle ScreenLeftHalf
        {
            get { return new Rectangle(0, 0, (int)(ScreenWidth / 2), ScreenHeight); }
        }

        static public Rectangle ScreenRightHalf
        {
            get { return new Rectangle((int)(ScreenWidth / 2), 0, (int)(ScreenWidth / 2), ScreenHeight); }
        }
    }    
}
