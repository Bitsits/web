using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;

using SuperHeroBattle.Sprites;

namespace SuperHeroBattle
{
    class GameInformation
    {
        public static bool IsLandScape = false;
        
        static int WindowHeight = 800;
        public static int Height
        {
            get
            {
                if (IsLandScape)
                {
                    return WindowWidth;
                }
                return WindowHeight;
            }
        }

        static int WindowWidth = 480;
        public static int Width
        {
            get
            {
                if (IsLandScape)
                {
                    return WindowHeight;
                }
                return WindowWidth;
            }
        }

        public static Rectangle Screen
        {
            get { return new Rectangle(0, 0, Width, Height); }
        }

        public static Rectangle LeftHalfOfScreen
        {
            get { return new Rectangle(0, 0, Width / 2, Height); }
        }

        public static Rectangle RightSideOfScreen
        {
            get { return new Rectangle(240, 0, Width / 2, Height); }
        }
    }
}
