using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;

namespace SuperHeroBattle.Sprites
{
    class Health
    {
        Vector2 position;
        Color color;
        Texture2D texture;

        public int Size;

        public Health(ContentManager content, Vector2 position, Color color, int size)
        {
            texture = content.Load<Texture2D>("Images/Pixel");
            this.position = position;
            this.color = color;
            this.Size = size;
        }

        public void Draw(SpriteBatch batch)
        {
            batch.Draw(texture, new Rectangle((int)position.X, (int)position.Y, Size, 25), color);
        }
    }
}