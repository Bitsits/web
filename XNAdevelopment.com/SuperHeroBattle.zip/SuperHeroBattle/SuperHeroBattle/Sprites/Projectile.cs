﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace SuperHeroBattle.Sprites
{
    class Projectile : Sprite
    {
        public bool IsAlive = true;

        public Projectile(ContentManager content, Vector2 position, Color color, SpriteEffects direction)
            : base(content, "Images/Projectile")
        {
            Position = position;
            this.color = color;
            this.direction = direction;
        }


        protected override void UpdateSprite(GameTime gameTime, SuperHeroBattle.Inputs.GameInput input)
        {
            if (direction == SpriteEffects.None)
            {
                Position.X += 9;
            }
            else
            {
                Position.X -= 9;
            }

            base.UpdateSprite(gameTime, input);
        }
    }
}
