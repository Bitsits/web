using Microsoft.Xna.Framework.Content;

namespace SuperHeroBattle.Sprites
{
    class Background : Sprite
    {
        public Background(ContentManager content)
            : base(content, "Images/Background")
        {
        }
    }
}
