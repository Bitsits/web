using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace SuperHeroBattle.Sprites
{
    class SuperHero: Sprite
    {
        public int Speed;
        public int Health;
        public int Attack;

        private PlayerIndex player;

        Inputs.GameInput gameInput;

        public List<Projectile> projectiles = new List<Projectile>();

        public enum State
        {
            Alive,
            Dead,
            Sketch,
        }
        public State currenState = State.Sketch;
        double deadTimer;

        Health healthBar;
        SoundEffect superShot;
        SoundEffect die;
        SoundEffect respawn;
        SoundEffect hit;

        public SuperHero(int speed, int health, int attack, ContentManager content, string assetName, Inputs.GameInput input):base(content, assetName)
        {
            Speed = speed;
            Health = health;
            Health = 100;
            Attack = attack;

            superShot = content.Load<SoundEffect>("SoundEffects/SuperShot");
            die = content.Load<SoundEffect>("SoundEffects/Die");
            respawn = content.Load<SoundEffect>("SoundEffects/ReSpawn");
            hit = content.Load<SoundEffect>("SoundEffects/Hit");

            if (player == PlayerIndex.One)
            {
                healthBar = new Health(content, new Vector2(100, 50), Color.Green, Health);
            }
            else if (player == PlayerIndex.Two)
            {
                healthBar = new Health(content, new Vector2(100, 50), Color.Blue, Health);
            
            }
            else if (player == PlayerIndex.Three)
            {
                healthBar = new Health(content, new Vector2(100, 50), Color.Red, Health);
            }
            else if (player == PlayerIndex.Four)
            {
                healthBar = new Health(content, new Vector2(100, 50), Color.Yellow, Health);
            }

            this.gameInput = input;

            gameInput.AddGamePadInput("MoveUp", Microsoft.Xna.Framework.Input.Buttons.LeftThumbstickUp, false);
            gameInput.AddGamePadInput("MoveDown", Microsoft.Xna.Framework.Input.Buttons.LeftThumbstickDown, false);
            gameInput.AddGamePadInput("Left", Microsoft.Xna.Framework.Input.Buttons.LeftThumbstickLeft, false);
            gameInput.AddGamePadInput("Right", Microsoft.Xna.Framework.Input.Buttons.LeftThumbstickRight, false);
            gameInput.AddGamePadInput("Fire", Microsoft.Xna.Framework.Input.Buttons.A, true);
        }

        static Random random = new Random();
            
        public void MakeAlive()
        {
            currenState = State.Alive;
            Health = 100;
            healthBar.Size = 100;
            IsBaseDrawn = true;
            Position = new Vector2(random.Next(200, 1000), random.Next(200, 500));
            KillCount = 0;
            DeathCount = 0;        
        }

        public void SetPlayerIndex(PlayerIndex player)
        {
            this.player = player;
            if (player == PlayerIndex.One)
            {
                healthBar = new Health(content, new Vector2(100, 50), Color.Green, Health);
                playerColor = Color.Green;
            }
            else if (player == PlayerIndex.Two)
            {
                healthBar = new Health(content, new Vector2(400, 50), Color.Blue, Health);
                playerColor = Color.Blue;
            
            }
            else if (player == PlayerIndex.Three)
            {
                healthBar = new Health(content, new Vector2(700, 50), Color.Red, Health);
                playerColor = Color.Red;
            }
            else if (player == PlayerIndex.Four)
            {
                healthBar = new Health(content, new Vector2(1000, 50), Color.Yellow, Health);
                playerColor = Color.Yellow;
            }

            color = playerColor;
        }

        public Color playerColor = Color.White;

        public int KillCount = 0;
        public int DeathCount = 0;

        public void CheckCollision(SuperHero hero)
        {
            if (currenState == State.Alive)
            {
                foreach (Projectile shot in hero.projectiles)
                {
                    if (shot.IsAlive && shot.CollisionRectangle.Intersects(CollisionRectangle))
                    {
                        shot.IsAlive = false;
                        hit.Play();
                        Health -= 10;
                    }
                }

                if (Health < 0 && currenState != State.Dead)
                {
                    DeathCount += 1;
                    hero.KillCount += 1;
                    //Die and then respawn
                    die.Play();
                    currenState = State.Dead;
                    IsBaseDrawn = false;
                    deadTimer = 3500.0f;
                    foreach (Projectile projectile in projectiles)
                    {
                        projectile.IsAlive = false;
                    }
                }
            }

            healthBar.Size = Health;
        }

        protected override void UpdateSprite(GameTime gameTime, SuperHeroBattle.Inputs.GameInput input)
        {
            if (currenState == State.Sketch)
            {
                scale = 1.0f;
            }
            else
            {
                scale = 0.3f;
            }

            if (currenState == State.Alive)
            {
                if (gameInput.IsPressed("MoveUp", player))
                {
                    Position.Y -= Speed;
                }

                if (gameInput.IsPressed("MoveDown", player))
                {
                    Position.Y += Speed;
                }

                if (gameInput.IsPressed("Left", player))
                {
                    Position.X -= Speed;
                    direction = SpriteEffects.FlipHorizontally;
                }

                if (gameInput.IsPressed("Right", player))
                {
                    Position.X += Speed;
                    direction = SpriteEffects.None;
                }

                if (gameInput.IsPressed("Fire", player))
                {
                    superShot.Play();
                    bool isNewNeeded = true;
                    foreach (Projectile shot in projectiles)
                    {
                        if (!shot.IsAlive)
                        {
                            shot.IsAlive = true;
                            shot.Position = Position;
                            shot.direction = direction;
                            isNewNeeded = false;
                            break;
                        }
                    }

                    if (isNewNeeded)
                    {
                        projectiles.Add(new Projectile(content, Position, color, direction));
                    }
                }
            }

            if (Position.Y > 720)
            {
                Position.Y = 0;
            }

            if (Position.Y < 0 )
            {
                Position.Y = 700;
            }

            if (Position.X > 1280)
            {
                Position.X = 0;
            }

            if (Position.X < 0)
            {
                Position.X = 1200;
            }

            foreach (Projectile projectile in projectiles)
            {
                if (projectile.IsAlive)
                {
                    projectile.Update(gameTime, input);
                    if (projectile.Position.Y > 800 || projectile.Position.Y < -100 || projectile.Position.X > 1500 || projectile.Position.X < -100)
                    {
                        projectile.IsAlive = false;
                    }
                }
            }


            if (currenState == State.Dead)
            {
                deadTimer -= gameTime.ElapsedGameTime.TotalMilliseconds;
                if (deadTimer < 0)
                {
                    respawn.Play();
                    MakeAlive();
                }
            }
        }

        protected override void DrawSprite(SpriteBatch batch)
        {
            foreach (Projectile projectile in projectiles)
            {
                if (projectile.IsAlive)
                {
                    projectile.Draw(batch);
                }
            }

            if (currenState == State.Alive)
            {
                healthBar.Draw(batch);
            }
        }
    }
}