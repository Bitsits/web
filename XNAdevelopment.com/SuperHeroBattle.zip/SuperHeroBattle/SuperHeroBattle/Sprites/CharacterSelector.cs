using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using SuperHeroBattle.Inputs;

namespace SuperHeroBattle.Sprites
{
    class CharacterSelector 
    {
        public PlayerIndex player;

        List<SuperHero> heroes = new List<SuperHero>();
        int currentHero = 0;
        
        static List<PlayerIndex> availablePlayers = new List<PlayerIndex>();
        static bool isStaticInformationLoaded = false;
        static GameInput input;

        Vector2 position;
        static SpriteFont font;

        public enum State
        {
            Waiting,
            Selecting,
            Selected
        }
        public State currentState = State.Waiting;

        public SuperHero Hero()
        {
            heroes[currentHero].SetPlayerIndex(player);
            return heroes[currentHero];
        }

        public CharacterSelector(ContentManager content, PlayerIndex player, Vector2 position, GameInput input) 
        {
            LoadContent(content, position, input);
            availablePlayers.Remove(player);
            this.player = player;
            currentState = State.Selecting;
        }
        
        public CharacterSelector(ContentManager content, Vector2 position, GameInput input)
        {
            LoadContent(content, position, input);
        }

        private void LoadContent(ContentManager content, Vector2 position, GameInput gameInput)
        {
            if (!isStaticInformationLoaded)
            {
                availablePlayers.Add(PlayerIndex.One);
                availablePlayers.Add(PlayerIndex.Two);
                availablePlayers.Add(PlayerIndex.Three);
                availablePlayers.Add(PlayerIndex.Four);

                input = gameInput;

                input.AddGamePadInput("Select", Microsoft.Xna.Framework.Input.Buttons.A, true);
                input.AddGamePadInput("Up", Microsoft.Xna.Framework.Input.Buttons.LeftThumbstickUp, true);
                input.AddGamePadInput("Down", Microsoft.Xna.Framework.Input.Buttons.LeftThumbstickDown, true);
                
                input.AddKeyboardInput("Select", Microsoft.Xna.Framework.Input.Keys.A, true);
                input.AddKeyboardInput("Select", Microsoft.Xna.Framework.Input.Keys.Space, true);
                input.AddKeyboardInput("Up", Microsoft.Xna.Framework.Input.Keys.Up, true);
                input.AddKeyboardInput("Down", Microsoft.Xna.Framework.Input.Keys.Down, true);

                font = content.Load<SpriteFont>("Fonts/myFont");

                isStaticInformationLoaded = true;
            }


            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero001", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero002", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero003", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero004", gameInput));

            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero005", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero006", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero007", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero008", gameInput));

            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero009", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero010", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero011", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero012", gameInput));

            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero013", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero014", gameInput));
            heroes.Add(new SuperHero(4, 5, 1, content, "Images/Heroes/Hero015", gameInput));
            
            foreach (SuperHero hero in heroes)
            {
                hero.Position = position;
            }

            this.position = position;
        }

        public void Reset()
        {
            if (currentState == State.Selected)
            {
                currentState = State.Selecting;
            }

            foreach (SuperHero hero in heroes)
            {
                hero.Position = position;
                hero.currenState = SuperHero.State.Sketch;
                hero.scale = 1.0f;
            }
        }

        public void Update(GameTime gameTime)
        {
            switch (currentState)
            {
                case State.Waiting:
                    {
                        foreach (PlayerIndex index in availablePlayers)
                        {
                            if (input.IsPressed("Select", index))
                            {
                                Screens.Screen.AddPlayer(index);
                                player = index;
                                availablePlayers.Remove(index);
                                currentState = State.Selecting;
                                break;
                            }
                        }
                        break;
                    }

                case State.Selecting:
                    {
                        if (input.IsPressed("Up", player))
                        {
                            currentHero -= 1;
                            if (currentHero < 0)
                            {
                                currentHero = heroes.Count - 1;
                            }
                        }
                        else if (input.IsPressed("Down", player))
                        {
                            currentHero += 1;
                            if (currentHero > heroes.Count - 1)
                            {
                                currentHero = 0;
                            }
                        }
                        else if (input.IsPressed("Select", player))
                        {
                            currentState = State.Selected;
                        }

                        break;
                    }
            }
        }

        public void Draw(SpriteBatch batch)
        {
            switch (currentState)
            {
                case State.Waiting:
                    {
                        batch.DrawString(font, "Press A to Join", position + new Vector2(100, 400), Color.White);
                        break;
                    }

                case State.Selecting:
                    { 
                         
                        heroes[currentHero].Draw(batch);
                        batch.DrawString(font, "Press Up/Down to Change Hero", position + new Vector2(40, 580), Color.White);
                        batch.DrawString(font, "Press A to Select Hero", position + new Vector2(50, 600), Color.White);
                        break;
                    }

                case State.Selected:
                    {
                        heroes[currentHero].Draw(batch);
                        batch.DrawString(font, "Ready!", position + new Vector2(180, 600), Color.White);
                        batch.DrawString(font, "Press Start", position + new Vector2(180, 650), Color.White);
                        break;
                    }
            }
        }
    }
}