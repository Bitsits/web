using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperHeroBattle
{
    class PlayerScreen
    {
        //Press Start to Join
        //Players press start to join, then they pick their hero
        //then they customize their stats

        //Battle Screen
        //Players move around the board and shoot, lose health
        //die and respawn until the time is up, 3 minutes?
        //Up down, left right (flying around), no obstacles.

        //Winner Screen
        //Player with most defeats wins, give awards to everyone

        //Repeat :)
    }
}