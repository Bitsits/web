﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace ItsAControlThing
{
    class Button : Text
    {
        public enum Buttons
        {
            LeftThumbstick,
            RightThumbstick,
            DirectionalPad,
            Back,
            Guide,
            Start,
            X,
            A,
            Y,
            B,
            RightShoulder,
            LeftShoulder,
            RightTrigger,
            LeftTrigger,
            None
        }

        public Buttons ButtonType;

        const string mButtonAssetName = "xboxControllerSpriteFont";

        public static string[] ButtonText = new string[] { Button.AButton, Button.Back, Button.BButton, Button.DPad, Button.Guide, Button.LeftShoulder, Button.LeftThumb, Button.LeftTrigger, Button.RightShoulder, Button.RightThumb, Button.RightTrigger, Button.Start, Button.XButton, Button.YButton };
        
        public Button(ContentManager theContent, Buttons theButton, Vector2 thePosition)
            : base(theContent, "", mButtonAssetName, thePosition, Color.White)
        {
            ChangeButtonType(theButton);
        }

        public void ChangeButtonType(Buttons theButton)
        {
            ButtonType = theButton;
            mText = "";

            switch (theButton)
            {
                case Buttons.LeftThumbstick:
                    {
                        mText = " ";
                        break;
                    }

                case Buttons.RightThumbstick:
                    {
                        mText = "\"";
                        break;
                    }

                case Buttons.DirectionalPad:
                    {
                        mText = "!";
                        break;
                    }

                case Buttons.Back:
                    {
                        mText = "#";
                        break;
                    }

                case Buttons.Guide:
                    {
                        mText = "$";
                        break;
                    }

                case Buttons.Start:
                    {
                        mText = "%";
                        break;
                    }

                case Buttons.X:
                    {
                        mText = "&";
                        break;
                    }

                case Buttons.Y:
                    {
                        mText = "(";
                        break;
                    }

                case Buttons.A:
                    {
                        mText = "'";
                        break;
                    }

                case Buttons.B:
                    {
                        mText = ")";
                        break;
                    }

                case Buttons.LeftShoulder:
                    {
                        mText = "-";
                        break;
                    }

                case Buttons.RightShoulder:
                    {
                        mText = "*";
                        break;
                    }

                case Buttons.RightTrigger:
                    {
                        mText = "+";
                        break;
                    }

                case Buttons.LeftTrigger:
                    {
                        mText = ",";
                        break;
                    }
            }
        }

        public void ChangeButtonType(string theButton)
        {
            switch (theButton)
            {
                case XButton:
                    {
                        ChangeButtonType(Buttons.X);
                        break;
                    }

                case YButton:
                    {
                        ChangeButtonType(Buttons.Y);
                        break;
                    }

                case AButton:
                    {
                        ChangeButtonType(Buttons.A);
                        break;
                    }

                case BButton:
                    {
                        ChangeButtonType(Buttons.B);
                        break;
                    }

                case RightTrigger:
                    {
                        ChangeButtonType(Buttons.RightTrigger);
                        break;
                    }

                case LeftTrigger:
                    {
                        ChangeButtonType(Buttons.LeftTrigger);
                        break;
                    }

                case Back:
                    {
                        ChangeButtonType(Buttons.Back);
                        break;
                    }

                case DPad:
                    {
                        ChangeButtonType(Buttons.DirectionalPad);
                        break;
                    }

                case Guide:
                    {
                        ChangeButtonType(Buttons.Guide);
                        break;
                    }

                case LeftShoulder:
                    {
                        ChangeButtonType(Buttons.LeftShoulder);
                        break;
                    }

                case LeftThumb:
                    {
                        ChangeButtonType(Buttons.LeftThumbstick);
                        break;
                    }

                case RightShoulder:
                    {
                        ChangeButtonType(Buttons.RightShoulder);
                        break;
                    }

                case RightThumb:
                    {
                        ChangeButtonType(Buttons.RightThumbstick);
                        break;
                    }

                case Start:
                    {
                        ChangeButtonType(Buttons.Start);
                        break;
                    }
            }
        }

        public const string XButton = "[X]";
        public const string YButton = "[Y]";
        public const string AButton = "[A]";
        public const string BButton = "[B]";
        public const string RightTrigger = "[RTRIGGER]";
        public const string LeftTrigger = "[LTRIGGER]";
        public const string Back = "[BACK]";
        public const string DPad = "[DPAD]";
        public const string Guide = "[GUIDE]";
        public const string LeftShoulder = "[LSHOULDER]";
        public const string LeftThumb = "[LTHUMB]";
        public const string RightShoulder = "[RSHOULDER]";
        public const string RightThumb = "[RTHUMB]";
        public const string Start = "[START]";

        public Vector2 Length()
        {
            Vector2 aLength = mFont.MeasureString(mText);
            aLength.Y = aLength.Y / 3;
            aLength.X = aLength.X + 10;
            
            return aLength;
        }
    }
}
