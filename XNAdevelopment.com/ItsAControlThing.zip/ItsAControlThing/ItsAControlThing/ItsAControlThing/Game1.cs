using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace ItsAControlThing
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Text mGameText;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 720;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            mGameText = new Text(Content, "Press [A] to begin", "Courier", new Vector2(200, 200), Color.White);

            mGameText.mText = "Press " + Button.AButton + " to start";
            mGameText.mText = "I wonder if this will error?";
            mGameText.mText = Button.YButton + " looks good.";
            mGameText.mText = "Does this look ok? " + Button.RightTrigger;
            mGameText.mText = "Not perfect " + Button.LeftThumb + " but ok.";

            mGameText.Center(new Rectangle(0, 0, graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight), Text.Alignment.Both);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            mGameText.Position = new Vector2(10, 20);
            mGameText.mText = "Press " + Button.AButton + " to start";
            mGameText.Draw(spriteBatch);

            mGameText.Position = new Vector2(50, 100);
            mGameText.mText = "You can write just text.";
            mGameText.Draw(spriteBatch);

            mGameText.Position = new Vector2(30, 190);
            mGameText.mText = Button.YButton + " place it at the front";
            mGameText.Draw(spriteBatch);

            mGameText.Position = new Vector2(110, 280);
            mGameText.mText = "Or put it at the end " + Button.RightTrigger;
            mGameText.Draw(spriteBatch);

            mGameText.Position = new Vector2(60, 400);
            mGameText.mText = "Not perfect " + Button.LeftThumb + " but ok.";
            mGameText.Draw(spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
