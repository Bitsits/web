using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace DriveFastAndDodgeTheOncomingObstacle
{
    class Hazard
    {
        public Vector2 Position;
        public bool Visible = true;

        public Hazard()
        {
        }
    }
}

