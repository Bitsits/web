using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace MoveTheGrowingCreature
{
    class Piece
    {

        private Vector2 mPosition;
        public Vector2 Position
        {
            get { return mPosition; }
            set { mPosition = value; }
        }

        private BoundingSphere mCollisionArea;
        public BoundingSphere CollisionArea
        {
            get { return mCollisionArea; }
            set { mCollisionArea = value; }
        }

        private Direction mDirection;
        public Direction CurrentDirection
        {
            get { return mDirection; }
            set { mDirection = value; }
        }

        private List<Waypoint> mWaypoints = new List<Waypoint>();
        public List<Waypoint> Waypoints
        {
            get { return mWaypoints; }
            set { mWaypoints = value; }
        }

    }
}
