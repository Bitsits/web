using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace MoveTheGrowingCreature
{
    class Waypoint
    {

        public Waypoint(Vector2 thePosition, Direction theDirection)
        {
            Position = thePosition;
            CurrentDirection = theDirection;
        }

        Vector2 mPosition;
        public Vector2 Position
        {
            get { return mPosition; }
            set { mPosition = value; }
        }       

        Direction mDirection;
        public Direction CurrentDirection
        {
            get { return mDirection; }
            set { mDirection = value; }
        }
    }
}
