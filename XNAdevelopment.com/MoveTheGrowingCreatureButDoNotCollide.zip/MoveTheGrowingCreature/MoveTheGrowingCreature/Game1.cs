using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace MoveTheGrowingCreature
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }

    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D mCreature;
        Texture2D mTitle;
        Vector2 mPosition = new Vector2(150, 80);
        float mRotation = 0;

        BoundingBox mTopWall = new BoundingBox(new Vector3(30, 10, 0), new Vector3(743, 32, 0));
        BoundingBox mBottomWall = new BoundingBox(new Vector3(30, 560, 0), new Vector3(743, 32, 0));
        BoundingBox mLeftWall = new BoundingBox(new Vector3(55, 10, 0), new Vector3(32, 570, 0));
        BoundingBox mRightWall = new BoundingBox(new Vector3(755, 10, 0), new Vector3(32, 570, 0));

        BoundingSphere mHead;

        //Un-attached tail piece
        Piece mTailPiece = new Piece();

        Dictionary<int, Piece> mTails = new Dictionary<int, Piece>();

        Random mRandom = new Random();
        Direction mDirection = Direction.Down;

        //Current Score
        int mScore = 0;

        SpriteFont mTrueTypeFont;

        private enum GameState
        {
            Title,
            Running,
            GameOver
        }

        GameState mCurrentState = GameState.Title;



        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            mTailPiece.Position = new Vector2(mRandom.Next(100, 700), mRandom.Next(80, 510));
            mCreature = Content.Load<Texture2D>("CreatureSheet");
            mTitle = Content.Load<Texture2D>("Title");

            mTrueTypeFont = Content.Load<SpriteFont>("Miramonte");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape) == true)
                this.Exit();

            // TODO: Add your update logic here
            GamePadState aGamePad = GamePad.GetState(PlayerIndex.One);
            KeyboardState aKeyboard = Keyboard.GetState();

            switch (mCurrentState)
            {
                case GameState.Title:
                    {
                        if (aGamePad.Buttons.Start == ButtonState.Pressed || aKeyboard.IsKeyDown(Keys.Space) == true)
                        {
                            mCurrentState = GameState.Running;
                        }
                        break;
                    }

                case GameState.Running:
                    {

                        Direction aNewDirection = mDirection;

                        if (aGamePad.ThumbSticks.Left.X > 0 || aKeyboard.IsKeyDown(Keys.Right) == true)
                        {
                            aNewDirection = Direction.Right;
                            mRotation = MathHelper.ToRadians(270);
                        }
                        else if (aGamePad.ThumbSticks.Left.X < 0 || aKeyboard.IsKeyDown(Keys.Left) == true)
                        {
                            aNewDirection = Direction.Left;
                            mRotation = MathHelper.ToRadians(90);
                        }
                        else if (aGamePad.ThumbSticks.Left.Y > 0 || aKeyboard.IsKeyDown(Keys.Up) == true)
                        {
                            aNewDirection = Direction.Up;
                            mRotation = MathHelper.ToRadians(180);
                        }
                        else if (aGamePad.ThumbSticks.Left.Y < 0 || aKeyboard.IsKeyDown(Keys.Down) == true)
                        {
                            aNewDirection = Direction.Down;
                            mRotation = 0;
                        }

                        //Add Waypoint
                        AddWaypoint(aNewDirection);

                        //Move the head pieces
                        MoveHeadPiece();

                        bool aIsCollision = false;

                        //Check to see if the Head piece has run into the Top wall
                        if (HandleBoundaryCollision(mTopWall, ref mPosition.Y, 1) == true)
                        {
                            aIsCollision = true;
                        }


                        //Check to see if the Head piece has run into the Bottom wall
                        if (HandleBoundaryCollision(mBottomWall, ref mPosition.Y, -1) == true)
                        {
                            aIsCollision = true;
                        }

                        //Check to see if the Head piece has run into the Left wall
                        if (HandleBoundaryCollision(mLeftWall, ref mPosition.X, 1) == true)
                        {
                            aIsCollision = true;
                        }

                        //Check to see if the Head piece has run into the Right wall
                        if (HandleBoundaryCollision(mRightWall, ref mPosition.X, -1) == true)
                        {
                            aIsCollision = true;
                        }

                        //Check to see if the creature has collided with it's tail
                        if (HandleTailCollision() == true)
                        {
                            aIsCollision = true;
                        }

                        //Check to see if the Head piece has picked up an unattached piece
                        HandleUnattachedPieceCollision();

                        if (aIsCollision == false)
                        {
                            //Move the tail pieces
                            MoveTailPiece();
                        }

                        if (aIsCollision == true)
                        {

                            mCurrentState = GameState.GameOver;
                        }

                        break;
                    }

                case GameState.GameOver:
                    {
                        if (aGamePad.Buttons.Start == ButtonState.Pressed || aKeyboard.IsKeyDown(Keys.Space) == true)
                        {
                            mScore = 0;
                            mTails.Clear();
                            mPosition = new Vector2(150, 80);
                            mDirection = Direction.Down;
                            mRotation = 0;
                            mTailPiece.Position = new Vector2(mRandom.Next(100, 700), mRandom.Next(80, 510));

                            mCurrentState = GameState.Running;
                        }
                        break;
                    }
            }


            base.Update(gameTime);
        }


        private void HandleUnattachedPieceCollision()
        {
            //Check to see if the head collides with the un-attached tail piece
            mHead = new BoundingSphere(new Vector3(mPosition.X, mPosition.Y, 0), 50);
            mTailPiece.CollisionArea = new BoundingSphere(new Vector3(mTailPiece.Position.X, mTailPiece.Position.Y, 0), 5);
            if (mHead.Intersects(mTailPiece.CollisionArea) == true)
            {
                AddTailPiece();
                mTailPiece.Position = new Vector2(mRandom.Next(100, 700), mRandom.Next(80, 510));
                mScore += 100 + ((mTails.Count - 1) * 50);
            }
        }


        private bool HandleTailCollision()
        {
            //Check to see if the head collides with the un-attached tail piece
            mHead = new BoundingSphere(new Vector3(mPosition.X, mPosition.Y, 0), 50);
            for (int aIndex = 2; aIndex <= mTails.Count; aIndex++)
            {
                mTails[aIndex].CollisionArea = new BoundingSphere(new Vector3(mTails[aIndex].Position.X, mTails[aIndex].Position.Y, 0), 5);
                if (mHead.Intersects(mTails[aIndex].CollisionArea) == true)
                {
                    return true;
                }
            }

            return false;
        }


        private bool HandleBoundaryCollision(BoundingBox theBoundary, ref float thePosition, int theMovement)
        {
            bool aIsCollision = false;
            mHead = new BoundingSphere(new Vector3(mPosition.X, mPosition.Y, 0), 50);
            if (theBoundary.Intersects(mHead) == true)
            {
                do
                {
                    thePosition += theMovement;
                    mHead = new BoundingSphere(new Vector3(mPosition.X, mPosition.Y, 0), 50);
                } while (theBoundary.Intersects(mHead) == true);

                aIsCollision = true;
            }

            return aIsCollision;
        }

        private void MoveHeadPiece()
        {
            //Move the head
            switch (mDirection)
            {
                case Direction.Down:
                    {
                        mPosition.Y += 4;
                        break;
                    }
                case Direction.Up:
                    {
                        mPosition.Y -= 4;
                        break;
                    }
                case Direction.Left:
                    {
                        mPosition.X -= 4;
                        break;
                    }
                case Direction.Right:
                    {
                        mPosition.X += 4;
                        break;
                    }
            }
        }

        private void MoveTailPiece()
        {
            //Cycle through each piece and move them in the appropriate direction
            foreach (Piece aPiece in mTails.Values)
            {
                if (aPiece.Waypoints.Count == 0)
                {
                    aPiece.CurrentDirection = mDirection;
                }

                switch (aPiece.CurrentDirection)
                {
                    case Direction.Down:
                        {
                            aPiece.Position += new Vector2(0, 4);

                            if (aPiece.Waypoints.Count > 0)
                            {
                                if (aPiece.Position.Y >= aPiece.Waypoints[0].Position.Y)
                                {
                                    aPiece.Position = new Vector2(aPiece.Position.X, aPiece.Waypoints[0].Position.Y);
                                    aPiece.CurrentDirection = aPiece.Waypoints[0].CurrentDirection;
                                    aPiece.Waypoints.RemoveAt(0);
                                }
                            }


                            break;
                        }
                    case Direction.Up:
                        {
                            aPiece.Position -= new Vector2(0, 4);
                            if (aPiece.Waypoints.Count > 0)
                            {
                                if (aPiece.Position.Y <= aPiece.Waypoints[0].Position.Y)
                                {
                                    aPiece.Position = new Vector2(aPiece.Position.X, aPiece.Waypoints[0].Position.Y);
                                    aPiece.CurrentDirection = aPiece.Waypoints[0].CurrentDirection;
                                    aPiece.Waypoints.RemoveAt(0);
                                }
                            }
                            break;
                        }
                    case Direction.Left:
                        {
                            aPiece.Position -= new Vector2(4, 0);
                            if (aPiece.Waypoints.Count > 0)
                            {
                                if (aPiece.Position.X <= aPiece.Waypoints[0].Position.X)
                                {
                                    aPiece.Position = new Vector2(aPiece.Waypoints[0].Position.X, aPiece.Position.Y);
                                    aPiece.CurrentDirection = aPiece.Waypoints[0].CurrentDirection;
                                    aPiece.Waypoints.RemoveAt(0);
                                }
                            }
                            break;
                        }
                    case Direction.Right:
                        {
                            aPiece.Position += new Vector2(4, 0);
                            if (aPiece.Waypoints.Count > 0)
                            {
                                if (aPiece.Position.X >= aPiece.Waypoints[0].Position.X)
                                {
                                    aPiece.Position = new Vector2(aPiece.Waypoints[0].Position.X, aPiece.Position.Y);
                                    aPiece.CurrentDirection = aPiece.Waypoints[0].CurrentDirection;
                                    aPiece.Waypoints.RemoveAt(0);
                                }
                            }
                            break;
                        }

                }
            }
        }

        private void AddWaypoint(Direction theNewDirection)
        {
            //Check to see if the creature is moving in a new direction. If it is, then set the direction
            //and add a new Waypoint to each of the tailpieces.
            if (theNewDirection != mDirection)
            {
                mDirection = theNewDirection;

                //Add a new WayPoint to all the current children
                if (mTails.Count > 0)
                {
                    for (int aIndex = 1; aIndex <= mTails.Count; aIndex++)
                    {
                        mTails[aIndex].Waypoints.Add(new Waypoint(mPosition, mDirection));
                    }
                }
            }
        }

        private void AddTailPiece()
        {

            Piece aPiece = new Piece();
            aPiece.Position = new Vector2(0, 0);
            mTails.Add(mTails.Count + 1, aPiece);

            Vector2 aPosition;
            if (mTails.Count <= 1)
            {
                aPosition = mPosition;
                mTails[mTails.Count].CurrentDirection = mDirection;
            }
            else
            {
                aPosition = mTails[mTails.Count - 1].Position;
                mTails[mTails.Count].CurrentDirection = mTails[mTails.Count - 1].CurrentDirection;
            }

            int aTailOffset = 50;

            switch (mTails[mTails.Count].CurrentDirection)
            {
                case Direction.Down:
                    {
                        mTails[mTails.Count].Position = new Vector2(aPosition.X, aPosition.Y - aTailOffset);
                        break;
                    }
                case Direction.Up:
                    {
                        mTails[mTails.Count].Position = new Vector2(aPosition.X, aPosition.Y + aTailOffset);
                        break;
                    }
                case Direction.Left:
                    {
                        mTails[mTails.Count].Position = new Vector2(aPosition.X + aTailOffset, aPosition.Y);
                        break;
                    }
                case Direction.Right:
                    {
                        mTails[mTails.Count].Position = new Vector2(aPosition.X - aTailOffset, aPosition.Y);
                        break;
                    }
            }

            if (mTails.Count > 1)
            {
                foreach (Waypoint aWaypoint in mTails[mTails.Count - 1].Waypoints)
                {
                    mTails[mTails.Count].Waypoints.Add(new Waypoint(aWaypoint.Position, aWaypoint.CurrentDirection));
                }
            }
            else
            {
                mTails[mTails.Count].Waypoints.Add(new Waypoint(mPosition, mDirection));
            }
        }



        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            spriteBatch.Begin();

            switch (mCurrentState)
            {
                case GameState.Title:
                    {
                        spriteBatch.Draw(mTitle, new Rectangle(0, 0, this.Window.ClientBounds.Width, this.Window.ClientBounds.Height), Color.White);
                        break;
                    }

                case GameState.Running:
                    {

                        spriteBatch.Draw(mCreature, mPosition, new Rectangle(13, 48, 97, 77), Color.White, mRotation, new Vector2(97 / 2, 77 / 2), 1, SpriteEffects.None, 0);

                        //Draw the top wall
                        spriteBatch.Draw(mCreature, new Vector2(30, 10), new Rectangle(0, 0, 205, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(235, 10), new Rectangle(0, 0, 205, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(440, 10), new Rectangle(0, 0, 205, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(645, 10), new Rectangle(0, 0, 128, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);

                        //Draw the left wall
                        spriteBatch.Draw(mCreature, new Vector2(65, 10), new Rectangle(0, 0, 205, 32), Color.White, MathHelper.ToRadians(90), new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(65, 215), new Rectangle(0, 0, 205, 32), Color.White, MathHelper.ToRadians(90), new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(65, 420), new Rectangle(0, 0, 150, 32), Color.White, MathHelper.ToRadians(90), new Vector2(0, 0), 1, SpriteEffects.None, 0);

                        //Draw the right wall
                        spriteBatch.Draw(mCreature, new Vector2(775, 10), new Rectangle(0, 0, 205, 32), Color.White, MathHelper.ToRadians(90), new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(775, 215), new Rectangle(0, 0, 205, 32), Color.White, MathHelper.ToRadians(90), new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(775, 420), new Rectangle(0, 0, 150, 32), Color.White, MathHelper.ToRadians(90), new Vector2(0, 0), 1, SpriteEffects.None, 0);

                        //Draw the bottom wall
                        spriteBatch.Draw(mCreature, new Vector2(30, 550), new Rectangle(0, 0, 205, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(235, 550), new Rectangle(0, 0, 205, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(440, 550), new Rectangle(0, 0, 205, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);
                        spriteBatch.Draw(mCreature, new Vector2(645, 550), new Rectangle(0, 0, 128, 32), Color.White, 0, new Vector2(0, 0), 1, SpriteEffects.None, 0);

                        //Draw the un-attached tail piece
                        spriteBatch.Draw(mCreature, mTailPiece.Position, new Rectangle(139, 52, 55, 55), Color.White, 0, new Vector2(55 / 2, 55 / 2), 1, SpriteEffects.None, 0);

                        //Draw the tails
                        foreach (Piece aPiece in mTails.Values)
                        {
                            spriteBatch.Draw(mCreature, aPiece.Position, new Rectangle(139, 52, 55, 55), Color.White, 0, new Vector2(55 / 2, 55 / 2), 1, SpriteEffects.None, 0);
                        }

                        spriteBatch.DrawString(mTrueTypeFont, "Score: " + mScore.ToString(), new Vector2(38, 8), Color.White);
                        spriteBatch.DrawString(mTrueTypeFont, "Score: " + mScore.ToString(), new Vector2(42, 8), Color.White);
                        spriteBatch.DrawString(mTrueTypeFont, "Score: " + mScore.ToString(), new Vector2(38, 12), Color.White);
                        spriteBatch.DrawString(mTrueTypeFont, "Score: " + mScore.ToString(), new Vector2(42, 12), Color.White);
                        spriteBatch.DrawString(mTrueTypeFont, "Score: " + mScore.ToString(), new Vector2(40, 10), Color.Green);

                        break;
                    }

                case GameState.GameOver:
                    {
                        spriteBatch.DrawString(mTrueTypeFont, "Game Over", new Vector2(100, 100), Color.Green, 0.0f, Vector2.Zero, 5.0f, SpriteEffects.None, 0);
                        spriteBatch.DrawString(mTrueTypeFont, "Final Score: " + mScore.ToString(), new Vector2(250, 230), Color.Green, 0.0f, Vector2.Zero, 2.0f, SpriteEffects.None, 0);
                        spriteBatch.DrawString(mTrueTypeFont, "Press 'Start' to play again, 'Back' to exit.", new Vector2(180, 300), Color.Green);

                        break;
                    }
            }

            spriteBatch.End();



            base.Draw(gameTime);
        }
    }
}
