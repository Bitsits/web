using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PathfindingSample
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        MouseState MSStateCurrent;
        MouseState MSStatePrew;

        KeyboardState KBStateCurrent;
        KeyboardState KBStatePrew;

        Texture2D tex_Quad32x32;
        Texture2D tex_Circle32x32;
        SpriteFont spritefont_DebugText;

        byte[,] PathGrid;
        byte[,] DrawGrid;

        ushort width = 24;
        ushort height = 24;

        enum DrawType
        {
            DrawFree,
            DrawWall
        }

        DrawType drawType = DrawType.DrawWall;

        Point Start;
        Point End;

        Point MsPos = new Point();
        Point prewMsPos = new Point();

        PathFinder myPathFinder;
        List<PathReturnNode> foundPath;

        int tileWidth = 32;

        float elapsedTime = 0.0f;

        MovableObject myMovable;
        Vector2 Click;

        int offX = 0;
        int offY = 0;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 768;
            graphics.IsFullScreen = false;
            graphics.SynchronizeWithVerticalRetrace = false;
            
            IsFixedTimeStep = false;
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            PathGrid = new byte[width, height];
            DrawGrid = new byte[width, height];

            for (int y = 0; y < height; y += 1)
            {
                for (int x = 0; x < width; x += 1)
                {
                    PathGrid[x, y] = 1;
                    DrawGrid[x, y] = 1;
                }
            }

            myPathFinder = new PathFinder(PathGrid);
            myPathFinder.HeuristicEstimate = 8;

            MovableObject.Initalize(24, tileWidth);

            myMovable = new MovableObject(new Vector2(16, 16));

            base.Initialize();

        }

        protected override void LoadContent()
        {
             spriteBatch = new SpriteBatch(GraphicsDevice);
             tex_Quad32x32 = Content.Load<Texture2D>("door_mossy");
             tex_Circle32x32 = Content.Load<Texture2D>("ship");             
             spritefont_DebugText = Content.Load<SpriteFont>("DebugText");

             IsMouseVisible = true;
        }

        protected override void UnloadContent()
        {
        }

        protected override void Update(GameTime gameTime)
        {
            MSStateCurrent = Mouse.GetState();
            KBStateCurrent = Keyboard.GetState();

            elapsedTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            prewMsPos = MsPos;  

            if (KBStateCurrent.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }
            if (KBStateCurrent.IsKeyDown(Keys.F1) && KBStatePrew.IsKeyUp(Keys.F1))
            {
                graphics.ToggleFullScreen();
            }

            if (KBStateCurrent.IsKeyDown(Keys.Add) && KBStatePrew.IsKeyUp(Keys.Add))
            {
                myPathFinder.HeuristicEstimate += 1;
            }
            if (KBStateCurrent.IsKeyDown(Keys.Subtract) && KBStatePrew.IsKeyUp(Keys.Subtract))
            {
                myPathFinder.HeuristicEstimate -= 1;
            }


            if (KBStateCurrent.IsKeyDown(Keys.F) && KBStatePrew.IsKeyUp(Keys.F))
            {
                drawType = DrawType.DrawFree;
            }
            if (KBStateCurrent.IsKeyDown(Keys.W) && KBStatePrew.IsKeyUp(Keys.W))
            {
                drawType = DrawType.DrawWall;
            }

            if (MSStateCurrent.RightButton == ButtonState.Pressed && MSStatePrew.RightButton == ButtonState.Released)
            {
                Click = new Vector2(MSStateCurrent.X, MSStateCurrent.Y);

                MsPos.X = (int)(MSStateCurrent.X + (offX * tileWidth)) / tileWidth;
                MsPos.Y = (int)(MSStateCurrent.Y + (offY * tileWidth)) / tileWidth;

                Start = new Point((int)(myMovable.PositionCurrent.X / tileWidth), (int)(myMovable.PositionCurrent.Y / tileWidth));
                End = new Point(MsPos.X, MsPos.Y);

                if (Start == End)
                {
                    myMovable.LinearMove(myMovable.PositionCurrent, Click);
                }
                else
                {
                    foundPath = myPathFinder.FindPath(Start, End);  
                    
                    if (foundPath != null)
                        myMovable.PathMove(ref foundPath, myMovable.PositionCurrent, Click);
                }
            }      

            //Wall drawing / removing
            if (MSStateCurrent.LeftButton == ButtonState.Pressed)
            {
                MsPos.X = (int)(MSStateCurrent.X + (offX * 8)) / tileWidth;
                MsPos.Y = (int)(MSStateCurrent.Y + (offY * 8)) / tileWidth;

                if ((MsPos.X < width) && (MsPos.Y < height) && (MsPos.X >= 0) && (MsPos.Y >= 0))
                {
                    switch (drawType)
                    {
                        case DrawType.DrawWall:
                            {
                                PathGrid[MsPos.X, MsPos.Y] = 0;
                                DrawGrid[MsPos.X, MsPos.Y] = 0;
                            }
                            break;
                        case DrawType.DrawFree:
                            {
                                PathGrid[MsPos.X, MsPos.Y] = 1;
                                DrawGrid[MsPos.X, MsPos.Y] = 1;
                            }
                            break;
                    }
                }
            }

            myMovable.Update(elapsedTime);

            MSStatePrew = MSStateCurrent;
            KBStatePrew = KBStateCurrent;

            base.Update(gameTime);


        }

        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Cornsilk);

            Color TextCol = new Color(255, 255, 255, 255);

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.None);

            for (int y = offY; y < offY + 24; y += 1)
            {
                for (int x = offX; x < offX + 24; x += 1)
                {
                    int posYY = offY * tileWidth;
                    int posXX = offX * tileWidth;

                    Rectangle rect = new Rectangle(x * tileWidth - posXX, y * tileWidth - posYY, tileWidth, tileWidth);

                    if (DrawGrid[x, y] == 0)
                    {
                        spriteBatch.Draw(tex_Quad32x32, rect, Color.DarkCyan);
                    }
                    else if (DrawGrid[x, y] == 1)
                    {
                        if (myPathFinder.WalkedNodes[x, y] == 1)
                        {
                            spriteBatch.Draw(tex_Quad32x32, rect, Color.Aqua);
                        }
                        else
                        {
                            spriteBatch.Draw(tex_Quad32x32, rect, Color.Silver);
                        }
                    }
                }
            }

            //Draw "character"
            spriteBatch.Draw(tex_Circle32x32, myMovable.PositionCurrent, null, Color.White, myMovable.Direction, new Vector2(16, 16), 1.0f, SpriteEffects.None, 0f);

            //Draw Text
            spriteBatch.DrawString(spritefont_DebugText, MsPos.ToString(), new Vector2(790, 8), Color.Black);
            spriteBatch.DrawString(spritefont_DebugText, "H = " + myPathFinder.HeuristicEstimate.ToString(), new Vector2(790, 28), Color.Black);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            using (Game1 game = new Game1())
            {
                 game.Run();
            }
        }
    }
}
