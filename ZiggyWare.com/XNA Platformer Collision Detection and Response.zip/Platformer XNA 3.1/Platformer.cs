// Part of the "Playing with Platforms" article by A. Scott McCallum ("GroZZleR").
// Please submit all questions and feedback to: grozzler@grozzler.com
// Copyright September 30th, 2007.
// Feel free to use this code, without permission, for any project.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Platformer
{
	public class Platformer : Microsoft.Xna.Framework.Game
	{
		GraphicsDeviceManager graphics;
		SpriteBatch spriteBatch;
		Texture2D texture;

        GamePadState lastGamepadState;
		World world;
		Player player;

		public Platformer()
		{
			graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
		}

		protected override void Initialize()
		{
			graphics.PreferredBackBufferWidth = 512;
			graphics.PreferredBackBufferHeight = 512;
			graphics.ApplyChanges();

			// Create our world!
			world = new World();

			// Create the 4 outer walls.
			world.AddEntity(Entity.Create<Wall>(new Vector2(0, 0), 512, 16));
			world.AddEntity(Entity.Create<Wall>(new Vector2(512 - 16, 0), 16, 512));
			world.AddEntity(Entity.Create<Wall>(new Vector2(0, 512 - 16), 512, 16));
			world.AddEntity(Entity.Create<Wall>(new Vector2(0, 0), 16, 512));

			// Now lets create some platforms.
			world.AddEntity(Entity.Create<Wall>(new Vector2(0, 96), 256, 32));
			world.AddEntity(Entity.Create<Wall>(new Vector2(512 - 256, 96 + 96 + 28), 256, 24));
			world.AddEntity(Entity.Create<Wall>(new Vector2(64, 96 * 3.5f), 128, 16));
			world.AddEntity(Entity.Create<Wall>(new Vector2(256, 96 * 4f), 128, 8));

			// Add the player.
			player = Entity.Create<Player>(new Vector2(16, 16), 32, 64);
			world.AddEntity(player);

			base.Initialize();
		}

		protected override void LoadContent()
		{
			spriteBatch = new SpriteBatch(GraphicsDevice);
			texture = Content.Load<Texture2D>("blank");

            base.LoadContent();
		}

		protected override void Update(GameTime gameTime)
		{
			// Allows the game to exit
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
				this.Exit();

			// Calculate our time intervals -- this isn't entirely necessary with XNA's
			// fixed time steps, but old habits die hard.
			float deltaTime = (float)((double)gameTime.ElapsedGameTime.TotalSeconds);
			float totalTime = (float)((double)gameTime.TotalRealTime.TotalSeconds);

			// Build a velocity vector for our player.
			KeyboardState keyboardState = Keyboard.GetState();
            GamePadState gps = GamePad.GetState(PlayerIndex.One);

			Vector2 velocity = player.Velocity;
			velocity.X = 0;

            if (keyboardState.IsKeyDown(Keys.W) ||
                ((gps.Buttons.A == ButtonState.Pressed) &&
                  (lastGamepadState.Buttons.A != gps.Buttons.A)))
				velocity.Y = -512;
            if (keyboardState.IsKeyDown(Keys.A) ||
                (gps.DPad.Left == ButtonState.Pressed) ||
                (gps.ThumbSticks.Left.X < -0.5f))
				velocity.X = -256;
			if (keyboardState.IsKeyDown(Keys.D) ||
                (gps.DPad.Right == ButtonState.Pressed) ||
                (gps.ThumbSticks.Left.X > 0.5f))
				velocity.X = 256;


            lastGamepadState = gps;

			player.Velocity = velocity;

			world.Update(deltaTime, totalTime);

			base.Update(gameTime);
		}

		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.Azure);

			// Loop through every entity and draw it.
			spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
			foreach (Entity body in world.Bodies)
			{
				Color colour = Color.Green;

				if (body is Wall)
					colour = Color.Black;

				spriteBatch.Draw(
					texture,
					body.Position,
					new Rectangle(0, 0, 
                        (int)body.BoundingBox.Width, 
                        (int)body.BoundingBox.Height),
					colour);
			}
			spriteBatch.End();

			base.Draw(gameTime);
		}
	}
}
