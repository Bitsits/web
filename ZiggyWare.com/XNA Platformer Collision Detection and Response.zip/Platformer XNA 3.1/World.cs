// Part of the "Playing with Platforms" article by A. Scott McCallum ("GroZZleR").
// Please submit all questions and feedback to: grozzler@grozzler.com
// Copyright September 30th, 2007.
// Feel free to use this code, without permission, for any project.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;

namespace Platformer
{
	public class World
	{
		protected Vector2 gravity = new Vector2(0, 16);

		protected List<Entity> entities;

		// The list of entities shouldn't be made available like this, but it makes things
		// a lot simpler for drawing.
		public List<Entity> Bodies { get { return entities; } }

		public World()
		{
			entities = new List<Entity>();
		}

		public void AddEntity(Entity entity)
		{
			entities.Add(entity);
		}

		public void RemoveEntity(Entity entity)
		{
			entities.Remove(entity);
		}

		public void Update(float deltaTime, float totalTime)
		{
			for (int i = 0; i < entities.Count; ++i)
			{
				// Add some gravity to their velocity.
				entities[i].Velocity += gravity * entities[i].Weight;

				// Move 'em.
				entities[i].Move(entities[i].Velocity * deltaTime);

				// Check for collisions.
				for (int j = 0; j < entities.Count; ++j)
				{
					if (entities[i] == entities[j])
						continue;

					Vector2 displacement = 
                        BoundingBox.CalculateMinimumTranslationDistance(
                            entities[i].BoundingBox, entities[j].BoundingBox);

					// Tell the entity that it's colliding with an object.
					if (displacement != Vector2.Zero)
					{
						entities[i].OnCollision(entities[j], displacement);
					}
				}
			}
		}
	}
}
