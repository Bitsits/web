// Part of the "Playing with Platforms" article by A. Scott McCallum ("GroZZleR").
// Please submit all questions and feedback to: grozzler@grozzler.com
// Copyright September 30th, 2007.
// Feel free to use this code, without permission, for any project.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;

namespace Platformer
{
	public class Wall : Entity
	{
		public Wall()
		{
			weight = 0.0f;
		}

		public override void OnCollision(Entity other, Vector2 displacement)
		{
			// This is empty because walls don't move for anything and never react.
		}
	}
}
