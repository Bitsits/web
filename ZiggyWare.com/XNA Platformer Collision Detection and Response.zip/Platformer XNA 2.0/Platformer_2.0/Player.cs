// Part of the "Playing with Platforms" article by A. Scott McCallum ("GroZZleR").
// Please submit all questions and feedback to: grozzler@grozzler.com
// Copyright September 30th, 2007.
// Feel free to use this code, without permission, for any project.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;

namespace Platformer
{
	public class Player : Entity
	{
		public override void OnCollision(Entity other, Vector2 displacement)
		{
			if (other is Wall)
			{
				Move(displacement);

				// It's moving us vertically (either up or down) so we're going to cancel our Y
				// velocity to help prevent objects from passing through eachother.  Without this
				// an object would continue to build up speed from gravity before teleporting through
				// an object.  Comment it out and see!
				if (displacement.Y != 0)
					velocity.Y = 0;
			}
		}
	}
}
