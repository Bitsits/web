// Part of the "Playing with Platforms" article by A. Scott McCallum ("GroZZleR").
// Please submit all questions and feedback to: grozzler@grozzler.com
// Copyright September 30th, 2007.
// Feel free to use this code, without permission, for any project.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;

namespace Platformer
{
	public abstract class Entity
	{
		protected BoundingBox boundingBox;
		protected Vector2 position;
		protected Vector2 velocity;
		protected float weight = 1.0f;

		public BoundingBox BoundingBox
		{
			get { return boundingBox; }
			set { boundingBox = value; }
		}

		public Vector2 Position
		{
			get { return position; }
			set { Teleport(value); }
		}

		public Vector2 Velocity
		{
			get { return velocity; }
			set { velocity = value; }
		}

		public float Weight
		{
			get { return weight; }
			set { weight = value; }
		}

		public void Teleport(Vector2 position)
		{
			this.position = position;
			boundingBox.Teleport(position);
		}

		public void Move(Vector2 adjustment)
		{
			this.position += adjustment;
			boundingBox.Move(adjustment);
		}

		public abstract void OnCollision(Entity other, Vector2 displacement);

		// This lets us create different sized entities, mainly walls, quickly.
		public static T Create<T>(Vector2 position, float width, float height) where T : Entity, new()
		{
			T body = new T();

			body.BoundingBox = new BoundingBox(width, height);
			body.Teleport(position);

			return body;
		}
	}
}
