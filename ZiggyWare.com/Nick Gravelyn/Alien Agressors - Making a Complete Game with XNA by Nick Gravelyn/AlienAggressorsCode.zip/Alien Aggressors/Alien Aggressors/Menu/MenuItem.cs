using System;

namespace Alien_Aggressors
{
	/// <summary>
	/// A very simple item for a menu
	/// </summary>
	public class MenuItem
	{
		//the name of the item
		public string Name;
		
		//an event raised when the item is "clicked"
		public event EventHandler Activate;

		//events raised when the user wants to scroll through options
		public event EventHandler OptionLeft;
		public event EventHandler OptionRight;

		//a flag for disabling items from being selected or clicked
		public bool IsDisabled = false;

		//any associated data for the item to use
		public object Tag;

		//basic constructor to set the name of the item
		public MenuItem(string name)
		{
			Name = name;
		}

		//simple methods to raise the events

		public void PerformActivate()
		{
			if (Activate != null)
				Activate(this, null);
		}

		public void PerformOptionLeft()
		{
			if (OptionLeft != null)
				OptionLeft(this, null);
		}

		public void PerformOptionRight()
		{
			if (OptionRight != null)
				OptionRight(this, null);
		}
	}
}
