using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Alien_Aggressors
{
	/// <summary>
	/// A fairly simple base class for menus.
	/// </summary>
	public class Menu
	{
		//a list of all the items in the menu
		public List<MenuItem> Items = new List<MenuItem>();

		//the index of the currently selected item
		int currentItem = 0;

		/// <summary>
		/// Gets the currently selected item or null 
		/// if no items exist in the menu.
		/// </summary>
		public MenuItem SelectedItem
		{
			get
			{
				if (Items.Count > 0)
					return Items[currentItem];
				else
					return null;
			}
		}

		/// <summary>
		/// Selects the next menu item.
		/// </summary>
		public void SelectNext()
		{
			if (Items.Count > 0)
			{
				//we loop over this code until we find a non-disabled item
				do
				{
					currentItem = (currentItem + 1) % Items.Count;
				} while (SelectedItem.IsDisabled);
			}
		}

		/// <summary>
		/// Selects the previous menu item.
		/// </summary>
		public void SelectPrevious()
		{
			if (Items.Count > 0)
			{
				//we loop over this code until we find a non-disabled item
				do
				{
					currentItem--;
					if (currentItem < 0)
						currentItem = Items.Count - 1;
				} while (SelectedItem.IsDisabled);
			}
		}

		/// <summary>
		/// Selects the item with the given index.
		/// </summary>
		/// <param name="index">The item index to select.</param>
		public void SelectItem(int index)
		{
			if (index >= 0 && index < Items.Count)
			{
				currentItem = index + 1;
				SelectPrevious();
			}
		}

		/// <summary>
		/// Draws the menu to the screen
		/// </summary>
		/// <param name="spriteBatch">The SpriteBatch to use for rendering</param>
		/// <param name="font">The font in which the text will be drawn</param>
		public void Draw(SpriteBatch spriteBatch, SpriteFont font)
		{
			spriteBatch.Begin(SpriteBlendMode.AlphaBlend);

			//loop through all the items.
			for (int i = 0; i < Items.Count; i++)
			{
				MenuItem item = Items[i];

				//get the size of the text
				Vector2 size = font.MeasureString(item.Name);

				//get the center of the screen
				Vector2 pos = new Vector2(
					spriteBatch.GraphicsDevice.Viewport.Width / 2,
					spriteBatch.GraphicsDevice.Viewport.Height / 2);

				//offset the position by half of the text size
				pos -= size * .5f;

				//add to the position's Y value an offset to space each item further down
				pos.Y += i * (size.Y * 1.1f);

				//determine the color of the item based on whether 
				//or not it is selected or disabled
				Color color = Color.White;
				if (item == SelectedItem)
					color = Color.Yellow;
				else if (item.IsDisabled)
					color = Color.DarkSlateGray;

				//render the item
				spriteBatch.DrawString(
					font,
					item.Name,
					pos,
					color);
			}

			spriteBatch.End();
		}
	}
}
