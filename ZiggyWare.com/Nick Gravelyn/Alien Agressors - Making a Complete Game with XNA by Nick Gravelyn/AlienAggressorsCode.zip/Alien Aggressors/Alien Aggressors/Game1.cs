using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Alien_Aggressors
{
	/// <summary>
	/// This is the main type for your game
	/// </summary>
	public class Game1 : Microsoft.Xna.Framework.Game
	{
		GraphicsDeviceManager graphics;
		SpriteBatch spriteBatch;
		StarryBackground stars;
		GameStateManager stateManager;

		public Game1()
		{
			graphics = new GraphicsDeviceManager(this);
			Content.RootDirectory = "Content";

			//create the state manager and add it to the Components collection
			stateManager = new GameStateManager(this);
			Components.Add(stateManager);

			//add the ContentManager and GameStateManager to the Services collection
			//so that our individual game states can retrieve them.
			Services.AddService(typeof(ContentManager), Content);
			Services.AddService(typeof(GameStateManager), stateManager);
		}

		/// <summary>
		/// Allows the game to perform any initialization it needs to before starting to run.
		/// This is where it can query for any required services and load any non-graphic
		/// related content.  Calling base.Initialize will enumerate through any components
		/// and initialize them as well.
		/// </summary>
		protected override void Initialize()
		{
			//initialize the sound system and play the background music
			SoundManager.Initialize(
				this, 
				"AlienAggressors.xgs", 
				"AlienAggressors.xwb", 
				"AlienAggressors.xsb");
			SoundManager.PlayMusic("tear_it_down");

			//call base.Initialize to create the graphics device before creating any game states.
			base.Initialize();

			//add all of our game states to the GameStateManager

			stateManager.GameStates.Add(
				AAGameState.MainMenu,
				new MainMenuGameState(this, "Alien Aggressors!"));

			stateManager.GameStates.Add(
				AAGameState.Options,
				new OptionsGameState(this));

			stateManager.GameStates.Add(
				AAGameState.LevelTransition, 
				new TransitionGameState(this));

			stateManager.GameStates.Add(
				AAGameState.Playing,
				new PlayingGameState(this));

			stateManager.GameStates.Add(
				AAGameState.Paused,
				new PausedGameState(this));

			EndPlayingGameState epgs = new EndPlayingGameState(this);
			stateManager.GameStates.Add(AAGameState.Win, epgs);
			stateManager.GameStates.Add(AAGameState.Lose, epgs);

			//start the game at the MainMenu game state
			stateManager.CurrentState = AAGameState.MainMenu;
		}

		/// <summary>
		/// LoadContent will be called once per game and is the place to load
		/// all of your content.
		/// </summary>
		protected override void LoadContent()
		{
			spriteBatch = new SpriteBatch(GraphicsDevice);

			//create our StarryBackground with 2000 stars
			stars = new StarryBackground(
				GraphicsDevice, 
				GraphicsDevice.Viewport.Width, 
				GraphicsDevice.Viewport.Height, 
				2000);
		}

		/// <summary>
		/// UnloadContent will be called once per game and is the place to unload
		/// all content.
		/// </summary>
		protected override void UnloadContent()
		{
			// TODO: Unload any non ContentManager content here
		}

		/// <summary>
		/// Allows the game to run logic such as updating the world,
		/// checking for collisions, gathering input, and playing audio.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Update(GameTime gameTime)
		{
			//update the InputHelder and SoundManager.
			InputHelper.Update();
			SoundManager.Update();

			//base.Update calls our GameStateManager's Update method to update the current state
			base.Update(gameTime);
		}

		/// <summary>
		/// This is called when the game should draw itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		protected override void Draw(GameTime gameTime)
		{
			//clear to black to look like space
			graphics.GraphicsDevice.Clear(Color.Black);

			//render the stars over the background
			spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
			spriteBatch.Draw(stars, Vector2.Zero, Color.White);
			spriteBatch.End();

			//base.Draw calls our GameStateManager's Draw method to draw the current state
			base.Draw(gameTime);
		}
	}
}
