using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents the game's win or lose state.
	/// </summary>
	public class EndPlayingGameState: GameState
	{
		SpriteBatch spriteBatch;
		SpriteFont spriteFont;

		//the score at the end of the game
		public int FinalScore = 0;

		public EndPlayingGameState(Game game)
			: base(game)
		{
			//create the SpriteBatch and load the font.

			spriteBatch = new SpriteBatch(GraphicsDevice);
			spriteFont = Content.Load<SpriteFont>("Courier New");
		}

		public override void Update(GameTime gameTime)
		{	
			//allow the player to return to the main menu using a slew of buttons
			if (InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.A) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.Start) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.A) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.Start) ||
				InputHelper.IsNewKeyPress(Keys.Space) ||
				InputHelper.IsNewKeyPress(Keys.Enter))
			{
				Manager.CurrentState = AAGameState.MainMenu;
			}
		}

		public override void Draw(GameTime gameTime)
		{
			//calculate the center of the screen
			Vector2 centerScreen = new Vector2(
				GraphicsDevice.Viewport.Width / 2, 
				GraphicsDevice.Viewport.Height / 2);

			//figure out the result string and size
			string result = (Manager.CurrentState == AAGameState.Win)
				? "WIN!"
				: "FAIL!";
			Vector2 halfStringSize = spriteFont.MeasureString(result) / 2;

			//generate the strings for our information and final score as well
			//as calculating their positions on the screen

			string info = "Press A, Start, Enter, or Space to continue...";
			Vector2 halfInfoSize = spriteFont.MeasureString(info) / 2;
			Vector2 infoPos = centerScreen - halfInfoSize + new Vector2(0f, 100f);

			string score = "Final Score: " + FinalScore.ToString();
			Vector2 halfScoreSize = spriteFont.MeasureString(score) / 2;
			Vector2 scorePos = centerScreen - halfScoreSize - new Vector2(0f, 100f);

			//simply draw each string to the screen at the desired location

			spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
			spriteBatch.DrawString(
				spriteFont,
				result,
				centerScreen - halfStringSize,
				Color.White);

			spriteBatch.DrawString(
				spriteFont,
				info,
				infoPos,
				Color.White);

			spriteBatch.DrawString(
				spriteFont,
				score,
				scorePos,
				Color.White);

			spriteBatch.End();
		}
	}
}
