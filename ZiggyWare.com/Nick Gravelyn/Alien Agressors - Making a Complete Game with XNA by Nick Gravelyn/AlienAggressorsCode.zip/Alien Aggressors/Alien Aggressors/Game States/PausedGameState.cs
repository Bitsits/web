using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents the game's Paused game state.
	/// </summary>
	public class PausedGameState : MenuBaseGameState
	{
		public PausedGameState(Game game)
			: base(game, "Paused")
		{
			//create just two items for resuming the game
			//or quiting out to the main menu

			MenuItem item = new MenuItem("Continue");
			item.Activate += ContinueActivated;
			Menu.Items.Add(item);

			item = new MenuItem("Quit To Main Menu");
			item.Activate += QuitActivated;
			Menu.Items.Add(item);
		}

		private void ContinueActivated(object sender, EventArgs e)
		{
			Menu.SelectItem(0);
			Manager.CurrentState = AAGameState.Playing;
		}

		private void QuitActivated(object sender, EventArgs e)
		{
			Menu.SelectItem(0);
			Manager.CurrentState = AAGameState.MainMenu;
		}

		public override void Update(GameTime gameTime)
		{
			//check for Escape key or B or Back button to return to the game
			if (InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.Back) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.Back) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.B) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.B) ||
				InputHelper.IsNewKeyPress(Keys.Escape))
			{
				Manager.CurrentState = AAGameState.Playing;
			}

			//make sure to call base.Update to update the menu logic
			base.Update(gameTime);
		}
	}
}
