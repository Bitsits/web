using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents a single game state in AlienAggressors
	/// </summary>
	public abstract class GameState
	{
		GameStateManager manager;
		ContentManager content;
		GraphicsDeviceManager graphics;
		Game game;

		/// <summary>
		/// Gets the game associated with this game state.
		/// </summary>
		public Game Game
		{
			get { return game; }
		}

		/// <summary>
		/// Gets the GameStateManager associated with this game state.
		/// </summary>
		public GameStateManager Manager
		{
			get { return manager; }
		}

		/// <summary>
		/// Gets the ContentManager associated with this game state.
		/// </summary>
		public ContentManager Content
		{
			get { return content; }
		}

		/// <summary>
		/// Gets the GraphicsDevice associated with this game state.
		/// </summary>
		public GraphicsDevice GraphicsDevice
		{
			get { return graphics.GraphicsDevice; }
		}

		/// <summary>
		/// Gets the GraphicsDeviceManager associated with this game state.
		/// </summary>
		public GraphicsDeviceManager GraphicsManager
		{
			get { return graphics; }
		}

		public GameState(Game game)
		{
			this.game = game;

			//use the Game.Services collection to retrieve our GameStateManager, 
			//ContentManager, and GraphicsDeviceManager.
			manager = game.Services.GetService(typeof(GameStateManager)) as GameStateManager;
			content = game.Services.GetService(typeof(ContentManager)) as ContentManager;
			graphics = game.Services.GetService(typeof(IGraphicsDeviceService))	as GraphicsDeviceManager;
		}

		//all game states must implement an Update method and a Draw method
		public abstract void Update(GameTime gameTime);
		public abstract void Draw(GameTime gameTime);
	}
}
