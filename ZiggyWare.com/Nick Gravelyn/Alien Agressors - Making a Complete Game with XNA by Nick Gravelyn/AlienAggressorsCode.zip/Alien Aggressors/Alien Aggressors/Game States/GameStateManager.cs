using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace Alien_Aggressors
{
	/// <summary>
	/// The game states for Alien Aggressors.
	/// </summary>
	public enum AAGameState
	{
		MainMenu,
		Options,
		LevelTransition,
		Playing,
		Paused,
		Win,
		Lose,
	}

	/// <summary>
	/// Handles updating and drawing the game states for Alien Aggressors.
	/// </summary>
	public class GameStateManager : DrawableGameComponent
	{
		/// <summary>
		/// The full collection of game states.
		/// </summary>
		public Dictionary<AAGameState, GameState> GameStates =
			new Dictionary<AAGameState, GameState>();

		/// <summary>
		/// The key for the current game state.
		/// </summary>
		public AAGameState CurrentState = AAGameState.MainMenu;

		public GameStateManager(Game game)
			: base(game)
		{
		}

		public override void Update(GameTime gameTime)
		{
			//if the state exists in our collection, update it.
			GameState state;
			if (GameStates.TryGetValue(CurrentState, out state))
				state.Update(gameTime);
		}

		public override void Draw(GameTime gameTime)
		{
			//if the state exists in our collection, draw it.
			GameState state;
			if (GameStates.TryGetValue(CurrentState, out state))
				state.Draw(gameTime);
		}
	}
}
