using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;

namespace Alien_Aggressors
{
	/// <summary>
	/// A game state representing the main game menu
	/// </summary>
	public class MainMenuGameState : MenuBaseGameState
	{
		public MainMenuGameState(Game game, string title)
			: base(game, title)
		{
			//Next we just add a bunch of menu items and hook their
			//events up to the event handlers below.

			MenuItem item;

			item = new MenuItem("Single Player");
			item.Activate += SinglePlayerActivated;
			Menu.Items.Add(item);

			item = new MenuItem("Co-Op");
			item.Activate += CoopActivated;
			Menu.Items.Add(item);

			item = new MenuItem("Options");
			item.Activate += OptionsActivated;
			Menu.Items.Add(item);

			item = new MenuItem("Quit");
			item.Activate += QuitActivated;
			Menu.Items.Add(item);
		}

		//this series of event handlers respond when one of the items
		//are activated.

		public void SinglePlayerActivated(object sender, EventArgs args)
		{
			//initialize the playing game state's field
			(Manager.GameStates[AAGameState.Playing] as PlayingGameState).Initialize(false, true);

			(Manager.GameStates[AAGameState.LevelTransition] as TransitionGameState).Caption = "Level 1";

			//set the state to our transition state
			Manager.CurrentState = AAGameState.LevelTransition;
		}

		public void CoopActivated(object sender, EventArgs args)
		{
			//initialize the playing game state's field
			(Manager.GameStates[AAGameState.Playing] as PlayingGameState).Initialize(true, true);

			(Manager.GameStates[AAGameState.LevelTransition] as TransitionGameState).Caption = "Level 1";

			//set the state to our transition state
			Manager.CurrentState = AAGameState.LevelTransition;
		}

		public void OptionsActivated(object sender, EventArgs args)
		{
			Manager.CurrentState = AAGameState.Options;
		}

		public void QuitActivated(object sender, EventArgs args)
		{
			Game.Exit();
		}

		public override void Update(GameTime gameTime)
		{
			//check for Escape or a Back button to quit the game
			if (InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.Back) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.Back) ||
				InputHelper.IsNewKeyPress(Keys.Escape))
			{
				Game.Exit();
			}

			//make sure to call base.Update to update the menu logic
			base.Update(gameTime);
		}
	}
}
