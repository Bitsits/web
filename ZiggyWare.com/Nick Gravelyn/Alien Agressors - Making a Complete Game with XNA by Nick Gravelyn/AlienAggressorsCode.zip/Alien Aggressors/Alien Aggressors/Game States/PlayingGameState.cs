using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents the game's playing state
	/// </summary>
	public class PlayingGameState : GameState
	{
		SpriteBatch spriteBatch;
		SpriteFont spriteFont;

		//two lists to contain all of our bullets
		List<Bullet> playerBullets = new List<Bullet>();
		List<Bullet> alienBullets = new List<Bullet>();

		//the two potential players
		PlayerShip player1;
		PlayerShip player2;

		//basic game data
		bool coOp = false;
		int score = 0;
		int level = 1;
		const int maxLevel = 10;

		//the grid of enemy aliens
		AlienGrid alienGrid = new AlienGrid();

		public PlayingGameState(Game game)
			: base(game)
		{
			//load the bullet and compute the center
			Bullet.Texture = Content.Load<Texture2D>("bullet");
			Bullet.Origin = new Vector2(Bullet.Texture.Width / 2, Bullet.Texture.Height / 2);

			//create the SpriteBatch and load the font
			spriteBatch = new SpriteBatch(GraphicsDevice);
			spriteFont = Content.Load<SpriteFont>("Courier New");
		}

		public void Initialize(bool isCoOp, bool newGame)
		{
			//create the two players and initialize their positions

			player1 = new PlayerShip(
				Content.Load<Texture2D>("player1"),
				PlayerIndex.One);
			player1.Position = new Vector2(
				GraphicsDevice.Viewport.Width / 2 - player1.Bounds.Width / 2,
				GraphicsDevice.Viewport.Height - player1.Bounds.Height);

			player2 = new PlayerShip(
				Content.Load<Texture2D>("player2"),
				PlayerIndex.Two);
			player2.Position = new Vector2(
				GraphicsDevice.Viewport.Width / 2 - player2.Bounds.Width / 2,
				GraphicsDevice.Viewport.Height - player2.Bounds.Height);

			//save whether to play a co-op game and reset the score and level
			coOp = isCoOp;
			if (newGame)
			{
				score = 0;
				level = 1;
			}

			//clear out all of the bullets
			playerBullets.Clear();
			alienBullets.Clear();

			//initialize the alien grid
			alienGrid.Initialize(Content.Load<Texture2D>("alien"), 10 + (level / 3), 5 + (level / 2));
		}

		public override void Update(GameTime gameTime)
		{
			//allow the players to pause the game using either the game pads or the Enter key on the keyboard
			if (InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.Start) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.Start) ||
				InputHelper.IsNewKeyPress(Keys.Enter))
			{
				Manager.CurrentState = AAGameState.Paused;
				return;
			}

			//update the players
			if (player1.IsAlive)
				player1.Update(gameTime, playerBullets, GraphicsDevice.Viewport.Width);
			if (coOp && player2.IsAlive)
				player2.Update(gameTime, playerBullets, GraphicsDevice.Viewport.Width);

			//update the player grid and switch to the Lose game state if they have reached the player
			if (alienGrid.Update(gameTime, alienBullets, GraphicsDevice.Viewport.Width, player1.Bounds.Top))
				Manager.CurrentState = AAGameState.Lose;

			//generate a rectangle for our playing area
			Rectangle screenRect = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

			//the list of bullets to remove from our main lists
			List<Bullet> bulletsToRemove = new List<Bullet>();

			foreach (Bullet b in playerBullets)
			{
				//update the bullet
				b.Update();

				//if the bullet is not in the playing area, flag it for removal
				if (!screenRect.Intersects(b.Bounds))
					bulletsToRemove.Add(b);
					
				//otherwise see if it has collided with an alien
				else if (alienGrid.CollideBullet(b))
				{
					//if so we flag it for removal and add 100 points
					bulletsToRemove.Add(b);
					score += 100;

					//if there are no more aliens...
					if (alienGrid.Count == 0)
					{
						//if we're on the last level...
						if (level == maxLevel)
						{
							//change game states to the Win game state
							GameState winState = Manager.GameStates[AAGameState.Win];
							(winState as EndPlayingGameState).FinalScore = score;
							Manager.CurrentState = AAGameState.Win;
						}

						//otherwise...
						else
						{
							//change to the next level and re-initialize the game state
							level++;
							Initialize(coOp, false);

							//change to the level transition game state
							GameState transState = Manager.GameStates[AAGameState.LevelTransition];
							(transState as TransitionGameState).Caption = "Level " + level.ToString();
							Manager.CurrentState = AAGameState.LevelTransition;
							return;
						}
					}
				}
			}

			//remove all the bullets that were flagged above
			foreach (Bullet b in bulletsToRemove)
				playerBullets.Remove(b);

			//clear the list for so we can use it with the alienBullets list
			bulletsToRemove.Clear();

			foreach (Bullet b in alienBullets)
			{
				//update the bullet
				b.Update();

				//if the bullet is not in the playing area, flag it for removal
				if (!screenRect.Intersects(b.Bounds))
					bulletsToRemove.Add(b);

				//otherwise see if it has collided with the first player
				else if (player1.IsAlive && player1.CollideBullet(b))
				{
					//flag the bullet for removal
					bulletsToRemove.Add(b);

					//remove a life from the player and reset him
					player1.ExtraLives--;
					player1.Position.X = player1.Bounds.Width / 2;

					//see if the game should be over now
					CheckPlayerLives();
				}

				//otherwise see if it has collided with the second player
				else if (coOp && player2.IsAlive && player2.CollideBullet(b))
				{
					//flag the bullet for removal
					bulletsToRemove.Add(b);

					//remove a life from the player and reset him
					player2.ExtraLives--;
					player2.Position.X = player2.Bounds.Width / 2;

					//see if the game should be over now
					CheckPlayerLives();
				}
			}

			//remove all the flagged bullets
			foreach (Bullet b in bulletsToRemove)
				alienBullets.Remove(b);
		}

		private void CheckPlayerLives()
		{
			//check for game over conditions. if the game is co-op
			//and both players are dead, the game is over. if the game
			//is not co-op and player 1 is dead, the game is over.

			if (coOp && !player1.IsAlive && !player2.IsAlive)
					Manager.CurrentState = AAGameState.Lose;
			else if (!coOp && !player1.IsAlive)
					Manager.CurrentState = AAGameState.Lose;

			//if the game was just determined to be a failure...
			if (Manager.CurrentState == AAGameState.Lose)
			{
				//update the game over state with the final score
				GameState loseState = Manager.GameStates[AAGameState.Lose];
				(loseState as EndPlayingGameState).FinalScore = score;
			}
		}

		public override void Draw(GameTime gameTime)
		{
			spriteBatch.Begin(SpriteBlendMode.AlphaBlend);
			
			//draw all of the player bullets
			foreach (Bullet b in playerBullets)
				b.Draw(spriteBatch);

			//draw all of the alien bullets
			foreach (Bullet b in alienBullets)
				b.Draw(spriteBatch);

			//draw the players
			if (player1.IsAlive)
				player1.Draw(spriteBatch);
			if (coOp && player2.IsAlive)
				player2.Draw(spriteBatch);

			//draw the aliens
			alienGrid.Draw(spriteBatch);

			//draw the score to the top left
			spriteBatch.DrawString(
				spriteFont,
				"Score: " + score.ToString(),
				new Vector2(10f),
				Color.White);

			//draw all of player 1's extra lives in the top right
			for (int i = 1; i <= player1.ExtraLives; i++)
			{
				spriteBatch.Draw(
					player1.Texture,
					new Rectangle(
						GraphicsDevice.Viewport.Width - (player1.Texture.Width * i),
						10,
						25,
						25),
					Color.White);
			}

			//draw all of player 2's extra lives in the top right
			//only draw player 2's lives if the game is a co-op game
			if (coOp)
			{
				for (int i = 1; i <= player2.ExtraLives; i++)
				{
					spriteBatch.Draw(
						player2.Texture,
						new Rectangle(
							GraphicsDevice.Viewport.Width - (player2.Texture.Width * i),
							35,
							25,
							25),
						Color.White);
				}
			}
			
			spriteBatch.End();
		}
	}
}
