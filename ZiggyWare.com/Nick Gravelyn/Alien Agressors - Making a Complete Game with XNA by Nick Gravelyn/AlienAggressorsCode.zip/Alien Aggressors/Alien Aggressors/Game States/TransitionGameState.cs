using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace Alien_Aggressors
{
	/// <summary>
	/// A simple game state representing a transition period before starting
	/// a new game or between game levels.
	/// </summary>
	public class TransitionGameState : GameState
	{
		//a SpriteBatch and font to render the caption
		SpriteBatch spriteBatch;
		SpriteFont font;

		//a timer to track how long the state has been up and a length
		//to set how long the state should be up.
		float transitionTimer = 0f;
		const float transitionLength = 2f;

		//the caption to display on screen
		public string Caption = string.Empty;

		public TransitionGameState(Game game)
			: base(game)
		{
			//create the SpriteBatch and load the font
			spriteBatch = new SpriteBatch(GraphicsDevice);
			font = Content.Load<SpriteFont>("Courier New");
		}

		public override void Update(GameTime gameTime)
		{
			//add the elapsed time to our timer
			transitionTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;

			//if the correct amount of time has passed we reset the timer for
			//our next use and set the state to playing to continue with the game.
			if (transitionTimer >= transitionLength)
			{
				transitionTimer = 0f;
				Manager.CurrentState = AAGameState.Playing;
			}
		}

		public override void Draw(GameTime gameTime)
		{
			spriteBatch.Begin(SpriteBlendMode.AlphaBlend);

			//get the center of the screen
			Vector2 pos = new Vector2(
				GraphicsDevice.Viewport.Width / 2,
				GraphicsDevice.Viewport.Height / 2);

			//offset that position by half of the size of the text (to center the text)
			pos -= font.MeasureString(Caption) * .5f;

			//draw the caption to the screen
			spriteBatch.DrawString(font, Caption, pos, Color.White);

			spriteBatch.End();
		}
	}
}
