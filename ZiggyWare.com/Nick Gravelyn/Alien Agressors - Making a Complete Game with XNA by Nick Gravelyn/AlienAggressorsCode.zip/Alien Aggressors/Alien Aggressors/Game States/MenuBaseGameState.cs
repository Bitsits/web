using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

namespace Alien_Aggressors
{
	/// <summary>
	/// A game state that is responsible for displaying
	/// and updating a menu of any kind.
	/// </summary>
	public class MenuBaseGameState : GameState
	{
		//a SpriteBatch and font to render the menu
		SpriteBatch spriteBatch;
		SpriteFont font;

		//the actual menu object
		protected Menu Menu = new Menu();

		//the screen title to display while the menu is up
		string title;

		public MenuBaseGameState(Game game, string title)
			: base(game)
		{
			//create the SpriteBatch and load the font
			spriteBatch = new SpriteBatch(GraphicsDevice);
			font = Content.Load<SpriteFont>("Courier New");

			//save the game title
			this.title = title;
		}

		public override void Update(GameTime gameTime)
		{
			//check for the A and Start game pad buttons and Space and Enter keyboard buttons
			//to activate the current menu item
			if (InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.A) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.Start) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.A) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.Start) ||
				InputHelper.IsNewKeyPress(Keys.Space) ||
				InputHelper.IsNewKeyPress(Keys.Enter))
			{
				if (Menu.SelectedItem != null)
					Menu.SelectedItem.PerformActivate();
				SoundManager.PlayCue("bwoop");
			}

			//check the left thumbsticks X axis, the DPads, the left arrow, and A key all to 
			//see if we should move to the item's left option
			if (InputHelper.DidThumbstickPassThreshold(PlayerIndex.One, Thumbstick.Left, ThumbstickAxis.X, -.3f) ||
				InputHelper.DidThumbstickPassThreshold(PlayerIndex.Two, Thumbstick.Left, ThumbstickAxis.X, -.3f) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.DPadLeft) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.DPadLeft) ||
				InputHelper.IsNewKeyPress(Keys.Left) ||
				InputHelper.IsNewKeyPress(Keys.A))
			{
				if (Menu.SelectedItem != null)
					Menu.SelectedItem.PerformOptionLeft();
				SoundManager.PlayCue("bwoop");
			}

			//check the left thumbsticks X axis, the DPads, the right arrow, and D key all to 
			//see if we should move to the item's right option
			if (InputHelper.DidThumbstickPassThreshold(PlayerIndex.One, Thumbstick.Left, ThumbstickAxis.X, .3f) ||
				InputHelper.DidThumbstickPassThreshold(PlayerIndex.Two, Thumbstick.Left, ThumbstickAxis.X, .3f) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.DPadRight) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.DPadRight) ||
				InputHelper.IsNewKeyPress(Keys.Right) ||
				InputHelper.IsNewKeyPress(Keys.D))
			{
				if (Menu.SelectedItem != null)
					Menu.SelectedItem.PerformOptionRight();
				SoundManager.PlayCue("bwoop");
			}

			//check the left thumbsticks Y axis, the DPads, the up arrow, and W key all to 
			//see if we should move to the previous menu item.
			if (InputHelper.DidThumbstickPassThreshold(PlayerIndex.One, Thumbstick.Left, ThumbstickAxis.Y, .3f) ||
				InputHelper.DidThumbstickPassThreshold(PlayerIndex.Two, Thumbstick.Left, ThumbstickAxis.Y, .3f) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.DPadUp) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.DPadUp) ||
				InputHelper.IsNewKeyPress(Keys.Up) ||
				InputHelper.IsNewKeyPress(Keys.W))
			{
				Menu.SelectPrevious();
				SoundManager.PlayCue("bwoop");
			}

			//check the left thumbsticks Y axis, the DPads, the down arrow, and S key all to 
			//see if we should move to the next menu item.
			if (InputHelper.DidThumbstickPassThreshold(PlayerIndex.One, Thumbstick.Left, ThumbstickAxis.Y, -.3f) ||
				InputHelper.DidThumbstickPassThreshold(PlayerIndex.Two, Thumbstick.Left, ThumbstickAxis.Y, -.3f) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.DPadDown) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.DPadDown) ||
				InputHelper.IsNewKeyPress(Keys.Down) ||
				InputHelper.IsNewKeyPress(Keys.S))
			{
				Menu.SelectNext();
				SoundManager.PlayCue("bwoop");
			}
		}

		public override void Draw(GameTime gameTime)
		{
			spriteBatch.Begin(SpriteBlendMode.AlphaBlend);

			Vector2 titlePos = new Vector2(GraphicsDevice.Viewport.Width / 2, 100f);
			titlePos -= font.MeasureString(title) * .5f;

			//draw the title to the screen
			spriteBatch.DrawString(
				font,
				title,
				titlePos,
				Color.White);

			spriteBatch.End();

			//draw the menu
			Menu.Draw(spriteBatch, font);
		}
	}
}
