using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents the game's option menu state
	/// </summary>
	public class OptionsGameState : MenuBaseGameState
	{
		//store the sound and music volumes
		int soundFxVolume = 100;
		int musicVolume = 100;

		//the menu items. we store these references so we 
		//can change their names when the values change.
		MenuItem soundFxItem;
		MenuItem musicItem;

		public OptionsGameState(Game game)
			: base(game, "Options")
		{
			//create our basic menu items and hook up the events

			soundFxItem = new MenuItem("Sound FX Volume: 100%");
			soundFxItem.OptionLeft += SoundFxOptionLeft;
			soundFxItem.OptionRight += SoundFxOptionRight;
			Menu.Items.Add(soundFxItem);

			musicItem = new MenuItem("Music Volume: 100%");
			musicItem.OptionLeft += MusicOptionLeft;
			musicItem.OptionRight += MusicOptionRight;
			Menu.Items.Add(musicItem);

			MenuItem item = new MenuItem("Toggle Fullscreen");
			item.Activate += FullScreenActivate;
			Menu.Items.Add(item);

			//by creating an empty item that is disabled, we essentially have
			//added a blank row to our menu to make things easier to read.
			item = new MenuItem("");
			item.IsDisabled = true;
			Menu.Items.Add(item);

			item = new MenuItem("Done");
			item.Activate += DoneActivated;
			Menu.Items.Add(item);
		}

		//create the actual handlers for the menu item events.
		//we adjust the volumes of the sound fx and music and
		//make sure to stay in the range of [0, 100]. we then
		//update the item's name and adjust the volume in the
		//AudioEngine of our SoundManager.

		private void SoundFxOptionLeft(object sender, EventArgs e)
		{
			soundFxVolume = (int)Math.Max(soundFxVolume - 10, 0);
			soundFxItem.Name = string.Format("Sound FX Volume: {0}%", soundFxVolume);
			SoundManager.SetSoundFXVolume(soundFxVolume / 100f);
		}

		private void SoundFxOptionRight(object sender, EventArgs e)
		{
			soundFxVolume = (int)Math.Min(soundFxVolume + 10, 100);
			soundFxItem.Name = string.Format("Sound FX Volume: {0}%", soundFxVolume);
			SoundManager.SetSoundFXVolume(soundFxVolume / 100f);
		}

		private void MusicOptionLeft(object sender, EventArgs e)
		{
			musicVolume = (int)Math.Max(musicVolume - 10, 0);
			musicItem.Name = string.Format("Music Volume: {0}%", musicVolume);
			SoundManager.SetMusicVolume((float)musicVolume / 100f);
		}

		private void MusicOptionRight(object sender, EventArgs e)
		{
			musicVolume = (int)Math.Min(musicVolume + 10, 100);
			musicItem.Name = string.Format("Music Volume: {0}%", musicVolume);
			SoundManager.SetMusicVolume((float)musicVolume / 100f);
		}

		//let the user switch between fullscreen and windowed modes. we currently
		//don't change the resolution because our entire game logic hinges on it.
		//we could change that to allow for it, but for now we won't worry too much.

		private void FullScreenActivate(object sender, EventArgs e)
		{
			GraphicsManager.ToggleFullScreen();
		}

		//simply return to the main menu
		private void DoneActivated(object sender, EventArgs e)
		{
			Menu.SelectItem(0);
			Manager.CurrentState = AAGameState.MainMenu;
		}

		public override void Update(GameTime gameTime)
		{
			//check for Escape key or B or Back button to return to the main menu
			if (InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.Back) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.Back) ||
				InputHelper.IsNewButtonPress(PlayerIndex.One, Buttons.B) ||
				InputHelper.IsNewButtonPress(PlayerIndex.Two, Buttons.B) ||
				InputHelper.IsNewKeyPress(Keys.Escape))
			{
				DoneActivated(null, null);
			}

			//make sure to call base.Update to update the menu logic
			base.Update(gameTime);
		}
	}
}
