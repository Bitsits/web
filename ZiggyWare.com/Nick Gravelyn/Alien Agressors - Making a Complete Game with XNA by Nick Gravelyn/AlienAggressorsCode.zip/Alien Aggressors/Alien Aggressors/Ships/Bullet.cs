using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents a bullet fired by any ship.
	/// </summary>
	public class Bullet
	{
		public static Texture2D Texture;
		public static Vector2 Origin;

		public Vector2 Position;
		public Vector2 Velocity;
		public Color Color;

		/// <summary>
		/// Gets the bounding rectangle for the bullet.
		/// </summary>
		public Rectangle Bounds
		{
			get
			{
				return new Rectangle(
					(int)(Position.X - Origin.X),
					(int)(Position.Y - Origin.Y),
					Texture.Width,
					Texture.Height);
			}
		}

		public void Update()
		{
			//simple updating of the position
			Position += Velocity;
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			spriteBatch.Draw(
				Texture,
				Position,
				null,
				Color,
				0,
				Origin,
				1f,
				SpriteEffects.None,
				0);
		}
	}
}
