using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Alien_Aggressors
{
	/// <summary>
	/// A drawable object in the game.
	/// </summary>
	public class Sprite
	{
		public Vector2 Position = Vector2.Zero;

		Vector2 center;
		Texture2D texture = null;

		/// <summary>
		/// Gets the bounding rectangle for the sprite
		/// </summary>
		public Rectangle Bounds
		{
			get
			{
				return new Rectangle(
					(int)(Position.X - center.X),
					(int)(Position.Y - center.Y),
					(int)texture.Width,
					(int)texture.Height);
			}
		}

		/// <summary>
		/// Gets the sprite's texture.
		/// </summary>
		public Texture2D Texture
		{
			get { return texture; }
		}

		public Sprite(Texture2D spriteTexture)
		{
			//save the texture and generate the center of the texture
			texture = spriteTexture;
			center = new Vector2(
				spriteTexture.Width / 2,
				spriteTexture.Height / 2);
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			//render the sprite at the desired position. cast to integers
			//to prevent rendering artifacts from drawing to fractional pixels.
			spriteBatch.Draw(
				texture,
				new Vector2((int)Position.X, (int)Position.Y),
				null,
				Color.White,
				0f,
				center,
				1f,
				SpriteEffects.None,
				0);
		}
	}
}
