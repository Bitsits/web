using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents a single player in the game.
	/// </summary>
	public class PlayerShip : Ship
	{
		//specifies which game pad the player is using
		PlayerIndex index;

		/// <summary>
		/// The number of extra lives the player has
		/// </summary>
		public int ExtraLives = 3;

		/// <summary>
		/// Gets a value indicating whether the player is still alive.
		/// </summary>
		public bool IsAlive
		{
			get { return ExtraLives >= 0; }
		}

		public PlayerShip(Texture2D spriteTexture, PlayerIndex playerIndex)
			: base(spriteTexture)
		{
			index = playerIndex;

			BulletColor = Color.Red;
			BulletVelocity = new Vector2(0f, -5f);
			BulletOrigin = new Vector2(0, -Bounds.Height / 2);
		}

		public override void Update(GameTime gameTime, List<Bullet> bullets, int fieldWidth)
		{
			//get the state of the player's game pad
			GamePadState gps = GamePad.GetState(index);

			//if the game pad is connected, we update using the game pad.
			//otherwise we update using the keyboard.

			if (gps.IsConnected)
				UpdateGamePad(gps, bullets);
			else
				UpdateKeyboard(bullets);

			//make sure the player does not leave the screen

			if (Bounds.Left < 0)
				Position.X = Bounds.Width / 2;
			else if (Bounds.Right > fieldWidth)
				Position.X = fieldWidth - Bounds.Width / 2;

			//make sure to call base.Update to update our bullet timer
			base.Update(gameTime, bullets, fieldWidth);
		}

		private void UpdateGamePad(GamePadState gps, List<Bullet> bullets)
		{
			//use the left thumbstick to move the player.
			Position.X += gps.ThumbSticks.Left.X * 3;

			//we use the A button or the right trigger to fire a bullet.
			if (gps.Buttons.A == ButtonState.Pressed ||
				gps.Triggers.Right > .3f)
				Fire(bullets);
		}

		private void UpdateKeyboard(List<Bullet> bullets)
		{
			//get the keyboard state and allow the player to use the Left and Right
			//arrows and A and D keys to move left and right. the space bar is used
			//to fire a bullet.

			KeyboardState keyState = Keyboard.GetState();

			if (keyState.IsKeyDown(Keys.A) || keyState.IsKeyDown(Keys.Left))
				Position.X -= 3;
			if (keyState.IsKeyDown(Keys.D) || keyState.IsKeyDown(Keys.Right))
				Position.X += 3;
			if (keyState.IsKeyDown(Keys.Space))
				Fire(bullets);
		}
	}
}
