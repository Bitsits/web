using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents a single ship in the game.
	/// </summary>
	public class Ship : Sprite
	{
		//these values are used to properly create new bullets
		public Color BulletColor = Color.Blue;
		public Vector2 BulletVelocity = Vector2.UnitY;
		public Vector2 BulletOrigin = Vector2.Zero;

		//these values are used to time the bullets.
		float fireTimer = 0f;
		float fireRate = .4f;

		/// <summary>
		/// Gets or sets the firing rate of the ship.
		/// </summary>
		public float FireRate
		{
			get { return fireRate; }
			set { fireRate = (float)Math.Max(value, 0f); }
		}

		public Ship(Texture2D spriteTexture)
			: base(spriteTexture)
		{
		}

		/// <summary>
		/// Determines if a ship was hit by the given bullet.
		/// </summary>
		/// <param name="b">The bullet to compare.</param>
		/// <returns>True if the bullet hit the ship; false otherwise.</returns>
		public bool CollideBullet(Bullet b)
		{
			//see if the bullet hit the ship
			bool hit = Bounds.Contains((int)b.Position.X, (int)b.Position.Y);

			//play a sound if hit
			if (hit)
				SoundManager.PlayCue("explode");

			//return the value
			return hit;
		}

		/// <summary>
		/// Fires a single bullet.
		/// </summary>
		/// <param name="bullets">The list into which the bullet will be added.</param>
		public void Fire(List<Bullet> bullets)
		{
			//make sure the timer has expired
			if (fireTimer <= 0f)
			{
				//reset the timer
				fireTimer = fireRate;

				//create a new bullet and add it to the list
				Bullet b = new Bullet();
				b.Position = Position + BulletOrigin;
				b.Velocity = BulletVelocity;
				b.Color = BulletColor;
				bullets.Add(b);

				//play the laser sound effect
				SoundManager.PlayCue("laser");
			}
		}

		public virtual void Update(GameTime gameTime, List<Bullet> bullets, int fieldWidth)
		{
			//reduce the fire timer by the elapsed time
			fireTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
		}
	}
}
