using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents a single alien ship.
	/// </summary>
	public class AlienShip : Ship
	{
		static Random rand = new Random();

		/// <summary>
		/// Specifies the chances (out of 1000) that the alien ship will fire a bullet
		/// </summary>
		public int ChanceToFire = 2;

		public AlienShip(Texture2D spriteTexture)
			: base(spriteTexture)
		{
			BulletOrigin = new Vector2(0, 16);
			BulletVelocity = new Vector2(0, 5);
			BulletColor = Color.Blue;
		}

		public override void Update(GameTime gameTime, List<Bullet> bullets, int fieldWidth)
		{
			//randomly try to fire a bullet
			if (rand.Next(1000) < ChanceToFire)
				Fire(bullets);

			//make sure to call base.Update so that our bullet timer gets updated
			base.Update(gameTime, bullets, fieldWidth);
		}
	}
}
