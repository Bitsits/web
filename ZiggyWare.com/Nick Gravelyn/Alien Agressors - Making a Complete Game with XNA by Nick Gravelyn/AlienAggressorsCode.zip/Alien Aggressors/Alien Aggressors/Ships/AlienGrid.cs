using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Alien_Aggressors
{
	/// <summary>
	/// Represents the full grid of aliens.
	/// </summary>
	public class AlienGrid : List<List<AlienShip>>
	{
		/// <summary>
		/// Represents the maximum speed of the grid
		/// </summary>
		public const float MaxSpeed = 10f;

		/// <summary>
		/// Represents the current speed of the grid
		/// </summary>
		public float Velocity = 1f;

		public bool Update(
			GameTime gameTime,
			List<Bullet> bullets,
			int fieldWidth,
			int playerLine)
		{
			//if there are no aliens, return false
			if (this.Count == 0)
				return false;

			//get the left-most alien and right-most alien
			AlienShip leftMost = this[0][0];
			AlienShip rightMost = this[this.Count - 1][0];

			//if we have hit the edge of our playing field
			if ((Velocity > 0 && rightMost.Bounds.Right >= fieldWidth) ||
				(Velocity < 0 && leftMost.Bounds.Left <= 0))
			{
				//create a velocity change to reverse direction and accelerate
				float velocityChange = 1.01f;

				//apply the velocity change while clamping our velocity to the maximum speed
				Velocity = MathHelper.Clamp(Velocity * -velocityChange, -MaxSpeed, MaxSpeed); 

				//go through all of the ships, move them down on the screen, and see if any
				//have crossed the player line. return true if any have.
				foreach (List<AlienShip> column in this)
				{
					foreach (Sprite enemy in column)
					{
						enemy.Position.Y += enemy.Bounds.Height / 2;

						if (enemy.Bounds.Bottom > playerLine)
							return true;
					}
				}
			}

			//go through all of the ships, update their position with the velocity, and call
			//their Update methods to allow them a chance to fire a bullet.
			foreach (List<AlienShip> column in this)
			{
				foreach (AlienShip enemy in column)
				{
					enemy.Position.X += Velocity;
					enemy.Update(gameTime, bullets, fieldWidth);
				}
			}

			//return false to indicate that the aliens haven't reached the player yet
			return false;
		}

		public void Initialize(Texture2D alienTexture, int columns, int rows)
		{
			//clear any existing aliens out of the grid
			this.Clear();

			for (int x = 0; x < columns; x++)
			{
				//create a new column
				List<AlienShip> column = new List<AlienShip>();

				for (int y = 0; y < rows; y++)
				{
					//create a ship
					AlienShip alien = new AlienShip(alienTexture);

					//figure out the spacing between aliens
					Vector2 alienSpacing = new Vector2(
						alien.Bounds.Width,
						alien.Bounds.Height) * 1.25f;

					//calculate the alien's position
					alien.Position = new Vector2(
						(alien.Bounds.Width / 2) + (alienSpacing.X * x),
						(alien.Bounds.Height / 2) + (alienSpacing.Y * y));

					//add the alien to the column
					column.Add(alien);
				}

				//add the column to the grid
				this.Add(column);
			}
		}

		public bool CollideBullet(Bullet b)
		{
			//if there are no aliens, we return false
			if (this.Count == 0)
				return false;

			//this stores which alien ship was hit (if any)
			AlienShip collider = null;

			foreach (List<AlienShip> column in this)
			{
				foreach (AlienShip enemy in column)
				{
					//attempt to collide an enemy with the bullet
					if (enemy.CollideBullet(b))
					{
						//if successful, save the enemy and break out of the inner loop
						collider = enemy;
						break;
					}
				}

				//if a collider was found, remove it from the column and break out of the loop
				if (collider != null)
				{
					column.Remove(collider);
					break;
				}
			}

			//go through our grid and remove any empty columns
			for (int i = this.Count - 1; i >= 0; i--)
				if (this[i].Count == 0)
					this.RemoveAt(i);

			//return whether a collider was found
			return (collider != null);
		}


		public void Draw(SpriteBatch spriteBatch)
		{
			//iterate through all aliens and call their Draw method
			foreach (List<AlienShip> column in this)
				foreach (AlienShip s in column)
					s.Draw(spriteBatch);
		}
	}
}
