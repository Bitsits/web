using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Alien_Aggressors
{
	/// <summary>
	/// A dynamically created starry texture for the background.
	/// </summary>
	public class StarryBackground : Texture2D
	{
		public StarryBackground(
			GraphicsDevice graphics, 
			int width, 
			int height, 
			int numberOfStars)
			: base(
				graphics, 
				width, 
				height, 
				1, 
				TextureUsage.None, 
				SurfaceFormat.Color)
		{
			//make sure the number of stars is valid
			if (numberOfStars >= width * height || numberOfStars < 0)
				throw new Exception(
					"numberOfStars must be in the range of [0, width * height - 1]");

			Random rand = new Random();

			Color[] pixels = new Color[width * height];
			int starsAdded = 0;

			//run a loop until we add enough stars
			while (starsAdded < numberOfStars)
			{
				//generate a random pixel index, see if it is still the default value,
				//and generate a new random value for the pixel.

				int index = rand.Next(pixels.Length);
				if (pixels[index] == Color.TransparentBlack)
				{
					float value = (float)rand.NextDouble() + .5f;
					pixels[index] = new Color(new Vector4(value));
					starsAdded++;
				}
			}

			//save the pixels to the texture
			SetData(pixels);
		}
	}
}
