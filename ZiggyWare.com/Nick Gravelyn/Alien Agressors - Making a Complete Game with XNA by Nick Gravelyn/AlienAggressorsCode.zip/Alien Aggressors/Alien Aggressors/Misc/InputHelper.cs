using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;

namespace Alien_Aggressors
{
	/// <summary>
	/// A static class that holds the last frame's input data and exposes
	/// some useful methods.
	/// </summary>
	public static class InputHelper
	{
		//we store the current and last input states for each state to use
		public static GamePadState GamePadState1;
		public static GamePadState GamePadState2;
		public static KeyboardState KeyboardState;
		public static GamePadState LastGamePadState1;
		public static GamePadState LastGamePadState2;
		public static KeyboardState LastKeyboardState;

		/// <summary>
		/// Tells whether a given button was just pressed this frame.
		/// </summary>
		/// <param name="index">Which GamePad to check.</param>
		/// <param name="button">Which button to check.</param>
		/// <returns>True if the button was just pressed; false otherwise</returns>
		public static bool IsNewButtonPress(PlayerIndex index, Buttons button)
		{
			//simply check for which game pad and then compare the new state
			//to the last state
			if (index == PlayerIndex.One)
				return (GamePadState1.IsButtonDown(button) && LastGamePadState1.IsButtonUp(button));
			else
				return (GamePadState2.IsButtonDown(button) && LastGamePadState2.IsButtonUp(button));
		}

		/// <summary>
		/// Tells whether a given key was just pressed this frame.
		/// </summary>
		/// <param name="key">Which key to check</param>
		/// <returns>True if the key was just pressed; false otherwise</returns>
		public static bool IsNewKeyPress(Keys key)
		{
			//simply return a comparison between the last state and the new one
			return (KeyboardState.IsKeyDown(key) && LastKeyboardState.IsKeyUp(key));
		}

		/// <summary>
		/// Tells whether a thumbstick axis passed a given threshold this frame.
		/// </summary>
		/// <param name="index">The game pad to check</param>
		/// <param name="newState">The new state of the game pad</param>
		/// <param name="thumbstick">Which thumbstick to check</param>
		/// <param name="axis">Which axis of the thumbstick to check</param>
		/// <param name="threshold">The given threshold to check. Must be in range [-1, 1]</param>
		/// <returns>True if the threshold was passed this frame, false otherwise</returns>
		public static bool DidThumbstickPassThreshold(
			PlayerIndex index, 
			Thumbstick thumbstick,
			ThumbstickAxis axis, 
			float threshold)
		{
			//the last and current thumbstick values
			Vector2 lastThumbStick = Vector2.Zero;
			Vector2 newThumbStick = Vector2.Zero;

			//based on which thumbstick and index we have, we want to
			//get the last and new thumbstick values from our new
			//and last gamepad state values
			if (thumbstick == Thumbstick.Left)
			{
				if (index == PlayerIndex.One)
				{
					lastThumbStick = LastGamePadState1.ThumbSticks.Left;
					newThumbStick = GamePadState1.ThumbSticks.Left;
				}
				else
				{
					lastThumbStick = LastGamePadState2.ThumbSticks.Left;
					newThumbStick = GamePadState2.ThumbSticks.Left;
				}
			}
			else
			{
				if (index == PlayerIndex.One)
				{
					lastThumbStick = LastGamePadState1.ThumbSticks.Right;
					newThumbStick = GamePadState1.ThumbSticks.Right;
				}
				else
				{
					lastThumbStick = LastGamePadState2.ThumbSticks.Right;
					newThumbStick = GamePadState2.ThumbSticks.Right;
				}
			}

			//the lastValue and newValue on the given axis
			float lastValue = 0f, newValue = 0f;

			//based on the axis given, we set the new and last values for testing
			if (axis == ThumbstickAxis.X)
			{
				lastValue = lastThumbStick.X;
				newValue = newThumbStick.X;
			}
			else
			{
				lastValue = lastThumbStick.Y;
				newValue = newThumbStick.Y;
			}

			//based on whether the threshold is negative, we return whether or
			//not the lastValue and newValue are on each side of the threshold
			if (threshold < 0f)
				return (lastValue > threshold && newValue < threshold);
			else
				return (lastValue < threshold && newValue > threshold);
		}

		/// <summary>
		/// Updates all the input states.
		/// </summary>
		public static void Update()
		{
			LastGamePadState1 = GamePadState1;
			LastGamePadState2 = GamePadState2;
			LastKeyboardState = KeyboardState;
			GamePadState1 = GamePad.GetState(PlayerIndex.One);
			GamePadState2 = GamePad.GetState(PlayerIndex.Two);
			KeyboardState = Keyboard.GetState();
		}
	}

	//a couple of simple enums for use with our DidThumbstickPassThreshold method
	public enum Thumbstick
	{
		Left,
		Right
	}

	public enum ThumbstickAxis
	{
		X,
		Y
	}
}
