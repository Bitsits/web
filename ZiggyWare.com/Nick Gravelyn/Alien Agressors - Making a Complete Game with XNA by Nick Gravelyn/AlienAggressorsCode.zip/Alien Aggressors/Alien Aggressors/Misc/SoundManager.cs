using System;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework;
using System.Reflection;
using System.IO;

namespace Alien_Aggressors
{
	/// <summary>
	/// Controls the audio for the game
	/// </summary>
	public static class SoundManager
	{
		//the three components of the sound in XNA
		static AudioEngine engine;
		static WaveBank waveBank;
		static SoundBank soundBank;

		//we hold a cue for the current background music
		static Cue music;

		/// <summary>
		/// Initializes the manager.
		/// </summary>
		/// <param name="engineFile">The relative path to the audio engine file.</param>
		/// <param name="waveBankFile">The relative path to the wave bank file.</param>
		/// <param name="soundBankFile">The relative path to the sound bank file.</param>
		public static void Initialize(Game game, string engineFile, string waveBankFile, string soundBankFile)
		{
			string contentDir = game.Content.RootDirectory + "/";

			//simply create the three pieces using the given file names
			engine = new AudioEngine(contentDir + engineFile);
			waveBank = new WaveBank(engine, contentDir + waveBankFile);
			soundBank = new SoundBank(engine, contentDir + soundBankFile);
		}

		/// <summary>
		/// Plays a cue with a given name.
		/// </summary>
		/// <param name="name">The name of the cue to play.</param>
		public static void PlayCue(string name)
		{
			soundBank.PlayCue(name);
		}

		/// <summary>
		/// Sets the background music to the sound with the given name.
		/// </summary>
		/// <param name="name">The name of the music to play.</param>
		public static void PlayMusic(string name)
		{
			music = soundBank.GetCue(name);
			music.Play();
		}

		/// <summary>
		/// Stops the background music.
		/// </summary>
		public static void StopMusic()
		{
			if (music != null && music.IsPlaying)
			{
				music.Stop(AudioStopOptions.Immediate);
				music = null;
			}
		}

		/// <summary>
		/// Sets the sound FX volume level.
		/// </summary>
		/// <param name="volume">A volume level in the range [0, 1].</param>
		public static void SetSoundFXVolume(float volume)
		{
			engine.GetCategory("SoundFx").SetVolume(volume);
		}

		/// <summary>
		/// Sets the music volume level.
		/// </summary>
		/// <param name="volume">A volume level in the range [0, 1].</param>
		public static void SetMusicVolume(float volume)
		{
			engine.GetCategory("Music").SetVolume(volume);
		}

		/// <summary>
		/// Updates the AudioEngine.
		/// </summary>
		public static void Update()
		{
			engine.Update();
		}
	}
}
