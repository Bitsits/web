#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace AnimatingSpriteSheets
{
	public class Game1 : Game
	{
		GraphicsDeviceManager graphics;

		//we need a SpriteBatch
		SpriteBatch batch;

		//and one of our AnimatingSprites
		AnimatingSprite sprite;

		public Game1()
		{
			graphics = new GraphicsDeviceManager(this);
			Content.RootDirectory = "Content";
		}

		protected override void Initialize()
		{
			sprite = new AnimatingSprite();

			//create our new Animations. since all of our frames are 32x32 we can easily figure
			//out the parameters for our animations.
			//our sheet lays the animations out as up-down-left-right.
			//each animation is 2 32x32 frames. so each Animation will have a width of 64,
			//a height of 32, 2 for the frame count, and 0 for the yOffset (the last parameter).
			//the only parameter that changes is the xOffset which moves the animation along the
			//X axis to the proper place, skipping all previous animation frames. for us, we move
			//the xOffset in multiples of 64.
			Animation up = new Animation(64, 32, 2, 0, 0);
			Animation down = new Animation(64, 32, 2, 64, 0);
			Animation left = new Animation(64, 32, 2, 128, 0);
			Animation right = new Animation(64, 32, 2, 192, 0);

			//next we add the animations to our sprite's animation dictionary using sensible names.
			sprite.Animations.Add("Up", up);
			sprite.Animations.Add("Down", down);
			sprite.Animations.Add("Left", left);
			sprite.Animations.Add("Right", right);

			//and set a starting position for the sprite
			sprite.Position = new Vector2(100f);

			base.Initialize();
		}

		protected override void LoadContent()
		{
			//create the sprite batch
			batch = new SpriteBatch(graphics.GraphicsDevice);

			//load the sprite texture sheet
			sprite.Texture = Content.Load<Texture2D>(@"Content/knt1");
		}


		protected override void Update(GameTime gameTime)
		{
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
				Keyboard.GetState().IsKeyDown(Keys.Escape))
				this.Exit();

			//we have three methods of input available.
			//1) Thumbstick input. This is the cleanest method since we don't have to
			//   worry about users pressing two buttons at once. Since we have limited
			//   all motion to left-right and up-down (no diagonals), the thumbstick
			//   actually provides an easier method of input.
			//2) DPad input. This lets us use the GamePad DPad to control the character.
			//   You'll notice that some directions are "favored" over others by being
			//   earlier in the series of if statements. This is a problem one would
			//   have to solve to use the DPad for input in a game with movement like this.
			//3) Keyboard input. Exactly the same as the DPad input except using WASD and
			//   the arrow keys for moving the character around.
			
			//determine if a GamePad is connected
			if (GamePad.GetState(PlayerIndex.One).IsConnected)
			{
				//by default we use the thumbstick input from the GamePad
				GetThumbstickInput();
				//GetDPadInput();
			}

			//otherwise just use the Keyboard input
			else
				GetKeyboardInput();

			//make sure we update the sprite who will in turn update his current active animation
			sprite.Update(gameTime);

			base.Update(gameTime);
		}

		private void GetKeyboardInput()
		{
			//get the keyboard state once instead of lots of times
			KeyboardState ks = Keyboard.GetState();

			//check the keys and set the proper values. we also call
			//StartAnimation on the sprite to ensure the sprite is
			//animating.
			if (ks.IsKeyDown(Keys.Right) || ks.IsKeyDown(Keys.D))
			{
				sprite.CurrentAnimation = "Right";
				sprite.Position.X++;
				sprite.StartAnimation();
			}
			else if (ks.IsKeyDown(Keys.Up) || ks.IsKeyDown(Keys.W))
			{
				sprite.CurrentAnimation = "Up";
				sprite.Position.Y--;
				sprite.StartAnimation();
			}
			else if (ks.IsKeyDown(Keys.Down) || ks.IsKeyDown(Keys.S))
			{
				sprite.CurrentAnimation = "Down";
				sprite.Position.Y++;
				sprite.StartAnimation();
			}
			else if (ks.IsKeyDown(Keys.Left) || ks.IsKeyDown(Keys.A))
			{
				sprite.CurrentAnimation = "Left";
				sprite.Position.X--;
				sprite.StartAnimation();
			}

			//if we aren't moving, we stop the animation
			else
			{
				sprite.StopAnimation();
			}
		}

		private void GetDPadInput()
		{
			//get the GamePad state once instead of lots of times
			GamePadState gps = GamePad.GetState(PlayerIndex.One);

			//check the buttons and set the proper values. we also call
			//StartAnimation on the sprite to ensure the sprite is
			//animating.
			if (gps.DPad.Right == ButtonState.Pressed)
			{
				sprite.CurrentAnimation = "Right";
				sprite.Position.X++;
				sprite.StartAnimation();
			}
			else if (gps.DPad.Up == ButtonState.Pressed)
			{
				sprite.CurrentAnimation = "Up";
				sprite.Position.Y--;
				sprite.StartAnimation();
			}
			else if (gps.DPad.Down == ButtonState.Pressed)
			{
				sprite.CurrentAnimation = "Down";
				sprite.Position.Y++;
				sprite.StartAnimation();
			}
			else if (gps.DPad.Left == ButtonState.Pressed)
			{
				sprite.CurrentAnimation = "Left";
				sprite.Position.X--;
				sprite.StartAnimation();
			}

			//if we aren't moving, we stop the animation
			else
			{
				sprite.StopAnimation();
			}
		}

		private void GetThumbstickInput()
		{
			//Easily the most elaborate input method, the GetThumbStickInput
			//does give us the most reliable method of moving the character around.

			//first we get the left thumbstick as a vector
			Vector2 leftStick = GamePad.GetState(PlayerIndex.One).ThumbSticks.Left;

			//we want to make sure the user has pressed the stick a little bit before
			//any movement is to happen
			if (leftStick.Length() > .2f)
			{
				//we convert the joystick vector to an angle. This value will be
				//between -Pi and Pi. We will then use this to determine which direction
				//to move.
				float stickAngle = (float)Math.Atan2(leftStick.Y, leftStick.X);

				//we now compare the stickAngle to a bunch of ranges. these ranges correspond
				//to areas mapped on the joystick for various directions. I have numbered each
				//area from 1-4 and you can see how they map to the thumbstick by looking
				//at the accompanying thumbstick.png file.

				//-Pi/4 to Pi/4 (Area 1)
				if (stickAngle > -MathHelper.PiOver4 &&
					stickAngle < MathHelper.PiOver4)
				{
					sprite.CurrentAnimation = "Right";
					sprite.Position.X++;
				}

				//Pi/4 to 3Pi/4 (Area 2)
				else if (stickAngle > MathHelper.PiOver4 &&
					stickAngle < 3f * MathHelper.PiOver4)
				{
					sprite.CurrentAnimation = "Up";
					sprite.Position.Y--;
				}

				//-Pi/4 to -3Pi/4 (Area 3)
				else if (stickAngle > -(3f * MathHelper.PiOver4) &&
					stickAngle < -MathHelper.PiOver4)
				{
					sprite.CurrentAnimation = "Down";
					sprite.Position.Y++;
				}

				//remaining area (Area 4)
				else
				{
					sprite.CurrentAnimation = "Left";
					sprite.Position.X--;
				}

				//make sure we are animating the sprite
				sprite.StartAnimation();
			}

			//if we aren't moving, we stop the animation
			else
			{
				sprite.StopAnimation();
			}
		}

		protected override void Draw(GameTime gameTime)
		{
			graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

			//start the SpriteBatch
			batch.Begin();

			//pass the batch to the sprite to draw itself
			sprite.Draw(batch);

			//end the batch
			batch.End();

			base.Draw(gameTime);
		}
	}
}
