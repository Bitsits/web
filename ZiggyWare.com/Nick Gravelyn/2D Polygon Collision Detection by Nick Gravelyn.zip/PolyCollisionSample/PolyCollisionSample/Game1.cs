using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

namespace PolyCollisionSample
{
	public class PolyCollisionGame : Microsoft.Xna.Framework.Game
	{
		GraphicsDeviceManager graphics;
		PrimitiveBatch primitiveBatch;

		PrimitiveShape shape1, shape2, shape3;

		public PolyCollisionGame()
		{
			graphics = new GraphicsDeviceManager(this);

			graphics.PreferredBackBufferWidth = 853;
			graphics.PreferredBackBufferHeight = 480;

			Vector2[] shape1Vertices = new Vector2[] {
				new Vector2(50f, 0f),
				new Vector2(40f, -5f),
				new Vector2(70f, -20f),
				new Vector2(0f, -40f),
				new Vector2(-40f, 0f),
				new Vector2(0f, 40f),
				new Vector2(70f, 20f),
				new Vector2(40f, 5f)
			};

			Vector2[] shape2Vertices = new Vector2[] {
				new Vector2(10f, 10f),
				new Vector2(-50f, -50f),
				new Vector2(-50f, 50f),
				new Vector2(50f, 50f),
				new Vector2(50f, -50f),
				new Vector2(-10f, 10f)
			};

			shape1 = new PrimitiveShape(shape1Vertices);
			shape2 = new PrimitiveShape(shape2Vertices);
			shape3 = new PrimitiveShape(shape1Vertices);
			shape2.Position = new Vector2(300f);
			shape3.Position = new Vector2(600f, 300f);
		}

		protected override void LoadGraphicsContent(bool loadAllContent)
		{
			if (loadAllContent)
			{
				primitiveBatch = new PrimitiveBatch(graphics.GraphicsDevice);
			}

			base.LoadGraphicsContent(loadAllContent);
		}

		protected override void Update(GameTime gameTime)
		{
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
				Keyboard.GetState().IsKeyDown(Keys.Escape))
				Exit();

			Vector2 movement = GamePad.GetState(PlayerIndex.One).ThumbSticks.Left * 1.5f;
			movement.Y *= -1;
			
			float rotation = GamePad.GetState(PlayerIndex.One).ThumbSticks.Right.X;

			shape1.Position += movement;
			shape1.Rotation += rotation * .1f;

			shape1.ShapeColor = shape2.ShapeColor = shape3.ShapeColor = Color.White;

			if (PrimitiveShape.TestCollision(shape1, shape2))
				shape1.ShapeColor = shape2.ShapeColor = Color.Red;

			if (PrimitiveShape.TestCollision(shape1, shape3))
				shape1.ShapeColor = shape3.ShapeColor = Color.Red;

			base.Update(gameTime);
		}

		protected override void Draw(GameTime gameTime)
		{
			graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

			shape1.Draw(primitiveBatch);
			shape2.Draw(primitiveBatch);
			shape3.Draw(primitiveBatch);

			base.Draw(gameTime);
		}
	}
}
