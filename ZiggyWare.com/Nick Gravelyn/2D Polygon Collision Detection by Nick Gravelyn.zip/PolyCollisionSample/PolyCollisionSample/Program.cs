using System;

namespace PolyCollisionSample
{
	static class Program
	{
		static void Main()
		{
			using (PolyCollisionGame game = new PolyCollisionGame())
			{
				game.Run();
			}
		}
	}
}

