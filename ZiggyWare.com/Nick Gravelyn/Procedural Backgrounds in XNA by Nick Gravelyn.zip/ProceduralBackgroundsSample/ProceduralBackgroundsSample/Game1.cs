#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

/*
 * This sample demonstrates how to procedurally generate simple backgrounds
 * that could be used for menus or during gameplay. 
 * 
 * The benefits to such technique include reduced asset demand (and thus smaller 
 * file size) as well as having resolution independent art assets for backgrounds.
 * One could also elaborate on these ideas to create much more interesting procedural
 * backgrounds by using Perlin noise or any other algorithm.
 * 
 * The downside to the technique is a slightly longer loading time as the textures
 * have to be created.
 * 
 * The sample allows a user to switch between four settings by using the numbers on
 * the keyboard:
 *		1 - No background texture. Just cornflower blue.
 *		2 - Use a background made of diagonal stripes
 *		3 - Use a background made of sine waves
 *		4 - Use a background made of checkerboards
 * 
 * To exit the sample either press Escape on your keyboard or Back on an Xbox 360 game pad.
 */

namespace ProceduralBackgroundsSample
{
	public class Game1 : Microsoft.Xna.Framework.Game
	{
		//no need for a ContentManager in this sample; just the GraphicsDeviceManager
		GraphicsDeviceManager graphics;

		//simple SpriteBatch
		SpriteBatch batch;

		//create a new list to store our procedural backgrounds
		List<Texture2D> backgrounds = new List<Texture2D>();

		//an index to the current background. by specifying -1, our draw code will not
		//draw the sprite
		int currentBackground = -1;

		public Game1()
		{
			graphics = new GraphicsDeviceManager(this);

			//turn on antialiasing for cleaner lines in our backgrounds
			graphics.PreferMultiSampling = true;
		}

		protected override void LoadGraphicsContent(bool loadAllContent)
		{
			if (loadAllContent)
			{
				//create the sprite batch
				batch = new SpriteBatch(graphics.GraphicsDevice);

				//call our methods to generate textures for us
				GenerateTexture1();
				GenerateTexture2();
				GenerateTexture3();
			}
		}

		//this method generates a simple diagonal stripped pattern for a background
		void GenerateTexture1()
		{
			//create a new texture using our helper method. the helper
			//also adds the texture to our list for us so we don't have to.
			Texture2D tex = CreateNewBackgroundTexture();

			//we're going to use a simple algorithm for creating a diagonally stripped background.
			//we'll use two colors: a background color and a foreground color.
			Color backgroundColor = Color.Black;
			Color foregroundColor = Color.Green;

			//now we loop through all of the pixels in our texture. we use a mod function (%) to find
			//the diagonals. we can change the distance between lines by playing with our modFactor.
			int modFactor = 15;

			//now create an array for the pixels
			Color[] pixels = new Color[tex.Width * tex.Height];

			//loop through the X and Y values. i prefer to use the Y for the outer loop, but changing it won't
			//break it. it might change the outputs, but i doubt that.
			for (int y = 0; y < tex.Height; y++)
			{
				for (int x = 0; x < tex.Width; x++)
				{
					//we calculate our mod value by summing the X and Y and using the modFactor we set above
					int modValue = (x + y) % modFactor;

					//if the modValue is 0, we use the foregroundColor. otherwise we use the backgroundColor
					if (modValue == 0)
						pixels[y * tex.Width + x] = foregroundColor;
					else
						pixels[y * tex.Width + x] = backgroundColor;
				}
			}

			//lastly we need to set the texture's data to our new pixel array
			tex.SetData<Color>(pixels);
		}

		//this method generates a series of sin waves as a background
		void GenerateTexture2()
		{
			//create a new texture using our helper method. the helper
			//also adds the texture to our list for us so we don't have to.
			Texture2D tex = CreateNewBackgroundTexture();

			//we'll use two colors: a background color and a foreground color.
			Color backgroundColor = Color.Black;
			Color foregroundColor = Color.Pink;

			//we need to set a vertical spacing for our sin waves
			int verticalSpacing = 20;

			//we also need to set a magnitude for the sin waves
			float sinMagnitude = 5f;

			//and finally we set a frequency for the sin wave
			float sinFrequency = .2f;

			//now create an array for the pixels
			Color[] pixels = new Color[tex.Width * tex.Height];

			//we're going to first fill the array in the background color
			for (int i = 0; i < pixels.Length; i++)
				pixels[i] = backgroundColor;

			//we now need to loop through all the horizontal pixels
			for (int x = 0; x < tex.Width; x++)
			{
				//we calculate the Y value for the sin wave
				float y = (float)Math.Sin((float)x * sinFrequency) * sinMagnitude;

				//we now have to loop through all rows and set the pixel
				//values accordingly
				while (y < tex.Height)
				{
					//cast the Y value to our row value
					int row = (int)y;

					//make sure the row is a valid row in the texture
					if (y >= 0 && y < tex.Height)
						pixels[row * tex.Width + x] = foregroundColor;

					//jump down to the next row based on our vertical spacing
					y += verticalSpacing;
				}
			}

			//lastly we need to set the texture's data to our new pixel array
			tex.SetData<Color>(pixels);
		}

		//this method creates a simple checkerboard style for a background
		void GenerateTexture3()
		{
			//create a new texture using our helper method. the helper
			//also adds the texture to our list for us so we don't have to.
			Texture2D tex = CreateNewBackgroundTexture();

			//we'll use two colors: a background color and a foreground color.
			Color backgroundColor = Color.Black;
			Color foregroundColor = Color.Red;

			//set up the size of our horizontal spacing
			int horizontalSpacing = tex.Width / 40;

			//set up the size of our vertical spacing
			int verticalSpacing = tex.Height / 40;

			//now create an array for the pixels
			Color[] pixels = new Color[tex.Width * tex.Height];
			
			//loop through the X and Y values
			for (int y = 0; y < tex.Height; y++)
			{
				for (int x = 0; x < tex.Width; x++)
				{
					//calculate the pixel
					int pixel = y * tex.Width + x;

					//if the pixel lies on a line, the Y value or X value will return 0 when we
					//use the mod function along with the spacings.
					int xMod = x % horizontalSpacing;
					int yMod = y % verticalSpacing;

					//if either mod value is 0, we use the foreground color. otherwise we use the background.
					if (xMod == 0 || yMod == 0)
						pixels[pixel] = foregroundColor;
					else
						pixels[pixel] = backgroundColor;
				}
			}

			//lastly we need to set the texture's data to our new pixel array
			tex.SetData<Color>(pixels);
		}

		Texture2D CreateNewBackgroundTexture()
		{
			//create a new Texture
			Texture2D tex = new Texture2D(

				//current graphics device
				graphics.GraphicsDevice,

				//width and height for the texture; we'll go fullscreen
				graphics.GraphicsDevice.Viewport.Width,
				graphics.GraphicsDevice.Viewport.Height,

				//mipmap generation. we'll leave at 1
				1,

				//no special resource usage
				ResourceUsage.None,

				//a basic format that allows RGBA colors
				SurfaceFormat.Color,

				//we want the texture to be handled automatically by the graphics device
				ResourceManagementMode.Automatic);

			//add the texture to our list
			backgrounds.Add(tex);

			//return the texture for use
			return tex;
		}

		protected override void Update(GameTime gameTime)
		{
			//quit the demo on the Back button or the escape key
			if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
				Keyboard.GetState().IsKeyDown(Keys.Escape))
				this.Exit();

			//use the number keys to select the texture. 1 = no texture.
			KeyboardState ks = Keyboard.GetState();
			if (ks.IsKeyDown(Keys.D1))
				currentBackground = -1;
			else if (ks.IsKeyDown(Keys.D2))
				currentBackground = 0;
			else if (ks.IsKeyDown(Keys.D3))
				currentBackground = 1;
			else if (ks.IsKeyDown(Keys.D4))
				currentBackground = 2;

			base.Update(gameTime);
		}

		protected override void Draw(GameTime gameTime)
		{
			graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

			//if the current background index is valid, we draw a fullscreen sprite with our texture
			if (currentBackground >= 0)
			{
				batch.Begin(SpriteBlendMode.AlphaBlend);
				batch.Draw(
					backgrounds[currentBackground], 
					new Rectangle(0, 0, graphics.GraphicsDevice.Viewport.Width, graphics.GraphicsDevice.Viewport.Height), 
					Color.White);
				batch.End();
			}

			base.Draw(gameTime);
		}
	}
}
